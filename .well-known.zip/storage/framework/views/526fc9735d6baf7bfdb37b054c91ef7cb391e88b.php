
<?php $__env->startSection('content'); ?>

<!--<section id="hero_in" class="courses">-->
<!--			<div class="wrapper">-->
<!--				<div class="container">-->
<!--					<h1 class="fadeInUp"><span></span>Online course detail</h1>-->
<!--				</div>-->
<!--			</div>-->
<!--		</section>-->
		<section id="hero_in" class="cart_section">
			<div class="wrapper">
				<div class="container">
					<div class="bs-wizard clearfix">
						<div class="bs-wizard-step active">
							<div class="text-center bs-wizard-stepnum">Your cart</div>
							<div class="progress">
								<div class="progress-bar"></div>
							</div>
							<a href="#0" class="bs-wizard-dot"></a>
						</div>

						<div class="bs-wizard-step disabled">
							<div class="text-center bs-wizard-stepnum">Payment</div>
							<div class="progress">
								<div class="progress-bar"></div>
							</div>
							<a href="#0" class="bs-wizard-dot"></a>
						</div>

						<div class="bs-wizard-step disabled">
							<div class="text-center bs-wizard-stepnum">Finish!</div>
							<div class="progress">
								<div class="progress-bar"></div>
							</div>
							<a href="#0" class="bs-wizard-dot"></a>
						</div>
					</div>
					<!-- End bs-wizard -->
				</div>
			</div>
		</section>

<div class="bg_color_1">
			<div class="container margin_60_35">
				<div class="row">
					<div class="col-lg-8">
						<div class="box_cart">
						<?php if(count($cartlist) >0): ?>
						<table class="table cart-list">
							<thead>
								<tr>
									<th>
										Item
									</th>
									<th style="padding-left: 35px;">
									    Name
									</th>
									<th style="padding-left: 35px;">
									    Count
									</th>
								
									<th>
										Price
									</th>
									<th>
										Actions
									</th>
								</tr>
							</thead>
							<tbody>
							    <?php $__currentLoopData = $cartlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr class="quantity_parent">
								    <input type="hidden" class="price" value="<?php echo e($cartdetail->cprice); ?>">
                                    <input type="hidden" class="course_id" value="<?php echo e($cartdetail->course_id); ?>">
                                    <input type="hidden" name="" class="single_total" value="0">
									<td>
							            <div>
							              	
							             <img src="<?php echo e(asset('uploads/advancecourse/image/'.$cartdetail->image)); ?>" alt="" 
							                    	class="image_basic_advance_course_first">
									    </div>
									</td>
									<td>
									   	<span class="item_cart"><?php echo e($cartdetail->ctitle); ?></span> 
									</td>
									<td> 
                                        <input type="number" id="tentacles" class = "quantity" name="tentacles" min="1" max="1000" value="<?php echo e($cartdetail->quantity); ?>"> 
                                    </td>
								
									<td>
										<strong>$<?php echo e($cartdetail->cprice); ?></strong>
									</td>
									<td class="options" style="width:5%; text-align:center;">
									    <a href="<?php echo e(url('cartdelete/'.$cartdetail->id)); ?>" class="edit_del"><i class="fa fa-trash-o remo tresh_call" aria-hidden="true"></i></a>
										<!--<a href="#"><i class="icon-trash"></i></a>-->
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							
							
							</tbody>
						</table>
		<div class="cart-options clearfix">
							<div class="float-left">
								<div class="apply-coupon">
									<div class="form-group">
										<input type="text" name="coupon-code" value="" placeholder="Your Coupon Code" class="form-control">
									</div>
									<div class="form-group">
										<button type="button" class="btn_1 outline">Apply Coupon</button>
									</div>
								</div>
							</div>
							<div class="float-right fix_mobile">
								<button type="button" class="btn_1 outline">Update Cart</button>
							</div>
						</div>
						    <!--<h1>No Item Found</h1>-->
						<?php endif; ?>
						<!-- /cart-options -->
					</div>
					</div>
					<!-- /col -->
					    <?php
                            $i=1;
                            $total = 0;
                        ?>
                       
                        <?php $__currentLoopData = $cartlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $price = $item->cprice;
                                $quantity = $item->quantity;
                                $subtotal = ($price*$quantity);
                                $total = $total + $subtotal;
                            ?>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<aside class="col-lg-4" id="sidebar">
						<div class="box_detail">
							<div id="total_cart">
								Total <span class="float-right">$<?php echo e($total); ?></span>
							</div>
							<div class="add_bottom_30">Lorem ipsum dolor sit amet, sed vide <strong>moderatius</strong> ad. Ex eius soleat sanctus pro, enim conceptam in quo, <a href="#0">brute convenire</a> appellantur an mei.</div>
							<a href="<?php echo e(url('checkout')); ?>" class="btn_1 full-width">Checkout</a>
							<a href="<?php echo e(url('/')); ?>" class="btn_1 full-width outline"><i class="icon-right"></i> Continue Shopping</a>
						</div>
					</aside>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript">
          $(document).ready(function(){
             
              $(document).on( "input","#tentacles", function(){
           
              var quantity = parseInt($(this).parents('.quantity_parent').find('.quantity').val());
              var price = parseInt($(this).parents('.quantity_parent').find('.cprice').val());
              var course_id = parseInt($(this).parents('.quantity_parent').find('.course_id').val());
              $this = $(this);
              $.ajax({
                type:'POST',
                dataType:'json',
                url:"<?php echo e(route('cartupdate')); ?>",
                data:{
                    quantity:quantity,
                    course_id:course_id,
                    _token:'<?php echo e(csrf_token()); ?>'
                },
                success:function(response){
                    if(response.status){
                         window.location.href = "<?php echo e(url('cartlist')); ?>"; 
                        }
                }
            });
              
            
            });
          });
        
          
        
        </script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/advanced_course_details.blade.php ENDPATH**/ ?>