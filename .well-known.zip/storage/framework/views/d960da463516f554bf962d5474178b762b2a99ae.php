
<?php $__env->startSection('contant'); ?>
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



            <div class="container-fluid">
 

 <div class="row">

	<div class="col-lg-12">
          <div class="card">

          <div class="row">
          <div class="col-md-12"> <h5 class="card-header text-uppercase"> About Setting <a style="float: right;" class="btn btn-primary" href="edit<?php echo e($data->id); ?>"><i class="fa fa-pencil" style="margin-right: 0;" aria-hidden="true"></i></a></h5></div>

          </div>
		 
         
            <div class="card-body">
              
			<div class="table-responsive">
	          <table class="table table-bordered">
            <thead>

               <tr>
                <th>About Us Title </th>
                <td><?php echo e($data->about_title); ?></td>
              </tr>

              <tr>
                <th>About Us SubTitle</th>
                <td><?php echo e($data->about_subtitle); ?></td>
              </tr>
              
               <tr>
                <th>About Us Description</th>
                <td><?php echo $data->about_des; ?></td>
              </tr>
              
    <tr>
                <th>About Us Description2</th>
                <td><?php echo $data->about_des2; ?></td>
              </tr>
    


     <tr>
                <th>About Us Image</th>
                <td>            
<a href="<?php echo e(url('uploads/about/'.$data->about_img)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(url('uploads/about/'.$data->about_img)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;">
</a>
</td>
              </tr>

           
          </thead>
          </table>
        </div>


			</div>
            </div>
          </div>     
          </div>
          	</div>  
            
	 
	

            <?php $__env->stopSection(); ?>



<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/admin/about/index.blade.php ENDPATH**/ ?>