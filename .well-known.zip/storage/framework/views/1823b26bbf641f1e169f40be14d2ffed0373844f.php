
<?php $__env->startSection('content'); ?>



<section>
    <div class="container">
        <h4>Privacy Policy</h4>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/privacy_policy.blade.php ENDPATH**/ ?>