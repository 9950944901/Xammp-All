
<?php $__env->startSection('contant'); ?>



				

    <div class="container-fluid">

	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> System Setting</div>
			     <div class="card-body">
				    <form method="POSt" action="admin/updatewebsetting" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<input type="hidden" name="id" value="<?php echo e($upadates['id']); ?>">
					 <!--   <div class="form-group row">-->
						<!--  <label for="basic-input" class="col-sm-3 col-form-label">Company Name</label>-->
						<!--  <div class="col-sm-9">-->
						<!--	<div class="input-group mb-3">-->
                            
						<!--		<input type="text" class="form-control" value="<?php echo e($upadates['companynames']); ?>" name="companynames" placeholder="some text" value="">-->
						<!--	  </div>-->
                             
						<!--  </div>-->
						<!--</div>-->
					
						
						<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Email</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
							<input type="email" class="form-control" value="<?php echo e($upadates['email']); ?>" name="email" placeholder="Enter email" >
						  </div>
                         
						  </div>
						</div>
						
						<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Mobile Number</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<input type="text" class="form-control" name="mobile" placeholder="Enter Mobile Number" value="<?php echo e($upadates['mobile']); ?>">
							  </div>
                            
						  </div>
						</div>

      <!--                  <div class="form-group row">-->
						<!--  <label for="basic-input" class="col-sm-3 col-form-label">Tagline</label>-->
						<!--  <div class="col-sm-9">-->
						<!--	<div class="input-group mb-3">-->
						<!--		<textarea type="textarea" class="form-control" name="tagline" placeholder="some text"><?php echo e($upadates['tagline']); ?></textarea>-->
						<!--	  </div>-->
						<!--  </div>-->
						<!--</div>-->
						
						<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Address</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="text" class="form-control" name="address" value="" placeholder="Enter Address"><?php echo e($upadates['address']); ?></textarea>
							  </div>
						  </div>
						</div>
						
						<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Logo</label>
						  <div class="col-sm-9">
                          <div class="col-sm-3">
<P> <span><input type="file" name="logo" class="form-control" autocomplete="nope" ></span></P>
<input type="hidden" name="logohidden" value="<?php echo e($upadates['logo']); ?>">
<a href="<?php echo e(url('/uploads/system_setting/'.$upadates->logo)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(('../uploads/system_setting/'.$upadates->logo)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 70px; height: 35px;"></a>
</div>
						  </div>
						</div>
						
						<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Favicon</label>
						  <div class="col-sm-9">
                          <div class="col-sm-3">
<P> <span><input type="file" name="favicon" class="form-control" autocomplete="nope" ></span></P>
<input type="hidden" name="faviconhidden" value="<?php echo e($upadates['favicon']); ?>">
<a href="<?php echo e(url('/uploads/system_setting/'.$upadates->favicon)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(('../uploads/system_setting/'.$upadates->favicon)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 70px; height: 35px;"></a>
</div>
						  </div>
						</div>
						
						<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Footer Logo</label>
						  <div class="col-sm-9">
                          <div class="col-sm-3">
<P> <span><input type="file" name="footerlogo" class="form-control" autocomplete="nope" ></span></P>
<input type="hidden" name="footerlogohidden" value="<?php echo e($upadates['footerlogo']); ?>">
<a href="<?php echo e(url('/uploads/system_setting/'.$upadates->footerlogo)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(('../uploads/system_setting/'.$upadates->footerlogo)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 70px; height: 35px;"></a>
</div>
						  </div>
						</div>
					
						
<!--                        <div class="form-group row">-->
<!--                        <label for="basic-input" class="col-sm-3 col-form-label">AboutUs Images</label>-->
<!--                        <div class="col-sm-9">-->
<!--                        <div class="col-sm-3">-->
<!--<P> <span>-->
<!--    <input type="file" name="Aboutimg[]" class="form-control" autocomplete="nope" multiple="multiple"></span></P>-->
<!--     <?php $__currentLoopData = json_decode($upadates->Aboutimg, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media_gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
<!--<input type="hidden" name="Aboutimghidden" value="<?php echo e($upadates['Aboutimg']); ?>">-->
<!--<a href="<?php echo e(url('/uploads/system_setting/'.$media_gallery)); ?>" data-fancybox="images" data-caption="This image has a caption">-->
<!--<img src="<?php echo e(('../uploads/system_setting/'.$media_gallery)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 70px; height: 35px;"></a>-->
<!--<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
<!--</div>-->
<!--                        </div>-->
<!--                        </div>-->
	
		<!--				<div class="form-group row">-->
		<!--				  <label for="basic-input" class="col-sm-3 col-form-label">AboutUs title</label>-->
		<!--				  <div class="col-sm-9">-->
		<!--					<div class="input-group mb-3">-->
		<!--						<textarea type="text" class="form-control" name="abouttitle" placeholder="some text"><?php echo e($upadates['abouttitle']); ?></textarea>-->
		<!--					  </div>-->
		<!--				  </div>-->
		<!--				</div>-->

		<!--<div class="form-group row">-->
		<!--				  <label for="basic-input" class="col-sm-3 col-form-label">Aboutus Description</label>-->
		<!--				  <div class="col-sm-9">-->
		<!--					<div class="input-group mb-3">-->
		<!--						<textarea name="editor" ><?php echo e($upadates['Description']); ?></textarea>-->
		<!--					  </div>-->
		<!--				  </div>-->
		<!--				</div>-->
						
						
						
							<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Facebook</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="text" class="form-control" name="facebook" placeholder="some url"><?php echo e($upadates['facebook']); ?></textarea>
							  </div>
						  </div>
						</div>
						
							<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Instagram</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="text" class="form-control"  name="instagram" placeholder="some url"><?php echo e($upadates['instagram']); ?></textarea>
							  </div>
						  </div>
						</div>
						
							<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Twitter</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="text" class="form-control"  name="twitter" placeholder="some url"/><?php echo e($upadates['twitter']); ?></textarea>
							  </div>
						  </div>
						</div>
							<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Pinterest</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="text" class="form-control" name="Pinterest" placeholder="some url"><?php echo e($upadates['pinterest']); ?></textarea>
							  </div>
						  </div>
						</div>
                        <div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Linkdin</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="text" class="form-control"  name="linkdin" placeholder="some url"><?php echo e($upadates['linkdin']); ?></textarea>
							  </div>
						  </div>
						</div>
						
						<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Youtube</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="text" class="form-control"  name="youtube" placeholder="some url"><?php echo e($upadates['youtube']); ?></textarea>
								<div class="input-group-append">
							  </div>
						  </div>
						</div>
						
						
						 <label for="basic-input" class="col-sm-3 col-form-label">Iframe</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="text" class="form-control"  name="iframe" placeholder="some url"><?php echo e($upadates['iframe']); ?></textarea>
								<div class="input-group-append">
							  </div>
						  </div>
						</div>
						
						</div>
<p class="text-center"><button type="submit" value="submit"  class="btn btn-success" name="submit">Update</button></p>

					</form>
		   
	    </div>
        </div>
							
					


   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
<?php $__env->stopSection(); ?>



<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/admin/updatewebsetting.blade.php ENDPATH**/ ?>