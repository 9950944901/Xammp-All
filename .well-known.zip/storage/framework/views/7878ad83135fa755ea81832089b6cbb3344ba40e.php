
<?php $__env->startSection('content'); ?>


<section id="hero_in" class="general" style="background-image:url(<?php echo e(asset('frontend/img_skill/faqbg.jpeg')); ?>)">
			<div class="wrapper">
				<div class="container">
				
				</div>
			</div>
</section>  
<section>
    <div class="faq_main" style="background-image:url('<?php echo e(asset('frontend/img_skill/screencapturefaq.png')); ?>');  background-repeat: no-repeat; background-position: left bottom 50px;">
    <div class="container">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <div class="accordion" id="accordionExample">
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingOne">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    What is FAQ?
                  </button>
                </h2>
                <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                  <div class="accordion-body">
                      FAQ (stands for Frequently Asked Questions) is a section of a company’s website dedicated to answering customers’ most common questions and concerns. FAQ pages
                      aim to make finding answers easy for customers, ideally without any need for outside assistance from a company’s representative. For e-commerce businesses,
                      FAQs mostly cover the company’s rules and policies about order changes, payments, shipping, returns, and refunds. For SaaS businesses, FAQ’s page design mainly
                      serves to guide customers on installing, using the product and troubleshooting common issues. 
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingTwo">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                   What is FAQ?
                  </button>
                </h2>
                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                  <div class="accordion-body">
                       FAQ (stands for Frequently Asked Questions) is a section of a company’s website dedicated to answering customers’ most common questions and concerns. FAQ pages
                      aim to make finding answers easy for customers, ideally without any need for outside assistance from a company’s representative. For e-commerce businesses,
                      FAQs mostly cover the company’s rules and policies about order changes, payments, shipping, returns, and refunds. For SaaS businesses, FAQ’s page design mainly
                      serves to guide customers on installing, using the product and troubleshooting common issues. 
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingThree">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                    What is FAQ?
                  </button>
                </h2>
                <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                  <div class="accordion-body">
                       FAQ (stands for Frequently Asked Questions) is a section of a company’s website dedicated to answering customers’ most common questions and concerns. FAQ pages
                      aim to make finding answers easy for customers, ideally without any need for outside assistance from a company’s representative. For e-commerce businesses,
                      FAQs mostly cover the company’s rules and policies about order changes, payments, shipping, returns, and refunds. For SaaS businesses, FAQ’s page design mainly
                      serves to guide customers on installing, using the product and troubleshooting common issues.
                  </div>
                </div>
              </div>
              
              
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingfour">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                   What is FAQ?
                  </button>
                </h2>
                <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingfour" data-bs-parent="#accordionExample">
                  <div class="accordion-body">
                       FAQ (stands for Frequently Asked Questions) is a section of a company’s website dedicated to answering customers’ most common questions and concerns. FAQ pages
                      aim to make finding answers easy for customers, ideally without any need for outside assistance from a company’s representative. For e-commerce businesses,
                      FAQs mostly cover the company’s rules and policies about order changes, payments, shipping, returns, and refunds. For SaaS businesses, FAQ’s page design mainly
                      serves to guide customers on installing, using the product and troubleshooting common issues.
                  </div>
                </div>
              </div>
              
               <div class="accordion-item">
                <h2 class="accordion-header" id="headingfive">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsefive" aria-expanded="false" aria-controls="collapsefive">
                    What is FAQ?
                  </button>
                </h2>
                <div id="collapsefive" class="accordion-collapse collapse" aria-labelledby="headingfive" data-bs-parent="#accordionExample">
                  <div class="accordion-body">
                       FAQ (stands for Frequently Asked Questions) is a section of a company’s website dedicated to answering customers’ most common questions and concerns. FAQ pages
                      aim to make finding answers easy for customers, ideally without any need for outside assistance from a company’s representative. For e-commerce businesses,
                      FAQs mostly cover the company’s rules and policies about order changes, payments, shipping, returns, and refunds. For SaaS businesses, FAQ’s page design mainly
                      serves to guide customers on installing, using the product and troubleshooting common issues.
                  </div>
                </div>
              </div>
              
              
              
            </div>
            </div>
            <div class="col-md-2"></div>
        </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/faq.blade.php ENDPATH**/ ?>