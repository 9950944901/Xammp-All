<style>

input[type="search"]::-webkit-search-cancel-button {
  display: none;
}
.top_header{
    background: linear-gradient(to right,#480048,#c04848);
}
.Have_any_question{
    color:white;
     font-family: 'Poppins';
}
.header_section_class_first{
    background: black;
    padding-top: 6px;
    padding-bottom: 1px;
    width: 100%;
}
    .header_navbar_list_div_1{
            width: 60%;
            float: left;
            padding-left: 52px;
            padding-top: 14px;
    }
       .header_navbar_list_div_1 ul{
           display: -webkit-box;
    }
.header_navbar_list_div_1 ul li{
          
    }
    
    .header_navbar_list_div_1 ul li a{
     padding-left: 49px;
    color: white;
    font-family: 'Poppins';
              
    }
   .header_navbar_list_div_2{
           padding-top: 15px;
   } 
      .header_navbar_list_div_2 ul{
       display: flex;
    align-items: center;
    justify-content: end;
   } 
        .header_navbar_list_div_2 ul li{
           padding-right: 34px;
   } 
           .header_navbar_list_div_2 ul li a{
        color:white;
         font-family: 'Poppins';
   } 
  
   .user_skilluva ul.dropdown-menu {
    left: -125px;
}

.user_skilluva ul.dropdown-menu.show {
    z-index: 9999999 !important;
}
   @media(max-width:767px){
           .header_navbar_list_div_1{
            width: 60%;
            float: left;
            padding-left: 52px;
            padding-top: 14px;
            display: none;
    }
       .user_skilluva ul.dropdown-menu {
    left: 0px;
}



   }
   
/*   .hamburger-box {*/
/*    width: 30px;*/
/*    height: 24px;*/
/*    display: inline-block;*/
/*    position: relative;*/
/*    top: 51px;*/
/*    background: #fff;*/
/*}*/
</style>












<?php

$da = App\Models\websetting::first();

?>

   


<section class="top_header newpost">
    <nav class="navbar navbar-expand-sm navbar-dark">
  <div class="container-fluid">
    <ul class="navbar-nav question">
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('FAQs')); ?>">Have any question?</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="tel://8769955456"><span><i class="fa fa-phone" aria-hidden="true"></i></span>&nbsp <?php echo e($da->mobile); ?></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="mailto:support@skilluva.com"><span><i class="fa fa-envelope-o" aria-hidden="true"></i></span>&nbsp <?php echo e($da->email); ?></a>
      </li>
    </ul>
    
    <ul class="navbar-nav">
        
        <div class="dropdown user_skilluva">
            <!--<p class="text-white">For Login & Registration</p>-->
          <button type="button" class="btn btn-outline-primary dropdown-toggle btn_outline_new" data-bs-toggle="dropdown">
            <i class="fa fa-user-circle-o" aria-hidden="true"></i>
          </button>
          
        
          <ul class="dropdown-menu header_bar">
              <?php if(session()->has('FRONT_USER_LOGIN')==null): ?>
            <li><a class="dropdown-item" href="<?php echo e(url('register')); ?>">Register</a></li>
            <li><a class="dropdown-item" href="<?php echo e(url('login')); ?>">Login</a></li>
             	<?php else: ?>
						<?php endif; ?>
						
						
						 <?php
                        
                        $user_role = session()->get('FRONT_USER_TYPE');
                      
                        ?>
                        <?php if($user_role): ?>
                            <?php if($user_role == 'Trainer'): ?>
            <li><a class="dropdown-item" href="<?php echo e(url('teacher-profile')); ?>">Trainer Dashboard</a></li>
            <li><a class="dropdown-item" href="<?php echo e(url('logout')); ?>">Logout</a></li>
            <?php else: ?>
             <li><a class="dropdown-item" href="<?php echo e(url('student-profile')); ?>">Learner Dashboard</a></li>
             <li><a class="dropdown-item" href="<?php echo e(url('logout')); ?>">Logout</a></li>
             <?php endif; ?>
			<?php endif; ?>
          </ul>
        </div>
        
    </ul>
    
  
  </div>
</nav>
</section>


<header class="header menu_2 ">
<div class="bg_wihte_skillnav">
		<div id="preloader"><div data-loader="circle-side"></div></div><!-- /Preload -->
		<div id="logo">
			<a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('uploads/system_setting/'.$da->logo)); ?>" width="149" height="42" alt=""></a>
		</div>
		<ul  id="top_menu" >
		     <!--id="top_menu"-->
			<!--<li><a href="<?php echo e(url('login')); ?>" class="login">Login</a>-->
			
			<!--		</li>-->
			<li><a href="#0" class="search-overlay-menu-btn">Search</a></li>
		
		</ul>
		<!-- /top_menu -->
		<a href="#menu" class="btn_mobile btn_mobile_hide_moile but_none" id="hide">
			<div class="hamburger hamburger--spin" id="hamburger">
				<div class="hamburger-box">
					<div class="hamburger-inner"></div>
				</div>
			</div>
		</a>
		<nav id="menu" class="main-menu main_menuindex">
			<ul>
				<li class="nav_link"><span><a href="<?php echo e(url('/')); ?>" class="nav_item_teb">Home</a></span>
					<!--<ul>-->
					<!--	<li><a href="index-2.html">Home Default</a></li>-->
					<!--	<li><a href="index-3.html">Home Video Bg</a></li>-->
					<!--	<li><a href="index-6.html">Home Flexslider</a></li>-->
					<!--	<li><a href="index-4.html">Home Layer Slider</a></li>-->
					<!--	<li><a href="index-5.html">Home FullScreen</a></li>-->
					<!--	<li><a href="index-7.html">Home Parallax Video</a></li>-->
					<!--	<li><a href="index-8.html">With Cookie bar (EU law)</a></li>-->
					<!--</ul>-->
				</li>
				<li class="nav_link"><span><a href="<?php echo e(url('about-us')); ?>" target="_parent" class="nav_item_teb">About Us</a></span></li>
				<li class="nav_link"><span><a href="javascript:;">Courses</a></span>
					<ul class="dropdown dropend">
						<li class="nav_link dropdown dropend"><a href="<?php echo e(url('basic-course')); ?>" class="nav_item_teb nav_item_teb_sticky" data-bs-toggle="dropdown">foundational courses</a>
						
                        <ul class="dropdown-menu category_list_ul">
                          <li><a class="dropdown-item" href="<?php echo e(url('basic-course')); ?>">Foundational courses</a></li>
                        </ul>
						</li>
						<li class="nav_link dropdown dropend"><a href="<?php echo e(url('advanced-course')); ?>" class="nav_item_teb nav_item_teb_sticky" data-bs-toggle="dropdown">Aggregate courses</a>
						 <ul class="dropdown-menu category_list_ul">
                          <li><a class="dropdown-item" href="<?php echo e(url('advanced-course')); ?>">Aggregate courses</a></li>
                          
                        </ul>
						
						</li>
						<!--<li><a href="courses-list.html">Courses list</a></li>-->
						<!--<li><a href="courses-list-sidebar.html">Courses list sidebar</a></li>-->
						<!--<li><a href="course-detail.html">Course detail</a></li>-->
      <!--                  <li><a href="course-detail-2.html">Course detail working form</a></li>-->
						<!--<li><a href="admission.html">Admission wizard</a></li>-->
						<!--<li><a href="teacher-detail.html">Teacher detail</a></li>-->
					</ul>
				</li>
				<li class="nav_link"><span><a href="<?php echo e(url('training_material')); ?>" class="nav_item_teb"> Find Trainers</a></span>
					<!--<ul>-->
					<!--	<li><a href="<?php echo e(url('training_material')); ?>">Training Material</a></li>-->
						<!--<li><a href="about.html">Games and Activities</a></li>-->
					<!--</ul>-->
				</li>
				<li class="nav_link"><span><a href="<?php echo e(url('ebook')); ?>" class="nav_item_teb">eBook Library</a></span>
					<!--<ul>-->
					<!--	<li><a href=>eBooks Combo</a></li>-->
					<!--</ul>-->
				</li>
				
				<!--<li><span><a href="javascript:;">Events</a></span>-->
				<!--	<ul>-->
				<!--		<li><a href="menu_2/index.html">Personalized Coaching</a></li>-->
				<!--	</ul>-->
				<!--</li>-->
				<!--<li><span><a href="#0">Pages</a></span>-->
				<!--	<ul>-->
				<!--		<li><a href="menu_2/index.html">Menu 2</a></li>-->
				<!--		<li><a href="about.html">About</a></li>-->
				<!--		<li><a href="blog.html">Blog</a></li>-->
				<!--		<li><a href="login.html">Login</a></li>-->
				<!--		<li><a href="register.html">Register</a></li>-->
				<!--		<li><a href="contacts.html">Contacts</a></li>-->
				<!--		<li><a href="404.html">404 page</a></li>-->
				<!--		<li><a href="agenda-calendar.html">Agenda Calendar</a></li>-->
				<!--		<li><a href="faq.html">Faq</a></li>-->
				<!--		<li><a href="help.html">Help</a></li>-->
				<!--	</ul>-->
				<!--</li>-->
				<!--<li><span><a href="#0">Blog</a></span>-->
				<!--	<ul>-->
				<!--		<li><a href="media-gallery.html">Self development</a></li>-->
				<!--		<li><a href="admin_section/index.html" target="_blank">Business and management</a></li>-->
				<!--		<li><a href="cart-1.html">Social welfare</a></li>-->
				<!--		<li><a href="cart-2.html">Technology</a></li>-->
				<!--		<li><a href="cart-3.html">Miscellaneous</a></li>-->
				<!--	</ul>-->
				<!--</li>-->
				<li class="nav_link"><span><a href="<?php echo e(url('contact')); ?>" target="_parent" class="nav_item_teb"  >Support</a></span></li>
					
				<li class="nav_link desktop_none_user"><span><a href="#0"><i class="fa fa-user-circle-o" style="font-size:16px;" aria-hidden="true"></i></a></span>
					<ul>
					    <?php if(session()->has('FRONT_USER_LOGIN')==null): ?>
						<li class="nav_link"><a href="<?php echo e(url('login')); ?>" class="nav_item_teb">Login</a></li>
						<li class="nav_link"><a href="<?php echo e(url('register')); ?>" target="_blank" class="nav_item_teb">Register</a></li>
						<?php else: ?>
						<?php endif; ?>
						
						
						 <?php
                        
                        $user_role = session()->get('FRONT_USER_TYPE');
                      
                        ?>
                        <?php if($user_role): ?>
                            <?php if($user_role == 'Trainer'): ?>
						<li class="nav_link"><a href="<?php echo e(url('teacher-dashboard')); ?>" class="nav_item_teb">Trainer Dashboard</a></li>
												<li class="nav_link"><a href="<?php echo e(url('logout')); ?>" class="nav_item_teb">Logout</a></li>
<?php else: ?>
		<li class="nav_link"><a href="<?php echo e(url('student-dashboard')); ?>" class="nav_item_teb">Student Dashboard</a></li>
																		<li class="nav_link"><a href="<?php echo e(url('logout')); ?>" class="nav_item_teb">Logout</a></li>
						<?php endif; ?>
						<?php endif; ?>
					</ul>
				</li>
				<?php if(session()->has('FRONT_USER_LOGIN')==!null): ?>
             <?php
              $user_id = session()->get('FRONT_USER_ID');
             $cart_count = \App\Models\Cart::where('user_id',$user_id)->count();
             ?>

				<li class="nav_link"><span><a href="<?php echo e(url('cartlist')); ?>"><i class="icon-basket-1 nav_item_teb" style="font-size:16px;" aria-hidden="true"><sup class="counting"><?php echo e($cart_count); ?></sup></i></a></span></li>
		     <?php else: ?>
		     <li class="nav_link"><span><a href="<?php echo e(url('login')); ?>"><i class="icon-basket-1 nav_item_teb" style="font-size:16px;" aria-hidden="true"><sup class="counting">0</sup></i></a></span></li>
		     <?php endif; ?>
			</ul>
		</nav>
		<!-- Search Menu -->
		<!--<div class="search-overlay-menu">-->
		<!--	<span class="search-overlay-close"><span class="closebt"><i class="ti-close"></i></span></span>-->
		<!--	<form role="search" id="searchform" method="get" action="<?php echo e(url('/course-search')); ?>">-->
		<!--		<input value="" name="search" type="search" placeholder="Search..." />-->
		<!--		<button type="submit"><i class="icon_search"></i>-->
		<!--		</button>-->
		<!--	</form>-->
		<!--</div>-->
		
		</div>
	</header>
	<?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/header.blade.php ENDPATH**/ ?>