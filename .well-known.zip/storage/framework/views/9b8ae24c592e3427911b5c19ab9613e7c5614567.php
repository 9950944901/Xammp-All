<?php $__env->startSection('page_title','Banners'); ?>
<?php $__env->startSection('contant'); ?>



<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header text-uppercase">Update Banners</div>
<div class="card-body">
<form method="POSt" action="update_banner" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="form-group row">

<input type="hidden" name="id" value="<?php echo e($data->id); ?>" />


<label for="basic-input" class="col-sm-2 col-form-label">Home Banner Title 1<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($data['home_banner_title_1']); ?>" name="home_banner_title_1" placeholder="Enter Home Banner Title 1" value="">
</div>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Home Banner Title 2<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($data['home_banner_title_2']); ?>" name="home_banner_title_2" placeholder="Enter Home Banner Title 2 value">
</div>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Home Banner Title 3<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($data['home_banner_title_3']); ?>" name="home_banner_title_3" placeholder="Enter Home Banner Title 3" value="">
</div>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Home Banner Image<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="file" class="form-control" value="<?php echo e($data['home_banner']); ?>" name="home_banner" placeholder="Enter Course Title" value="">
<img src="<?php echo e(url('uploads/banners/home_banner/'.$data['home_banner'])); ?>" width="70" />
</div>
</div>


<label for="basic-input" class="col-sm-2 col-form-label">About Banner Title<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($data['about_banner_title']); ?>" name="about_banner_title" placeholder="Enter About Banner Title" value="">
</div>
</div>


<label for="basic-input" class="col-sm-2 col-form-label">About Banner Image<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="file" class="form-control" value="<?php echo e($data['about_banner']); ?>" name="about_banner" placeholder="Enter About Banner Title" value="">
<img src="<?php echo e(url('uploads/banners/about_banner/'.$data['about_banner'])); ?>" width="70" />

</div>
</div>


<label for="basic-input" class="col-sm-2 col-form-label">Foundational Banner Title<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($data['foundational_banner_title']); ?>" name="foundational_banner_title" placeholder="Enter foundational Banner Title" value="">
</div>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Foundational Banner Image<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="file" class="form-control" value="<?php echo e($data['foundational_banner']); ?>" name="foundational_banner" placeholder="Enter Foundational Banner Image" value="">
<img src="<?php echo e(url('uploads/banners/foundational_banner/'.$data['foundational_banner'])); ?>" width="70" />

</div>
</div>



<label for="basic-input" class="col-sm-2 col-form-label">Accredited Banner Title<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($data['accredited_banner_title']); ?>" name="accredited_banner_title" placeholder="Enter Accredited Banner Title" value="">
</div>
</div>


<label for="basic-input" class="col-sm-2 col-form-label">Accredited Banner Image<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="file" class="form-control" value="<?php echo e($data['accredited_banner']); ?>" name="accredited_banner" placeholder="Enter Accredited Banner Title" value="">
<img src="<?php echo e(url('uploads/banners/accredited_banner/'.$data['accredited_banner'])); ?>" width="70" />

</div>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Trainer Banner Title<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($data['trainer_banner_title']); ?>" name="trainer_banner_title" placeholder="Enter Trainer Banner Title" value="">
</div>
</div>



<label for="basic-input" class="col-sm-2 col-form-label">Trainer Banner Image<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="file" class="form-control" value="<?php echo e($data['trainer_banner']); ?>" name="trainer_banner" placeholder="Enter Trainer Banner Title" value="">
<img src="<?php echo e(url('uploads/banners/trainer_banner/'.$data['trainer_banner'])); ?>" width="70" />

</div>
</div>



<label for="basic-input" class="col-sm-2 col-form-label">Ebook Banner Title<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($data['ebookbanner_title']); ?>" name="ebookbanner_title" placeholder="Ebook Trainer Banner Title" value="">
</div>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Ebook Banner Image<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="file" class="form-control" value="<?php echo e($data['ebookbanner']); ?>" name="ebookbanner" placeholder="Ebook Trainer Banner Title" value="">
<img src="<?php echo e(url('uploads/banners/ebookbanner/'.$data['ebookbanner'])); ?>" width="70" />

</div>
</div>



<label for="basic-input" class="col-sm-2 col-form-label">Support Banner Title<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($data['support_banner_title']); ?>" name="support_banner_title" placeholder="Ebook Support Banner Title" value="">
</div>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Support Banner Image<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="file" class="form-control" value="<?php echo e($data['support_banner']); ?>" name="support_banner" placeholder="Ebook Support Banner Title" value="">
<img src="<?php echo e(url('uploads/banners/support_banner/'.$data['support_banner'])); ?>" width="70" />

</div>
</div>


</div>





<p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>

</form>
</div>
</div>
</div>
</div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/admin/banner/edit.blade.php ENDPATH**/ ?>