<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="Ansonika">
    <title>Skilluva</title>

    <!-- Favicons-->
    <link rel="shortcut icon" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>">

    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&amp;display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="<?php echo e(URL::asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('frontend/css/style.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(URL::asset('frontend/css/vendors.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(URL::asset('frontend/css/icon_fonts/css/all_icons.min.css')); ?>" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="<?php echo e(URL::asset('frontend/css/custom.css')); ?>" rel="stylesheet">

</head>

<body id="register_bg">
	
	<nav id="menu" class="fake_menu"></nav>
	
	<div id="preloader">
		<div data-loader="circle-side"></div>
	</div>
	<!-- End Preload -->
	
	<div id="login">
		<aside>
			<figure>
				<a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(URL::asset('frontend/img_skill/logo_skill.png')); ?>" width="149" height="42" alt=""></a>
			</figure>
			<form autocomplete="off" id="frmRegistration" method="post">
			    <?php echo csrf_field(); ?>
				<div class="form-group">

					<span class="input">
					<input class="input_field" type="text" name="fname">

						<label class="input_label">
						<span class="input__label-content">Your Name</span>
					</label>

					</span>
				<div id="fname_error" class="field_error" style="color:red;"></div>

					<span class="input">
					<input class="input_field" type="text" name="lname">
						<label class="input_label">
						<span class="input__label-content">Your Last Name</span>
					</label>
					</span>
				<div id="lname_error" class="field_error" style="color:red;"></div>

					<span class="input">
					<input class="input_field" type="email" name="email">
						<label class="input_label">
						<span class="input__label-content">Your Email</span>
					</label>
					</span>
									<div id="email_error" class="field_error" style="color:red;"></div>

		<!--<span class="input">-->
		<!--			<input class="input_field" type="number" name="mobile">-->
		<!--				<label class="input_label">-->
		<!--				<span class="input__label-content">Your Mobile Number</span>-->
		<!--			</label>-->
		<!--			</span>-->
									<div id="mobile_error" class="field_error" style="color:red;"></div>

					
					<span class="input input_filed_mian">
						<select class="input_field"  name="type">
					    <option value=""></option>
					    <option value="Learner">Learner</option>
					    <option value="Trainer">Trainer</option>

					    
					</select>
						<label class="input_label">
						<!--<span class="input__label-content">-->
						    User Type
						    <!--</span>-->
					</label>
					</span>
				<div id="type_error" class="field_error" style="color:red;"></div>

	<!--<span class="input">-->
	<!--					<select class="input_field " name="country">-->
	<!--				    <option value=""></option>-->
	<!--				    <option value="India">India</option>-->
	<!--				    <option value="usa">Usa</option>-->

					    
	<!--				</select>-->
	<!--					<label class="input_label">-->
	<!--					<span class="input__label-content">Country</span>-->
	<!--				</label>-->
	<!--				</span>-->
	<!--			<div id="country_error" class="field_error" style="color:red;"></div>-->


	<!--<span class="input">-->
	<!--					<select class="input_field " name="state">-->
	<!--				    <option value=""></option>-->
	<!--				    <option value="India">Rajasthan</option>-->
	<!--				    <option value="usa">los</option>-->

					    
	<!--				</select>-->
	<!--					<label class="input_label">-->
	<!--					<span class="input__label-content">State</span>-->
	<!--				</label>-->
	<!--				</span>-->
	<!--			<div id="state_error" class="field_error" style="color:red;"></div>-->



	<!--<span class="input">-->
	<!--					<select class="input_field " name="city">-->
	<!--				    <option value=""></option>-->
	<!--				    <option value="India">Jaipur</option>-->
	<!--				    <option value="usa">los</option>-->

					    
	<!--				</select>-->
	<!--					<label class="input_label">-->
	<!--					<span class="input__label-content">City</span>-->
	<!--				</label>-->
	<!--				</span>-->
				<div id="city_error" class="field_error" style="color:red;"></div>
					<span class="input">
					<input class="input_field" type="password" id="password1" name="password">
						<label class="input_label">
						<span class="input__label-content">Your password</span>
					</label>
					</span>
				<div id="password_error" class="field_error" style="color:red;"></div>

					<span class="input">
					<input class="input_field" type="password" id="password2" name="cpassword">
						<label class="input_label">
						<span class="input__label-content">Confirm password</span>
					</label>
					</span>
									<div id="cpassword_error" class="field_error" style="color:red;"></div>

					<div id="pass-info" class="clearfix"></div>
				</div>
				<input  type="submit" class="btn_1 rounded full-width add_top_30" id="btnRegistration" value="Register to Skilluva">
				<div class="text-center add_top_10">Already have an acccount? <strong><a href="<?php echo e(url('login')); ?>">Sign In</a></strong></div>
			</form>
			<div class="copy">© 2022 Skilluva</div>
		</aside>
	</div>
	<!-- /login -->
	
	<!-- COMMON SCRIPTS -->
    <script src="<?php echo e(URL::asset('frontend/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('frontend/js/common_scripts.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('frontend/js/main.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('frontend/assets/validate.js')); ?>"></script>
	
	<!-- SPECIFIC SCRIPTS -->
	<script src="<?php echo e(URL::asset('frontend/js/pw_strenght.js')); ?>"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  <script>
      jQuery('#frmRegistration').submit(function(e){
  e.preventDefault();
  jQuery('.field_error').html('');
  jQuery.ajax({
    url:'register',
    data:jQuery('#frmRegistration').serialize(),
    type:'post',
    success:function(result){
      if(result.status=="error"){
        jQuery.each(result.error,function(key,val){
          jQuery('#'+key+'_error').html(val[0]);
        });
      }
      
      if(result.status=="success"){
        jQuery('#frmRegistration')[0].reset();
                jQuery('#thank_you_msg').html(result.msg);

       window.location.href='login'

      }
    }
  });
});
      
  </script>
  
  
</body>
</html><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/register.blade.php ENDPATH**/ ?>