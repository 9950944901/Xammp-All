

<?php $__env->startSection('content'); ?>


<style>

.active{
font-size: 14px;
background-image: linear-gradient(to right, rgb(218, 34, 255) 0%, rgb(151, 51, 238) 51%, rgb(218, 34, 255) 100%);

}


.inactive{
font-size: 14px;
background-image: linear-gradient(to right, rgb(255, 81, 47) 0%, rgb(240, 152, 25) 51%, rgb(255, 81, 47) 100%);
}

li{
    
    list-style:none;
}


</style>

<div class="page-wrapper">
<div class="page-content">


<div class="col-sm-12">
<div class="container-fluid">

<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header"></div>
<div class="card-body">
<div class="">
<div class="row">
             <div class="col-6">
      
            <h5>Course Detail</h5>
              
            <ul>
                <li>Course Detail</li>
                <li>Name: &nbsp;<SPAN><?php echo e(isset($ebookcourse->etitle) ? $ebookcourse->etitle:''); ?></SPAN></li>
                <li>Price : &nbsp; <span><?php echo e(isset($ebookcourse->eprice) ? $ebookcourse->eprice:''); ?></span></li>
            </ul>
      
    </div>

<table id="example2" class="table table-bordered" style="width:100%">
<thead>
<tr>
<th>Sr.No.</th>
<th>Pdf</th>
</tr>
</thead>
    
   
   
<tbody>


    <?php
        $i=1;
        $ebookpdf = json_decode($ebookcourse->ebook);
       
    ?>
        <?php $__currentLoopData = $ebookpdf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pdf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr role="row" class="odd">
            <td><?php echo e($i++); ?></td>
            <td><embed src="<?php echo e(url('/uploads/Ebook/ebook/',$pdf)); ?>" type="application/pdf" width="100%" height="600px"></td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>

<div class="d-flex justify-content-flex-end Pagination_1" >

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>







<style>

.w-5 {
display: none;
}

.h-5{
display: none;
}

</style>


<?php $__env->stopSection(); ?>
<?php echo $__env->yieldPushContent('footer_script'); ?>













<?php echo $__env->make('layouts.master_student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/studentdashboard/ebook/view.blade.php ENDPATH**/ ?>