
<?php $__env->startSection('content'); ?>


<style>

.active{
font-size: 14px;
background-image: linear-gradient(to right, rgb(218, 34, 255) 0%, rgb(151, 51, 238) 51%, rgb(218, 34, 255) 100%);

}


.inactive{
font-size: 14px;
background-image: linear-gradient(to right, rgb(255, 81, 47) 0%, rgb(240, 152, 25) 51%, rgb(255, 81, 47) 100%);
}


</style>

<div class="page-wrapper">
<div class="page-content">


<div class="col-sm-12">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<div class="card">
            <div class="card-body">
              
			<div class="table-responsive">
	          <table class="table table-bordered">
            <thead>

              
              
               <tr>
                <th>Course Title </th>
                <td><?php echo e($csview['ctitle']); ?></td>
              </tr>

              <tr>
                <th>Course MRP </th>
                <td>₹<?php echo e($csview->cmrp); ?></td>
              </tr>
              
               <tr>
                <th>Course Price </th>
                <td>₹<?php echo e($csview->cprice); ?></td>
              </tr>
              
                <tr>
                <th>Course Description </th>
                <td><?php echo e($csview->description); ?></td>
              </tr>

              <tr>
                <th>Course Image </th>
                <td>                    	        <img class="mb-3 w-25" style="height:100px;"src="<?php echo e(asset('uploads/advancecourse/image/'.$csview['image'])); ?>">
</td>
              </tr>


              <tr>
                <th>Course Video </th>
                <td>            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(url('uploads/trainer_course/video/'.$video->video)); ?>" data-fancybox="images" data-caption="This image has a caption">
<video src="<?php echo e(url('uploads/trainer_course/video/'.$video->video)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;" controls></video>
</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
              </tr>



             

    
			  
          </thead>
          </table>
        </div>


			</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('layouts.master_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/teacherdashboard/view_single_course.blade.php ENDPATH**/ ?>