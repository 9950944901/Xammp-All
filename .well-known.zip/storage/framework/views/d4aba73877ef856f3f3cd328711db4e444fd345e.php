
<?php $__env->startSection('content'); ?>

<main>
		<section id="hero_in" class="general">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span>blog</h1>
				</div>
			</div>
		</section>
		<!--/hero_in-->

		<div class="container margin_60_35">
			<div class="row">
				<div class="col-lg-9">
				      
			
                
               
				    
					<div class="bloglist singlepost">
						<p><img alt="" class="img-fluid" src="<?php echo e(url('uploads/blog_images/'.$data->blog_img)); ?>"></p>
						<h1><?php echo e($data->title); ?></h1>
						<div class="postmeta">
							<ul>
								<li><a href="#"><i class="icon_folder-alt"></i> Collections</a></li>
								<li><a href="#"><i class="icon_clock_alt"></i> 23/12/2015</a></li>
								<li><a href="#"><i class="icon_pencil-edit"></i> Admin</a></li>
								<li><a href="#"><i class="icon_comment_alt"></i> (14) Comments</a></li>
							</ul>
						</div>
						<!-- /post meta -->
						<div class="post-content">
							<div class="dropcaps">
								<p><?php echo e($data->description); ?>.</p>
							</div>

						</div>
						<!-- /post -->
					</div>
							
					
					<!-- /single-post -->

				<!---->
				</div>
				<!-- /col -->

				<aside class="col-lg-3">
					<div class="widget">
						<form>
							<div class="form-group">
								<input type="text" name="search" id="search" class="form-control" placeholder="Search...">
							</div>
							<button type="submit" id="submit" class="btn_1 rounded"> Search</button>
						</form>
					</div>
					<!-- /widget -->
					<div class="widget">
						<div class="widget-title">
							<h4>Recent Posts</h4>
						</div>
						<ul class="comments-list">
							<li>
								<div class="alignleft">
									<a href="<?php echo e(url('blog-details')); ?>"><img src="<?php echo e(URL::asset('frontend/img/blog-5.jpg')); ?>" alt=""></a>
								</div>
								<small>11.08.2016</small>
								<h3><a href="<?php echo e(url('blog-details')); ?>" title="">Verear qualisque ex minimum...</a></h3>
							</li>
							<li>
								<div class="alignleft">
									<a href="<?php echo e(url('blog-details')); ?>"><img src="<?php echo e(URL::asset('frontend/img/blog-6.jpg')); ?>" alt=""></a>
								</div>
								<small>11.08.2016</small>
								<h3><a href="<?php echo e(url('blog-details')); ?>" title="">Verear qualisque ex minimum...</a></h3>
							</li>
							<li>
								<div class="alignleft">
									<a href="<?php echo e(url('blog-details')); ?>"><img src="<?php echo e(URL::asset('frontend/img/blog-4.jpg')); ?>" alt=""></a>
								</div>
								<small>11.08.2016</small>
								<h3><a href="<?php echo e(url('blog-details')); ?>" title="">Verear qualisque ex minimum...</a></h3>
							</li>
						</ul>
					</div>
					<!-- /widget -->
					<div class="widget">
						<div class="widget-title">
							<h4>Blog Categories</h4>
						</div>
						<ul class="cats">
							<li><a href="#">Admissions <span>(12)</span></a></li>
							<li><a href="#">News <span>(21)</span></a></li>
							<li><a href="#">Events <span>(44)</span></a></li>
							<li><a href="#">Focus in the lab <span>(31)</span></a></li>
						</ul>
					</div>
					<!-- /widget -->
					<div class="widget">
						<div class="widget-title">
							<h4>Popular Tags</h4>
						</div>
						<div class="tags">
							<a href="#">Information tecnology</a>
							<a href="#">Students</a>
							<a href="#">Community</a>
							<a href="#">Carreers</a>
							<a href="#">Literature</a>
							<a href="#">Seminars</a>
						</div>
					</div>
					<!-- /widget -->
				</aside>
				<!-- /aside -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</main>
	<!--/main-->
	
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/blog_details.blade.php ENDPATH**/ ?>