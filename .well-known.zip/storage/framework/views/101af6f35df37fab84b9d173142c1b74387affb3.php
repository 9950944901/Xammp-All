
<?php $__env->startSection('page_title','Course'); ?>
<?php $__env->startSection('contant'); ?>


			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Course</div>
			     <div class="card-body">
				    <form method="POSt" action="update_course" class="form-horizontal" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            
                            <input type="hidden" value="<?php echo e($cview['id']); ?>" name="id"/>
					    <div class="form-group row">
						  
						  		  <label for="basic-input" class="col-sm-2 col-form-label">Course Title<span style="color:red;">*</span></label>
						  	  <div class="col-sm-10">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e($cview['title']); ?>" name="title" placeholder="Enter Course Title" value="">
							  </div>
						  </div>
						  
						  
						  
						  
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Course Category<span style="color:red;">*</span></label>
    						    <div class="col-sm-4">
    							<div class="input-group mb-3">
                                   <select class="form-select form-control mb-2 single-select " id="catagory" name="catagory" aria-label="Default select example" >
                                        <option value="">--Select Course Categroy type--</option>
                                        <?php $__currentLoopData = $categoryslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $settingees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  value = "<?php echo e($settingees->id); ?>" <?php echo e($settingees->id == $cview->catagory ? 'selected' : ''); ?>><?php echo e($settingees->categroy); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <p style="color:red;"><?php $__errorArgs = ['catagory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </select>							  
                                </div>
                                <p style="color:red;"><?php $__errorArgs = ['subcategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
    						  </div>
    						  
    						  
    						  
    						  
    						  <label for="basic-input" class="col-sm-2 col-form-label">Course SubCategory<span style="color:red;">*</span></label>
    						    <div class="col-sm-4">
    							<div class="input-group mb-3">
                                    <select id="subcategory" class="form-control" name="subcategory">
                                        <option value="">--Select Course Subcategroy type--</option>
                                        <?php $__currentLoopData = $subcategoryslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $settingees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <option  value = "<?php echo e($settingees->id); ?>" <?php echo e($settingees->id == $cview->subcategory ? 'selected' : ''); ?>><?php echo e($settingees->sub_categroy); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>							  
                                </div>
                                <p style="color:red;"><?php $__errorArgs = ['subcategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
    						  </div>
						  
						  
						  	  <label for="basic-input" class="col-sm-12 col-form-label">Course Video<span style="color:red;">*</span></label>
						  	  <div class="col-sm-12">
							<div class="input-group mb-3">
                            
								<input type="file" class="form-control" value="<?php echo e($cview['video']); ?>" name="video[]" placeholder="Enter Course Title" value="" multiple>
							  </div>
						 <?php $__currentLoopData = json_decode($cview->video, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media_gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(url('uploads/Foundational_course/video/'.$media_gallery)); ?>" data-fancybox="images" data-caption="This image has a caption">
<video src="<?php echo e(url('uploads/Foundational_course/video/'.$media_gallery)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;" controls></video>
</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						  </div>
						  
						  </div>
						  <div class="form-group row">
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Image<span style="color:red;">*</span></label>
						  	  <div class="col-sm-12">
								<div class="input-group mb-3">
                            
								<input type="file" class="form-control" value="<?php echo e($cview['image']); ?>" name="image" placeholder="Enter Course MRP" value="">
							
		
							  </div>
							  <?php if($cview->image): ?>
                    	        <img class="mb-3 w-25" style="height:100px;"src="<?php echo e(asset('uploads/Foundational_course/image/'.$cview->image)); ?>">
                            <?php endif; ?>
                              
						  </div>
						  </div>
						 
						 	  <label for="basic-input" class="col-sm-2 col-form-label">Course MRP</label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e($cview['mrp']); ?>" name="mrp" placeholder="Enter Course MRP" value="">
							  </div>
						  </div>
						  
						  	  		  <label for="basic-input" class="col-sm-2 col-form-label">Course Price</label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e($cview['price']); ?>" name="price" placeholder="Enter Course Price" value="">
							  </div>
						  </div>

						    <div class="form-group row">
						  
						  <label for="basic-input" class="col-sm-12 col-form-label">Course Description<span style="color:red;">*</span></label>
						  	  <div class="col-sm-12">
							<div class="input-group mb-3">
                            
								<textarea type="text" class="form-control" value="" name="editor" placeholder="Description" ><?php echo e($cview['description']); ?></textarea>
							  </div>
						  </div>
						  </div>
						  

						  
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>



<script type = "text/javascript">
	jQuery(document).ready(function(){
			jQuery('#catagory').change(function(){
				let cid=jQuery(this).val();
				jQuery.ajax({
					url:'getSubcat',
					type:'post',
					data:'cid='+cid+'&_token=<?php echo e(csrf_token()); ?>',
					success:function(result){

						jQuery('#subcategory').html(result)
					}
				});
			});
    });

</script>
<script type="text/javascript">
    $(document).on('click', '.videodelete', function(){
        
        var id = $(this).attr('data-id');
       
        $this = $(this);
     
        $.ajax({
            url:"coursevideodelete2",
            type:'post',
            data:{
                 id:id,
                _token:'<?php echo e(csrf_token()); ?>'
            },
            success: function(data) {
               $this.parents(".parc").remove();  
            }
            
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/admin/course/edit.blade.php ENDPATH**/ ?>