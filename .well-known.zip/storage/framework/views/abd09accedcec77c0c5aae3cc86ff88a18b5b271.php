
<?php $__env->startSection('contant'); ?>
 <style>
   select.form-control.select_main_langugage {
    height: 70px !important;
}

.select_main_puja option{
  color: #fff !important;
}

.select_main_langugage{
  color: #fff !important;
}

#main {
    background-image: url(../frontend_asset/assets/img/bg-ewd-pattern.png);
    background-size: 100% 100%;
    background-attachment: fixed;
}

.contact .php-email-form {
    width: 100%;
    padding: 30px;
    padding-top: 0;
    background: none !important;
}

.contact .container {
    /*width: 100%;*/
    /*padding: 30px;*/
    /*padding-top: 0;*/
    background: rgb(231 128 23) !important;
}

.pitarkriya_main .form-check {
    display: flex;
    align-items: center;
}

.pitarkriya_main .form-check input {
    margin-right: 10px;
    height: 29px;
}
.contact .php-email-form input {
    padding: 10px 15px;
    height: 44px;
}


.contact .php-email-form .form-group {
    padding-bottom: 1px;
}

.text-center {
    padding: 8px;
    text-align: center!important;
}

.contact form p {
    margin-bottom: 0px;
}

.contact .row {
    margin-top: 9px;
}

.form_input_main {
    padding-bottom: 0px !important;
}
.form_group_titlename .row {
    margin-top: 0px !important;
}


.form_otp_main label {
    color: #000 !important;
}

.form_otp_main input.form-control {
    border: solid 1px #898282 !important;
}


.form_otp_main input#otp::-webkit-input-placeholder{
    color:#000 !important;
}

           .Allcheckbox {
    height: 82px !important;
    overflow: auto;
   
}


.Allcheckbox {
    color: #000 !important;
}


.Allcheckbox input[type="checkbox"] {
    margin-right: 8px;
}

.Allcheckbox {
    height: 82px !important;
    overflow: auto;
    width: 100%;
    background: #fff !important;
    padding: 9px 13px;
}

.Allcheckbox {
    height: 109px !important;
    overflow: auto;
    width: 100%;
    background: #fff !important;
    padding: 9px 13px;
    border-radius: 8px;
}
 </style>
 
  <main id="main">
                 <section id="contact" class="contact">
                <div class="container">
                    <h2 class="text-white text-center">Register Form</h2>
                  
                <form  method="POST" id="formdiv"  enctype="multipart/form-data" role="form" action="submitForm" >
                <?php echo csrf_field(); ?>
               <div class="row">
                <div class="col-md-6 form-group form_group_titlename">
                   <div class="row">
                 <div class="col-sm-3"> 
                        <label for="comment">Title:</label>
                        <select class="form-control form-select" name="title" id="title" >
                        <option>Pandit</option>
                        <option value="Acharya">Acharya</option>
                        <option value="Shashtri">Shashtri </option>
                        <option value="Others">Others</option>
                        </select>
                        </div>
                        <div class="col-sm-9">
                        <label for="comment">First Name:</label>
                <input type="text" class="form-control"  id="fname" placeholder="Your First Name" name="fname" >
                </div>
                         </div>
                  </div>
                        <div class="col-md-6 form-group mt-3 mt-md-0">
                        <label for="comment">Last Name:</label>
                        <input type="text" class="form-control"  id="lname" placeholder="Your Last Name"  name="lname" >
                        </div>
                        </div>
                            <div class="row">
                        
                        
                        
                           <div class="col-md-6 form-group mt-3 mt-md-0">
                        <label for="comment">Email:</label>
                        <input type="email" class="form-control" id="email" placeholder="Email" name="email"/ >
              </div>
                       
               
                 <div class="col-md-6 form-group mt-3 mt-md-0">
                   <label for="comment">Mobile:</label>
                 <input type="number" class="form-control" placeholder="Mobile" name="mobile" id="mobile" />
                </div>
                </div>
                             <div class="row">
                  <div class="col-md-6 form-group">
                        <label for="comment">Language:</label>
                        <select class="form-select form-control" name="language" id="language" >
                        <option value="">Choose Option..</option>
                        <option value="Hindi">Hindi</option>
                        <option value="English">English</option>
                <option value="Oriya">Oriya</option>
              <optio n value="Bengali">Bengali</option>
               
                <option value="Telugu">Telugu</option>
                    <option value="Tamil">Tamil</option>
                        <option value="Others">Others</option>
                             </select>
                            </div>
                        <div class="col-md-6 form-group mt-3 mt-md-0">
                        <label for="comment">Community:</label>
                             <select class="form-select form-control" name="community" id="community">
                            <option value="">Choose Option..</option>
                        <option value="North Indian">North Indian</option>
                        <option value="Bengali">Bengali</option>
                             <option value="Assamese">Assamese</option>
                            <option value="Telugu">Telugu</option>
                        <option value="Tamil">Tamil</option>
                    <option value="Oriya"> Oriya</option>
                  <option value="Others">Others</option>
                </select>
                </div>
                         </div>
                     <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="comment">Preferred Location For Puja:</label>
                        <select class="form-select form-control" name="pujalocation" id="pujalocation" >
                        <option value="0 - 2 Years"> Within 10km</option>
                        <option value="0 - 2 Years"> Within City</option>
                        <option value="2 - 5 Years"> Out of City</option>
                        <option value="5 - 10 Years"> Both</option>
                </select>
                       
                        </div>
              
                       
                        <div class="col-md-6 form-group mt-3 mt-md-0">
                        <label for="comment">Experience (Years):</label>
                        <select class="form-select form-control" name="experience" id="experience" >
                <option value="0 - 2 Years"> 0 - 2 Years</option>
              <option value="2 - 5 Years"> 2 - 5 Years</option>
              <option value="5 - 10 Years"> 5 - 10 Years</option>
                <option value="10 Years and above"> 10 Years and above </option>
                   </select>
                  </div>
                        </div>
                            <div class="row">
                        <div class="col-md-6 form-group">
                        <div class="row">
                        <div class="col-md-4">
                        <label for="comment">DOB:</label>
                        <input type="date" class="form-control"  id="dob" placeholder="Date/time" name="dob" >
                        </div>
                        <div class="col-md-4">
                        <label for="comment">Place:</label>
                        <input type="text" class="form-control"  id="place" placeholder="Place" name="place" >
                        </div>
                        <div class="col-md-4">
                        <label for="comment">Time:</label>
                        <input type="time" class="form-control"  id="time" name="time" >
                        </div>
                        </div>
                        
                        </div>
                        <div class="col-md-6 form-group mt-3 mt-md-0">
                        <label for="comment">Educational Qualification:</label>
                        <select class="form-select form-control" name="education" id="education">
                        <option value="">-- select one --</option>
                        <option value="High School">High School</option>
                        <option value="Graduation">Graduation</option>
                        <option value="Post Graduation">Post Graduation</option>
                        <option value="Doctorate">Doctorate</option>
                        <option value="Others">Others</option>
                        </select>
                        </div>
                        </div>
                            <div class="row">
                        <div class="col-md-6 form-group">
                        <label for="comment">Country:</label>
                        <select class="form-control form-select" id="country" name="country" >
                        <option value="India">India</option>
                        <option value="AX">Aland Islands</option>
                        <option value="AL">Albania</option>
                        <option value="DZ">Algeria</option>
                        <option value="AS">American Samoa</option>
                        <option value="AD">Andorra</option>
                        <option value="AO">Angola</option>
                        <option value="AI">Anguilla</option>
                        <option value="AQ">Antarctica</option>
                        <option value="AG">Antigua and Barbuda</option>
                        <option value="AR">Argentina</option>
                        <option value="AM">Armenia</option>
                        <option value="AW">Aruba</option>
                        <option value="AU">Australia</option>
                        <option value="AT">Austria</option>
                        <option value="AZ">Azerbaijan</option>
                        <option value="BS">Bahamas</option>
                        <option value="BH">Bahrain</option>
                        <option value="BD">Bangladesh</option>
                        <option value="BB">Barbados</option>
                        <option value="BY">Belarus</option>
                        <option value="BE">Belgium</option>
                        <option value="BZ">Belize</option>
                        <option value="BJ">Benin</option>
                        <option value="BM">Bermuda</option>
                        <option value="BT">Bhutan</option>
                        <option value="BO">Bolivia</option>
                        <option value="BQ">Bonaire, Sint Eustatius and Saba</option>
                        <option value="BA">Bosnia and Herzegovina</option>
                        <option value="BW">Botswana</option>
                        <option value="BV">Bouvet Island</option>
                        <option value="BR">Brazil</option>
                        <option value="IO">British Indian Ocean Territory</option>
                        <option value="BN">Brunei Darussalam</option>
                        <option value="BG">Bulgaria</option>
                        <option value="BF">Burkina Faso</option>
                        <option value="BI">Burundi</option>
                        <option value="KH">Cambodia</option>
                        <option value="CM">Cameroon</option>
                        <option value="CA">Canada</option>
                        <option value="CV">Cape Verde</option>
                        <option value="KY">Cayman Islands</option>
                        <option value="CF">Central African Republic</option>
                        <option value="TD">Chad</option>
                        <option value="CL">Chile</option>
                        <option value="CN">China</option>
                        <option value="CX">Christmas Island</option>
                        <option value="CC">Cocos (Keeling) Islands</option>
                        <option value="CO">Colombia</option>
                        <option value="KM">Comoros</option>
                        <option value="CG">Congo</option>
                        <option value="CD">Congo, Democratic Republic of the Congo</option>
                        <option value="CK">Cook Islands</option>
                        <option value="CR">Costa Rica</option>
                        <option value="CI">Cote D'Ivoire</option>
                        <option value="HR">Croatia</option>
                        <option value="CU">Cuba</option>
                        <option value="CW">Curacao</option>
                        <option value="CY">Cyprus</option>
                        <option value="CZ">Czech Republic</option>
                        <option value="DK">Denmark</option>
                        <option value="DJ">Djibouti</option>
                        <option value="DM">Dominica</option>
                        <option value="DO">Dominican Republic</option>
                        <option value="EC">Ecuador</option>
                        <option value="EG">Egypt</option>
                        <option value="SV">El Salvador</option>
                        <option value="GQ">Equatorial Guinea</option>
                        <option value="ER">Eritrea</option>
                        <option value="EE">Estonia</option>
                        <option value="ET">Ethiopia</option>
                        <option value="FK">Falkland Islands (Malvinas)</option>
                        <option value="FO">Faroe Islands</option>
                        <option value="FJ">Fiji</option>
                        <option value="FI">Finland</option>
                        <option value="FR">France</option>
                        <option value="GF">French Guiana</option>
                        <option value="PF">French Polynesia</option>
                        <option value="TF">French Southern Territories</option>
                        <option value="GA">Gabon</option>
                        <option value="GM">Gambia</option>
                        <option value="GE">Georgia</option>
                        <option value="DE">Germany</option>
                        <option value="GH">Ghana</option>
                        <option value="GI">Gibraltar</option>
                        <option value="GR">Greece</option>
                        <option value="GL">Greenland</option>
                        <option value="GD">Grenada</option>
                        <option value="GP">Guadeloupe</option>
                        <option value="GU">Guam</option>
                        <option value="GT">Guatemala</option>
                        <option value="GG">Guernsey</option>
                        <option value="GN">Guinea</option>
                        <option value="GW">Guinea-Bissau</option>
                        <option value="GY">Guyana</option>
                        <option value="HT">Haiti</option>
                        <option value="HM">Heard Island and Mcdonald Islands</option>
                        <option value="VA">Holy See (Vatican City State)</option>
                        <option value="HN">Honduras</option>
                        <option value="HK">Hong Kong</option>
                        <option value="HU">Hungary</option>
                        <option value="IS">Iceland</option>
                        <option value="IN">India</option>
                        <option value="ID">Indonesia</option>
                        <option value="IR">Iran, Islamic Republic of</option>
                        <option value="IQ">Iraq</option>
                        <option value="IE">Ireland</option>
                        <option value="IM">Isle of Man</option>
                        <option value="IL">Israel</option>
                        <option value="IT">Italy</option>
                        <option value="JM">Jamaica</option>
                        <option value="JP">Japan</option>
                        <option value="JE">Jersey</option>
                        <option value="JO">Jordan</option>
                        <option value="KZ">Kazakhstan</option>
                        <option value="KE">Kenya</option>
                        <option value="KI">Kiribati</option>
                        <option value="KP">Korea, Democratic People's Republic of</option>
                        <option value="KR">Korea, Republic of</option>
                        <option value="XK">Kosovo</option>
                        <option value="KW">Kuwait</option>
                        <option value="KG">Kyrgyzstan</option>
                        <option value="LA">Lao People's Democratic Republic</option>
                        <option value="LV">Latvia</option>
                        <option value="LB">Lebanon</option>
                        <option value="LS">Lesotho</option>
                        <option value="LR">Liberia</option>
                        <option value="LY">Libyan Arab Jamahiriya</option>
                        <option value="LI">Liechtenstein</option>
                        <option value="LT">Lithuania</option>
                        <option value="LU">Luxembourg</option>
                        <option value="MO">Macao</option>
                        <option value="MK">Macedonia, the Former Yugoslav Republic of</option>
                        <option value="MG">Madagascar</option>
                        <option value="MW">Malawi</option>
                        <option value="MY">Malaysia</option>
                        <option value="MV">Maldives</option>
                        <option value="ML">Mali</option>
                        <option value="MT">Malta</option>
                        <option value="MH">Marshall Islands</option>
                        <option value="MQ">Martinique</option>
                        <option value="MR">Mauritania</option>
                        <option value="MU">Mauritius</option>
                        <option value="YT">Mayotte</option>
                        <option value="MX">Mexico</option>
                        <option value="FM">Micronesia, Federated States of</option>
                        <option value="MD">Moldova, Republic of</option>
                        <option value="MC">Monaco</option>
                        <option value="MN">Mongolia</option>
                        <option value="ME">Montenegro</option>
                        <option value="MS">Montserrat</option>
                        <option value="MA">Morocco</option>
                        <option value="MZ">Mozambique</option>
                        <option value="MM">Myanmar</option>
                        <option value="NA">Namibia</option>
                        <option value="NR">Nauru</option>
                        <option value="NP">Nepal</option>
                        <option value="NL">Netherlands</option>
                        <option value="AN">Netherlands Antilles</option>
                        <option value="NC">New Caledonia</option>
                        <option value="NZ">New Zealand</option>
                        <option value="NI">Nicaragua</option>
                        <option value="NE">Niger</option>
                        <option value="NG">Nigeria</option>
                        <option value="NU">Niue</option>
                        <option value="NF">Norfolk Island</option>
                        <option value="MP">Northern Mariana Islands</option>
                        <option value="NO">Norway</option>
                        <option value="OM">Oman</option>
                        <option value="PK">Pakistan</option>
                        <option value="PW">Palau</option>
                        <option value="PS">Palestinian Territory, Occupied</option>
                        <option value="PA">Panama</option>
                        <option value="PG">Papua New Guinea</option>
                        <option value="PY">Paraguay</option>
                        <option value="PE">Peru</option>
                        <option value="PH">Philippines</option>
                        <option value="PN">Pitcairn</option>
                        <option value="PL">Poland</option>
                        <option value="PT">Portugal</option>
                        <option value="PR">Puerto Rico</option>
                        <option value="QA">Qatar</option>
                        <option value="RE">Reunion</option>
                        <option value="RO">Romania</option>
                        <option value="RU">Russian Federation</option>
                        <option value="RW">Rwanda</option>
                        <option value="BL">Saint Barthelemy</option>
                        <option value="SH">Saint Helena</option>
                        <option value="KN">Saint Kitts and Nevis</option>
                        <option value="LC">Saint Lucia</option>
                        <option value="MF">Saint Martin</option>
                        <option value="PM">Saint Pierre and Miquelon</option>
                        <option value="VC">Saint Vincent and the Grenadines</option>
                        <option value="WS">Samoa</option>
                        <option value="SM">San Marino</option>
                        <option value="ST">Sao Tome and Principe</option>
                        <option value="SA">Saudi Arabia</option>
                        <option value="SN">Senegal</option>
                        <option value="RS">Serbia</option>
                        <option value="CS">Serbia and Montenegro</option>
                        <option value="SC">Seychelles</option>
                        <option value="SL">Sierra Leone</option>
                        <option value="SG">Singapore</option>
                        <option value="SX">Sint Maarten</option>
                        <option value="SK">Slovakia</option>
                        <option value="SI">Slovenia</option>
                        <option value="SB">Solomon Islands</option>
                        <option value="SO">Somalia</option>
                        <option value="ZA">South Africa</option>
                        <option value="GS">South Georgia and the South Sandwich Islands</option>
                        <option value="SS">South Sudan</option>
                        <option value="ES">Spain</option>
                        <option value="LK">Sri Lanka</option>
                        <option value="SD">Sudan</option>
                        <option value="SR">Suriname</option>
                        <option value="SJ">Svalbard and Jan Mayen</option>
                        <option value="SZ">Swaziland</option>
                    <option value="SE">Sweden</option>
                <option value="CH">Switzerland</option>
                <option value="SY">Syrian Arab Republic</option>
                         <option value="TW">Taiwan, Province of China</option>
                 <option value="TJ">Tajikistan</option>
                        <option value="TZ">Tanzania, United Republic of</option>
                        <option value="TH">Thailand</option>
                        <option value="TL">Timor-Leste</option>
                        <option value="TG">Togo</option>
                        <option value="TK">Tokelau</option>
                        <option value="TO">Tonga</option>
                        <option value="TT">Trinidad and Tobago</option>
                        <option value="TN">Tunisia</option>
                        <option value="TR">Turkey</option>
                        <option value="TM">Turkmenistan</option>
                        <option value="TC">Turks and Caicos Islands</option>
                        <option value="TV">Tuvalu</option>
                        <option value="UG">Uganda</option>
                        <option value="UA">Ukraine</option>
                        <option value="AE">United Arab Emirates</option>
                        <option value="GB">United Kingdom</option>
                        <option value="US">United States</option>
                        <option value="UM">United States Minor Outlying Islands</option>
                        <option value="UY">Uruguay</option>
                        <option value="UZ">Uzbekistan</option>
                        <option value="VU">Vanuatu</option>
                        <option value="VE">Venezuela</option>
                        <option value="VN">Viet Nam</option>
                        <option value="VG">Virgin Islands, British</option>
                        <option value="VI">Virgin Islands, U.s.</option>
                        <option value="WF">Wallis and Futuna</option>
                        <option value="EH">Western Sahara</option>
                        <option value="YE">Yemen</option>
                        <option value="ZM">Zambia</option>
                        <option value="ZW">Zimbabwe</option>
                        </select>
                        </div>
                        <div class="col-md-6 form-group mt-3 mt-md-0">
                        <label for="comment">State:</label>
                        <select class="form-control form-select" id="state" name="state">
                        <option value="Rajasthan">Rajasthan</option>
                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
              <optio
              
 
                <option value="Bihar">Bihar</option>
                   <option value="Chandigarh">Chandigarh</option>
                  <option value="Chhattisgarh">Chhattisgarh</option>
                <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                <option value="Daman and Diu">Daman and Diu</option>
                         <option value="Delhi">Delhi</option>
 <option value="Lakshadweep">Lakshadweep</option>
                 <option value="Puducherry">Puducherry</option>
                <option value="Goa">Goa</option>
              <optio
              n value="Gujarat">Gujarat</option>
               ion value="Haryana">Haryana</option>
                <option value="Himachal Pradesh">Himachal Pradesh</option>
                   <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                 <option value="Jharkhand">Jharkhand</option>
                <option value="Karnataka">Karnataka</option>
                <option value="Kerala">Kerala</option>
                         <option value="Madhya Pradesh">Madhya Pradesh</option>
                  <option value="Maharashtra">Maharashtra</option>
                <option value="Manipur">Manipur</option>
              <optio
              n value="Meghalaya">Meghalaya</option>
              ion value="Mizoram">Mizoram</option>
                <option value="Nagaland">Nagaland</option>
                   <option value="Odisha">Odisha</option>
                    <option value="Punjab">Punjab</option>
                      <option value="Sikkim">Sikkim</option>
                       <option value="Tamil Nadu">Tamil Nadu</option>
                        <option value="Telangana">Telangana</option>
                        <option value="Tripura">Tripura</option>
                        <option value="Uttar Pradesh">Uttar Pradesh</option>
                 <option value="Uttarakhand">Uttarakhand</option>
                <option value="West Bengal">West Bengal</option>
                </select>
                        </div>
                  </div>
                    <div class="row">
              <div class="col-md-6 form-group">
              <label for="comment">City:</label>
                <input type="text" class="form-control" id="city" name="city" placeholder="City" >
                   </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                <label for="comment">Village/Tehsil/Town:</label>
                
                <input type="text" class="form-control" name="village" id="village" placeholder="Village/Tehsil/Town" >
                 </div>
                   </div>
                        <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="comment">Home Address:</label>
                             <textarea class="form-control" name="address" id="address" rows="1" placeholder="Home Address" ></textarea>
                        </div>
                        <div class="col-md-6 form-group mt-3 mt-md-0">
                        <label for="comment">Pincode:</label>
                        <input type="number" class="form-control" name="pincode" id="pincode" placeholder="Your Pincode" >
                        </div>
                        </div>
                            <div class="row">
                    
                 
                        
                          <div class="col-md-6 form-group mt-3 mt-md-0">
                        <label for="comment">Upload Image:</label>
                <input type="file" name="img" row="4" id="img" class="form-control" required>
              </div>
             
              
                <div class="col-md-6 form-group mt-3 mt-md-0">
                <label for="comment">Referral Code Optional:</label>
                   <input type="text" class="form-control" name="referalcode" id="referalcode" placeholder="Referral Code Optional" >
                </div>
                </div>
                    <div class="row">
                        <div class="col-md-6 form-group">
                  <label for="comment">Brief About Yourself(150 Words)</label>
                <textarea class="form-control" rows="4" id="des"  name="des" placeholder="Any other details" ></textarea>
              </div>
              
              
              
             <div class="col-md-6 form-group">
             <label for="comment">Expertise:</label>
            <!-- <select class="form-select form-control" name="" id="" multiple >-->
            <!--     <option value="">Astrology</option>-->
            <!--     <option value="">Vedic</option>-->
            <!--     <option value="">Vastu</option>-->
            <!--     <option value="">Tarot Card</option>-->
            <!--     <option value="">Palmistry</option>-->
            <!--    <option value="">Lal Kitab</option>-->
            <!--    <option value="">Signature Expert</option>-->
            <!--    <option value="">Fengsui</option>-->
            <!--    <option value="">Dev Puja</option>-->
            <!--    <option value="">Pitra Kriya</option>-->
            <!--    <option value="">Katha Vachak</option>-->
            <!--</select>-->
            
            
            
             <div class="Allcheckbox">
                    <!--<input type="button" onclick='selects()' value="Select All"/>  -->
                    <!--<input type="button" onclick='deSelect()' value="Deselect All"/>  -->
                <input type="checkbox" name="chk" value="Smile">Astrology<br>  
                <input type="checkbox" name="chk" value="Cry">Vedic<br>  
                <input type="checkbox" name="chk" value="Laugh">Vastu<br>  
                <input type="checkbox" name="chk" value="Angry">Tarot Card<br>
                <input type="checkbox" name="chk" value="Smile">Palmistry<br>  
                <input type="checkbox" name="chk" value="Cry">Lal Kitab<br>  
                <input type="checkbox" name="chk" value="Laugh">Signature Expert<br>  
                <input type="checkbox" name="chk" value="Angry">Fengsui<br>  
                <input type="checkbox" name="chk" value="Smile">Dev Puja<br>  
                <input type="checkbox" name="chk" value="Cry">Pitra Kriya<br>  
                <input type="checkbox" name="chk" value="Laugh">Katha Vachak<br> 
                 <br>
                 
                </div>
            </div>
            
            </div>
             
                <div class="text-center"><input type="submit" class="btn btn-primary" name="submit"   value="Submit" data-bs-toggle="modal" data-bs-target="#myModal"> 
                </div>
               </form>
               
                </div>
            </section>
       </main>
           <div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">
                                      
      <div class="modal-header">
        <h4 class="modal-title">  <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> </h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <!-- Modal body -->
      <div class="modal-body">
                   <form method="post" class="form_otp_main" action="submitOtp">
            <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label for="emotpail text-dark">OTP:</label>
                  <input type="otp" class="form-control" id="otp" placeholder="Enter OTP" name="otp">
                </div>
                
                <div class="form-group">
                  <input type="submit" class="btn btn-primary mt-2" id="submit" value="submit" name="submit" type="submit">
                </div>
                        <!--<button class="btn btn-success" type="submit">Resend OTP</button>-->
                        </form>  

      </div>

     

    </div>
  </div>
</div>


  <script type="text/javascript">
            function selects(){
                var ele=document.getElementsByName('chk');
                for(var i=0; i<ele.length; i++){
                    if(ele[i].type=='checkbox')
                        ele[i].checked=true;
                }
            }
            function deSelect(){
                var ele=document.getElementsByName('chk');
                for(var i=0; i<ele.length; i++){
                    if(ele[i].type=='checkbox')
                        ele[i].checked=false;
                }
            }
        </script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skilluva/pandatji.com/resources/views/frontend/register_form.blade.php ENDPATH**/ ?>