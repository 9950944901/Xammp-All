<?php $__env->startSection('content'); ?>



	
		
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js" ></script>
<style>
.box_grid_main_img {
    height:260px;
    width: 300px;
        margin: 0 auto !important;
}

.box_grid_main_img img {
    object-fit: contain;
    height: 100%;
    display: block !important;
        margin: 0 auto !important;
}

  
    
    .box_grid_main .wrapper h3 {
          overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
}

    .box_grid_main .wrapper p {
          overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
}

.eboook_pagiantion_main svg {
    width: 13px;
}

.eboook_pagiantion_main .flex.justify-between.flex-1.sm\:hidden {
    display: none !important;
}

.eboook_pagiantion_main p.text-sm.text-gray-700.leading-5 {
    display: none !important;
}
</style>


<?php 

$data = App\Models\Bnner::first();

?>

<main>
    

		<section id="hero_in" class="courses" style="background-image:url(<?php echo e(url('uploads/banners/ebookbanner/'.$data['ebookbanner'])); ?>)">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span><?php echo e($data->ebookbanner_title); ?></h1>
				</div>
			</div>
		</section>
		<!--/hero_in-->
		
		
		
		

		<div class="filters_listing ">
			<div class="container">
				<ul class="clearfix">
				
					<li>
					    <h2>Select Your E-Books</h2>
					</li>
				</ul>
			</div>
			<!-- /container -->
		</div>
		<!-- /filters -->

		<div class="container margin_60_35">
			<div class="row">
				<aside class="col-lg-3" id="sidebar">
					<div id="filters_col"> <a data-bs-toggle="collapse" href="#collapseFilters" aria-expanded="false" aria-controls="collapseFilters" id="filters_col_bt">Filters </a>
						<div class="collapse show" id="collapseFilters">
							<div class="filter_type">
								<h6>Category</h6>
								<ul>
									<li>
										<label>
											<input type="checkbox" class="icheck" checked>all <small>(945)</small>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">Architecture <small>(45)</small>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">Managment <small>(30)</small>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">Business <small>(25)</small>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">Litterature <small>(56)</small>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">Biology <small>(10)</small>
										</label>
									</li>
								</ul>
							</div>
							<div class="filter_type">
								<h6>Rating</h6>
								<ul>
									<li>
										<label>
											<input type="checkbox" class="icheck">
											<span class="rating"><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i> <small>(145)</small></span>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">
											<span class="rating"><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star"></i> <small>(25)</small></span>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">
											<span class="rating"><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star"></i><i class="icon_star"></i> <small>(68)</small></span>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">
											<span class="rating"><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star"></i><i class="icon_star"></i><i class="icon_star"></i> <small>(34)</small></span>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">
											<span class="rating"><i class="icon_star voted"></i><i class="icon_star"></i><i class="icon_star"></i><i class="icon_star"></i><i class="icon_star"></i> <small>(10)</small></span>
										</label>
									</li>
								</ul>
							</div>
						</div>
						<!--/collapse -->
					</div>
					<!--/filters col-->
				</aside>
				<!-- /aside -->





				<div class="col-lg-9">
				    	<!--<div class="main_title_2 mt-5">-->
         <!--   				<span><em></em></span>-->
         <!--   				<h2>EBOOKS</h2>-->
         <!--   				<p class="mt-2">Here are our top Selling Ebooks, Book Now.</p>-->
         <!--   			</div>-->
					<div class="row">
				
					    
					    
					    
					    	<?php $__currentLoopData = $ebook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-6">
							<div class="box_grid wow box_grid_main">
								<figure class="block-reveal">
									<div class="block-horizzontal"></div>
									<a href="#0" class="wish_bt"></a>
									<a href="#0">
									    <div class="box_grid_main_img">
									    <img src="<?php echo e(url('uploads/Ebook/ebook/'.$book->eimage)); ?>" class="img-fluid" alt="">
									    </div>
									    </a>
									<!--<div class="price">$54</div>-->
									<div class="preview"><span>Preview course</span></div>
								</figure>
								<div class="wrapper">
									<h3><?php echo e($book->etitle); ?></h3>
									
								</div>
								<ul>
									<li><del class="text-danger">₹<?php echo e($book->emrp); ?></del></li>
									<li>₹<?php echo e($book->eprice); ?></li>
									
									<li><a href="subscription-package">Membership</a></li>
								</ul>
							</div>
						</div>
						
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<div class="eboook_pagiantion_main">
               <?php echo e($ebook->links()); ?>

					</div>
					</div>
					<!-- /row -->
					<!--<p class="text-center"><a href="#0" class="btn_1 rounded add_top_30">Load more</a></p>-->
				</div>
				<!-- /col -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
		
		<!-- /bg_color_1 -->
	</main>
	<!--/main-->
		
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/ebook.blade.php ENDPATH**/ ?>