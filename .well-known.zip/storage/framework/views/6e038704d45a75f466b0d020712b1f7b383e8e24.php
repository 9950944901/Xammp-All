
<?php $__env->startSection('contant'); ?>
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



            <div class="container-fluid">
 

 <div class="row">

	<div class="col-lg-12">
          <div class="card">

          <div class="row">
          <div class="col-md-12"> <h5 class="card-header text-uppercase"> Trainer Data </h5></div>

          </div>
		 
         
            <div class="card-body">
              
			<div class="table-responsive">
	          <table class="table table-bordered">
            <thead>

               <tr>
                <th>Full Name </th>
                <td><?php echo e($teachers->fname); ?>&nbsp;<?php echo e($teachers->lname); ?></td>
              </tr>

              <tr>
                <th>Email</th>
                <td><?php echo e($teachers->email); ?></td>
              </tr>
              
               <tr>
                <th>Mobile Number</th>
                <td><?php echo e($teachers->mobile); ?></td>
              </tr>
              
                <tr>
                <th>Expertise</th>
                <td><?php echo e($teachers->Expertise); ?></td>
              </tr>

     
      
                    <tr>
                <th>City&State </th>
                <td><?php echo e($teachers->city); ?>&nbsp;,<?php echo e($teachers->state); ?></td>
              </tr>

              <tr>
                <th>Brief intro</th>
                <td><?php echo e($teachers->brief_intro); ?></td>
              </tr>
              
              

     
            <tr>
  
                <th>Image</th>
                <td>            
<a href="<?php echo e(url('uploads/user_images/'.$teachers->image)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(url('uploads/user_images/'.$teachers->image)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;">
</a>
</td>
              </tr>
       
        
    
			  
          </thead>
          </table>
        </div>


			</div>
            </div>
          </div>     
          </div>
          	</div>  
            
	 
	

            <?php $__env->stopSection(); ?>



<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/admin/fullteacherview.blade.php ENDPATH**/ ?>