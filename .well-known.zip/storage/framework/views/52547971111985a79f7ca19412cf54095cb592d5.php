
<?php $__env->startSection('page_title','E-Book'); ?>
<?php $__env->startSection('contant'); ?>


			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> E-Book</div>
			     <div class="card-body">
				    <form method="POST" action="update_ebook" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<input type="hidden" name="id" value="<?php echo e($ebook['id']); ?>">

					    <div class="form-group row">

						  		  <label for="basic-input" class="col-sm-2 col-form-label">E-Book Title<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e($ebook['etitle']); ?>" name="etitle" placeholder="Enter E-Book Title" value="">
							  </div>
						  </div>
						  
						  		  <label for="basic-input" class="col-sm-2 col-form-label">E-Book MRP<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e($ebook['emrp']); ?>" name="emrp" placeholder="Enter E-Book MRP" value="">
							  </div>
						  </div>
						  
						  	  		  <label for="basic-input" class="col-sm-2 col-form-label">E-Book Price<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e($ebook['eprice']); ?>" name="eprice" placeholder="Enter E-Book Price" value="">
							  </div>
						  </div>
						  
						  	  <label for="basic-input" class="col-sm-2 col-form-label">E-Book Image<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="file" class="form-control" value="<?php echo e($ebook['eimage']); ?>" name="eimage" placeholder="Enter E-Book Title" value="" >
								<img src="<?php echo e(url('uploads/Ebook/ebook/'.$ebook->image)); ?>" width="55">
							  </div>
						  </div>
						  
						
						  <label for="basic-input" class="col-sm-2 col-form-label">Description<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e($ebook['wname']); ?>" name="wname" placeholder="Some text...." value="">
							  </div>
						  </div>
						 
						  
  <label for="basic-input" class="col-sm-2 col-form-label">Ebook Pdf<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="file" class="form-control" value="<?php echo e($ebook['pdf']); ?>" name="ebook[]" placeholder="Some text...." value="" multiple>
							  </div>
						  </div>
						  </div>
						  
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/admin/ebook/edit.blade.php ENDPATH**/ ?>