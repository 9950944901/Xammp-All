
<?php $__env->startSection('content'); ?>
<style>
@media  only screen and (max-width: 991px){
.why_choose_deteriucet1 {
    width: 100%;
    font-size: 22px !important;
    font-weight: lighter;
    font-size: 0px;
    padding: 10px 0px;
    border-radius: 25px 0px 25px 0px;
}
}
  
  .main_title_222{
          margin-top: 20px;
  }
  
  .frontend_img{
         position: relative;
    z-index: -999999;
    width: 100%;
    border-radius: 174px;
  }
.OUR_TEAM{
        font-weight: 600;
            text-align: center!important;
}
 .hard_working{
     line-height: 0;
    text-align: center!important;
 }

.frontend_images:hover{
      border-radius: 100px;
    width: 100%;
    transition: .2s linear;
    background-color: rgb(255, 182, 6,0.6);
}

.border_div1{
        padding: 16px 0;
}

.frontend_images {
      border-radius: 50%;
    display: flex;
}
@media  only screen and (max-width: 768px) {
    .frontend_img {
    position: relative;
    z-index: -999999;
    width: 50%;
    border-radius: 174px;
    margin: 0 auto;
}
}
 
.modal-backdrop {
    position: fixed;
    top: 0;
    left: 0;
    display: none!important;
    z-index: 1050;
    width: 100vw;
    height: 100vh;
    background-color: #000;
}

.purchased_Without{
      box-shadow: 0 0 10px;
    padding: 12px 15px;
    line-height: 0;
    border-radius: 8px;
}

.dakota_email{
        padding: 0 30px;
}

.envelope_images{
       color: #048214;
    font-size: 29px;
    line-height: 0;
}
.frontend_images_envelope {
    width: 100%;
}
 .Founder_color{
         color: #e59f20;
    height: 0;
 }
 .established_fact{
         color: #ff9200;
    line-height: 0;
    margin: 20px 0;
 }
 .pencil_bookmark{
  color: white;
    background-color: #349106;
    padding: 8px 13px;
    font-size: 25px;
    border-radius: 6px;
 }
 
.embarrassing_hidden {
    text-align: center;
}
.facebook_pencil{
    
}
 .About_Us_us{
     margin-top: 40px;
 }
 
 .creative_and_hard{
         text-align: center;
    color: white;
 }
 
</style>




<?php 

$data = App\Models\Bnner::first();

?>



<section id="hero_in" class="general" style="background-image:url(<?php echo e(url('uploads/banners/about_banner/'.$data['about_banner'])); ?>)">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span><?php echo e($data->about_banner_title); ?></h1>
				</div>
			</div>
</section>
<!--/hero_in-->
<!--<div class="container margin_120_95">-->
<!--    <div class="row">-->
<!--        <div class="col-lg-4 col-md-6">-->
<!--            </div>-->
            
<!--             <div class="col-lg-4 col-md-6">-->
<!--                 	<div class="main_title_2">-->
<!--				<span><em></em></span>-->
<!--				<h2 class="why_choose_deteriucet">Why choose</h2>-->
<!--				<p>Cum doctus civibus efficiantur in imperdiet deterruisset.</p>-->
<!--			</div>-->
<!--            </div>-->
<!--		 <div class="col-lg-4 col-md-6">-->
<!--            </div>-->
			
<!--				<div class="col-lg-4 col-md-6">-->
<!--					<a class="box_feat" href="#">-->
<!--						<i class="pe-7s-diamond"></i>-->
<!--						<h3>Qualified teachers</h3>-->
<!--						<p>SkillUVA is an e-learning platform where students and working professionals can enroll themselves for high-quality Video Courses of their choice.</p>-->
<!--					</a>-->
<!--				</div>-->
<!--				<div class="col-lg-4 col-md-6">-->
<!--					<a class="box_feat" href="#">-->
<!--						<i class="pe-7s-display2"></i>-->
<!--						<h3>Equiped class rooms</h3>-->
<!--						<p>We have an exclusive Trainer’s Corner where Trainers and Coaches can buy and download best training courseware for their corporate training programs. </p>-->
<!--					</a>-->
<!--				</div>-->
<!--				<div class="col-lg-4 col-md-6">-->
<!--					<a class="box_feat" href="#">-->
<!--						<i class="pe-7s-science"></i>-->
<!--						<h3>Advanced teaching</h3>-->
<!--						<p>Along with that SkillUVA also has an eBook library where learners can download paid and free eBooks for their personal & professional development.</p>-->
<!--					</a>-->
<!--				</div>-->
<!--				<div class="col-lg-4 col-md-6">-->
<!--					<a class="box_feat" href="#">-->
<!--						<i class="pe-7s-rocket"></i>-->
<!--						<h3>Adavanced study plans</h3>-->
<!--						<p>One can also take advantage of personalized live coaching sessions with our Master Trainers across the globe on Sales, Leadership & Personal Effectiveness. </p>-->
<!--					</a>-->
<!--				</div>-->
<!--				<div class="col-lg-4 col-md-6">-->
<!--					<a class="box_feat" href="#">-->
<!--						<i class="pe-7s-target"></i>-->
<!--						<h3>Focus on target</h3>-->
<!--						<p>Last but not the least, Our Blog will keep you abreast on latest technological, social, business and personal development articles for your growth.</p>-->
<!--					</a>-->
<!--				</div>-->
<!--				<div class="col-lg-4 col-md-6">-->
<!--					<a class="box_feat" href="#">-->
<!--						<i class="pe-7s-graph1"></i>-->
<!--						<h3>focus on success</h3>-->
<!--						<p>SkillUVA is established on the premise to proclaim that learning is not limited to a time or a specific age but rather on the attitude of a learner. Learning is forever, </p>-->
<!--					</a>-->
<!--				</div>-->
<!--			</div>-->
<!--		</div>-->
<!--our origin-->	


<section class="our origin">
    <div class="main_title_222">
			<div class="container">
				<div class="main_title_2">
					<div class="about_choose">
					<h2 class="why_choose_deteriucet1"><?php echo e($ab->about_title); ?></h2>
					</div>
					<p><?php echo e($ab->about_subtitle); ?></p>
				</div>
				<div class="row justify-content-between">
					<div class="col-lg-12 wow" data-wow-offset="150">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
						<img src="<?php echo e(url('uploads/about/'.$ab->about_img )); ?>" class="img-fluid">
						</figure>
					</div>
					

				</div>
				<!--/row-->
			</div>
			<!--/container-->
		</div>
</section>


<div class="bg_color_1">
			<div class="container margin_120_95">
				<!--<div class="main_title_2">-->
				<!--	<span><em></em></span>-->
				<!--	<h2>“Invest in yourself with SkillUVA and grow daily.”</h2>-->
				<!--	<p>Dr Ashish Parnani, Founder</p>-->
				<!--</div>-->
				<div class="row justify-content-between">
					<div class="col-lg-6 wow" data-wow-offset="150">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>

								<p><?php echo $ab->about_des; ?></p>
					
						</figure>
					</div>
					<div class="col-lg-5 wow" data-wow-offset="150">
					    <figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<h3>WHAT WE DO</h3>
						<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus
						Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>
						<p>Happy Learning with SkillUVA!!</p>
						</figure>
					</div>
				</div>
				<!--/row-->
			</div>
			<!--/container-->
		</div>




  <!-- <div class="container margin_120_95">-->
			
		<!--	<div class="container margin_120_95 our_trainers_main">-->
		<!--	<div class="main_title_2">-->
		<!--		<span><em></em></span>-->
		<!--		<h2>Tranding Our Trainers </h2>-->
		<!--		<p class="mt-2">Here is our Top Trainers, Choose one for you Now.</p>-->
		<!--	</div>-->
		<!--	<div id="carousel" class="owl-carousel owl-theme">-->
			    
		<!---->
                
  <!--            -->
		<!--		<div class="item">-->
		<!--			<a href="#0">-->
		<!--				<div class="title">-->
		<!--					-->
		<!--				-->
		<!--					</h4>-->
		<!--				</div>-->
		<!--				<div class="trainers_image_fit">-->
		<!--				   -->
		<!--				</div>-->
		<!--			</a>-->
		<!--		</div>-->
		<!---->
		<!--	</div>-->
		
		<!--</div>-->
			
		<!--</div>-->
<!--/container-->

<!--<section class="team_sliser">-->
<!--<div class="d-flex align-items-center py-5 mh-100">    -->
<!--        <a class="carousel-control-prev text-decoration-none " href="#mycarousel" role="button" data-bs-slide="prev">-->
<!--            <div class="d-flex flex-column justify-content-center me-2 ms-auto left"><span><i class="fa fa-chevron-left left_icon" aria-hidden="true"></i></span> </div> <span class="sr-only"></span>-->
<!--        </a>-->
<!--        <div class="container">-->
<!--            <div id="mycarousel" class="carousel slide" data-bs-ride="carousel">-->
<!--                <ol class="carousel-indicators">-->
<!--                    <li data-bs-target="#mycarousel" data-bs-slide-to="0" class="active"></li>-->
<!--                    <li data-bs-target="#mycarousel" data-bs-slide-to="1"></li>-->
<!--                    <li data-bs-target="#mycarousel" data-bs-slide-to="2"></li>-->
<!--                </ol>-->
<!--                <div class="carousel-inner">-->
<!--                    <div class="carousel-item active">-->
<!--                        <div class="row">-->
<!--                            <div class="col-lg-6 ">-->
<!--                                <img src="https://images.pexels.com/photos/8052808/pexels-photo-8052808.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500" class="d-block w-100" alt="...">-->
<!--                            </div>-->
<!--                            <div class="col-lg-6 ">-->
<!--                                <div class=" d-flex flex-column justify-content-center my-5 px-3">-->
<!--                                    <p class="review text-center">"Incredible services and amazing customer support"</p>-->
<!--                                    <div class="name d-flex align-items-center justify-content-center">-->
<!--                                        <span class="fas fa-minus pe-1"></span>-->
<!--                                        <p class="m-0">Joy Smith</p>-->
<!--                                    </div>-->
<!--                                    <p class="job text-center">Project Manager</p>-->
<!--                                </div>-->
<!--                            </div>-->

<!--                        </div>-->
<!--                    </div>-->
<!--                    <div class="carousel-item">-->
<!--                        <div class="row">-->
<!--                            <div class="col-lg-6 ">-->
<!--                                <img src="https://images.pexels.com/photos/8052808/pexels-photo-8052808.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500" class="d-block w-100" alt="...">-->
<!--                            </div>-->
<!--                            <div class="col-lg-6 ">-->
<!--                                <div class=" d-flex flex-column justify-content-center my-5 px-3">-->
<!--                                    <p class="review text-center">"Incredible services and amazing customer support"</p>-->
<!--                                    <div class="name d-flex align-items-center justify-content-center">-->
<!--                                        <span class="fas fa-minus pe-1"></span>-->
<!--                                        <p class="m-0">Joy Smith</p>-->
<!--                                    </div>-->
<!--                                    <p class="job text-center">Project Manager</p>-->
<!--                                </div>-->
<!--                            </div>-->

<!--                        </div>-->
<!--                    </div>-->
<!--                    <div class="carousel-item">-->
<!--                        <div class="row">-->
<!--                            <div class="col-lg-6 ">-->
<!--                                <img src="https://images.pexels.com/photos/8052808/pexels-photo-8052808.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500" class="d-block w-100" alt="...">-->
<!--                            </div>-->
<!--                            <div class="col-lg-6 ">-->
<!--                                <div class=" d-flex flex-column justify-content-center my-5 px-3">-->
<!--                                    <p class="review text-center">"Incredible services and amazing customer support"</p>-->
<!--                                    <div class="name d-flex align-items-center justify-content-center">-->
<!--                                        <span class="fas fa-minus pe-1"></span>-->
<!--                                        <p class="m-0">Joy Smith</p>-->
<!--                                    </div>-->
<!--                                    <p class="job text-center">Project Manager</p>-->
<!--                                </div>-->
<!--                            </div>-->

<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--        <a class="carousel-control-next text-decoration-none " href="#mycarousel" role="button" data-bs-slide="next">-->
<!--            <div class="d-flex flex-column justify-content-center right ms-2 me-auto"><span><i class="fa fa-chevron-right left_icon" aria-hidden="true"></i></span> </div> <span class="sr-only"></span>-->
<!--        </a>-->
<!--    </div>-->
<!--</section>-->









<section class="Robert_Garrisonll">
    <div class="container">
        <div class="row">
            <h2 class="MEET_OUR_TEAM">MEET OUR TEAM</h2>
            <p class="creative_and_hard">We have the most creative and hard working team.</p>
            
            <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
                <div class="card">
                    <div class="face front-face">
                        <?php if($Team->img): ?>
                        <img src="<?php echo e(url('uploads/Team_images/'.$Team->img)); ?>"
                            alt="" class="profile" width="100%">
                            <?php else: ?>
                             <img src="https://statinfer.com/wp-content/uploads/dummy-user.png"
                            alt="" class="profile" width="100%">
                            <?php endif; ?>
                            
                        <div class="pt-3 text-uppercase name">
                           <?php echo e($Team->name); ?>

                        </div>
                        <div class="designation"><?php echo e($Team->designation); ?></div>
                    </div>
                    <div class="face back-face">
                        <span><i class="fa fa-quote-left" aria-hidden="true"></i></span>
                        <div class="testimonial">
                            I made bacck the purchase price in just 48 hours! Thank you for making it pain less,
                            pleasant.
                            The service was execellent. I will refer everyone I know.
                        </div>
                       <button type="button" class="btn btn-primary toggle_button" data-bs-toggle="modal" data-bs-target="#team<?php echo e($Team->id); ?>">
                               View More
                                 </button>
                        <span><i class="fa fa-quote-right" aria-hidden="true"></i></span>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
        </div>
    </div>
</section>





<!-- The Modal -->
            <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="modal" id="team<?php echo e($Team->id); ?>">
  <div class="modal-dialog modal-xl">
    <div class="modal-content About_Us_us">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">About Us</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
     
     <section>
            <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="purchased_Without">
                        <?php if($Team->img): ?>
                        <img src="<?php echo e(url('uploads/Team_images/'.$Team->img)); ?>"
                            alt="" class="profile" width="100%">
                            <?php else: ?>
                             <img src="https://statinfer.com/wp-content/uploads/dummy-user.png"
                            alt="" class="profile" width="100%">
                            <?php endif; ?>

                    <h3>  <?php echo e($Team->name); ?></h3>
                    <p class="Founder_color"><?php echo e($Team->designation); ?></p>
                    <P><i class="fa fa-envelope-o envelope_images" aria-hidden="true"></i><span class="dakota_email"><?php echo e($Team->mail); ?></span></P>
                     <!--<P><i class="fa fa-mobile envelope_images" aria-hidden="true"></i><span class="dakota_email">+012 (345) 6789</span></P>-->
                     <!-- <P><i class="fa fa-map-marker envelope_images" aria-hidden="true"></i><span class="dakota_email">205 Main Street, USA</span></P>-->
                      <span class="facebook_pencil">
                         <a href="<?php echo e($Team->fb); ?>"><i class="fa fa-facebook pencil_bookmark" aria-hidden="true"></i></a> 
                          <a href="<?php echo e($Team->twiter); ?>"> <i class="fa fa-twitter pencil_bookmark" aria-hidden="true"></i></a> 
                        <a href="<?php echo e($Team->mail); ?>"> <i class="fa fa-linkedin pencil_bookmark" aria-hidden="true"></i></a> 
                      </span>
                </div>
                </div>
                <div class="col-lg-1">
                    </div>
                <div class="col-lg-7">
                    <h2 class="established_fact">About Me</h2>
                    
                    <p><?php echo $Team->description; ?></p>
                   
                   
                    </div>
                    </div>
                </div>
     </section>
     
     
     </div>
      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>











<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/aboutus.blade.php ENDPATH**/ ?>