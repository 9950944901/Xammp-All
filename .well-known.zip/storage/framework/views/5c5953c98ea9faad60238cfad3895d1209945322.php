
<?php $__env->startSection('page_title','Categroy'); ?>
<?php $__env->startSection('contant'); ?>

			   
	<div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> <?php echo e(empty($data->id) ? ' Add New' : 'Update'); ?> <?php echo e($title ?? ''); ?></div>
			     <div class="card-body">
				    <form method="post" action="<?php echo e(asset("admin/save-user")); ?>" class="form-horizontal" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
 
                        <input type="hidden" name="type" value="<?php echo e($role ?? ''); ?>">
                        <input type="hidden" name="userId" value="<?php echo e(!empty($data->id) ? $data->id : ''); ?>">
					    <div class="form-group ">
						  <label for="basic-input" class=" col-form-label">First Name</label>
						  <div class="">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(!empty($data->fname)  ? $data->fname : old('fname')); ?>" name="fname" placeholder="First Name " >
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
                        </div>
                        <div class="form-group ">
						  <label for="basic-input" class=" col-form-label">Last Name</label>
						  <div class="">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(!empty($data->lname)  ? $data->lname : old('lname')); ?>" name="lname" placeholder="Last Name " >
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
                        </div>
                        <div class="form-group ">
						  <label for="basic-input" class=" col-form-label">Email</label>
						  <div class="">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(!empty($data->email)  ? $data->email : old('email')); ?>" name="email" placeholder="Email" >
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
                        </div>
                         <div class="form-group ">
						  <label for="basic-input" class=" col-form-label">Mobile</label>
						  <div class="">
							<div class="input-group mb-3">
                            
								<input type="number" maxlenght="10" class="form-control" value="<?php echo e(!empty($data->mobile)  ? $data->mobile : old('mobile')); ?>" name="mobile" placeholder="Mobile" >
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
                        </div>
                        <div class="form-group ">
						  <label for="basic-input" class=" col-form-label">Password</label>
						  <div class="">
							<div class="input-group mb-3">
                            
								<input type="password" class="form-control" value="<?php echo e(!empty($data->password)  ? decrypt($data->password) : old('password')); ?>" name="password" placeholder="Password" >
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
                        </div>
						 
					
						  
						  
						 
                    <div class="form-group ">
						  <label for="basic-input" class="col-form-label">Status</label>
						
							<div class="input-group mb-3">
<select name="status" class="form-control single-select">
<option value="">Select Status</option>
<option value="1" <?php echo e((!empty($data->status) && $data->status == 1)  ? 'selected' : ''); ?>>Active</option>
<option value="0" <?php echo e((!empty($data->status) && $data->status == 0)  ? 'selected' : ''); ?>>Inactive</option>
</select> 

<p style="color:red;"><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
</div>
						 
						  
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/admin/add_user.blade.php ENDPATH**/ ?>