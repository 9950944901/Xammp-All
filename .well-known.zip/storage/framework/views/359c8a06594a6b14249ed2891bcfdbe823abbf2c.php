
<?php $__env->startSection('content'); ?>
<style>
.couraes_images{
        height: 286px;
    padding: 13px 1px;
}
    
    
</style>



<section id="hero_in" class="courses start_bg_zoom">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp animated"><span></span> Trainer Deteile</h1>
				</div>
			</div>
</section>

	<section class="skill_tranner_uva_first_tranner_section">
		    <div class="container">
		        <div class="row">
		            <div class="col-md-6">
                                <div class="input-group">
                                <div class="form-outline">
                                <input type="search" id="form1" class="form-control" placeholder="Search..."/>
                                
                                </div>
                                <button type="button" class="btn btn-primary" style="height: 47px;">
                                <i class="icon-search"></i>
                                </button>
                                </div>
		            </div>
		            <div class="col-md-4"></div>
	             <div class="col-md-2">                             
		                <form method="get" id= "searchform" action="<?php echo e(url('training_material_details/'.$user->id.'/categorysearch')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
    		                <div class="mt-2">
    		                    <select name="categorysearch" class="categorysearch">
    		                            <option value="">Categroy</option>
        							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        							    <option value="<?php echo e($category->id); ?>"><?php echo e($category->categroy); ?></option>
        							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    						    </select>
    		                </div>
		                </form>
		            </div>
		        </div>
		        
		    </div>
		</section>

<section>
	<div class="container margin_60_35">
			<div class="row">
		
				<aside class="col-lg-3">
				    	    <div class="traner_profile_position_first">
				  <div class="col-md-12">
            
            <div class="card p-3 py-4 card_profile_imag">
                
                <div class="text-center">
                    <?php if($user->image): ?>
                        <img src="<?php echo e(asset('uploads/user_images/'.$user->image)); ?>" width="100" class="rounded-circle image_circle_profile_image">
                    
                    <?php else: ?>
                        <img src="https://i.imgur.com/bDLhJiP.jpg" width="100" class="rounded-circle image_circle_profile_image">
                    
                    <?php endif; ?>
                </div>
                
                <div class="text-center mt-3">
                    <span class="bg-secondary p-1 px-4 rounded text-white">Pro</span>
                    <h5 class="mt-4 mb-0 Alexender"><?php echo e($user->fname); ?></h5>
                    <span class="mt-3 Designe"><?php echo e($user->Expertise); ?></span>
                    
                    <div class="px-4 mt-1">
                        <p class="fonts Designe"><?php echo e($user->brief_intro); ?></p>
                    </div>
                     <ul class="social-list">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fa fa-google"></i></a></li>
                    </ul>
                    <div class="buttons">
                        <button class="btn btn-outline-primary px-4 message_profile">View Profile</button>
                    </div>
                </div>
            </div>
         </div>
         </div>
        	</aside>
        	
				<div class="col-lg-9">
				    <?php if(count($courses) > 0): ?>
				    <div><h1 class="trainer_select_your_traner">Select Your Course</h1></div>
					<div class="row">
					    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    						<div class="col-md-4">
    							<div class="box_grid wow">
    								<figure class="block-reveal">
    									<div class="block-horizzontal"></div>
    									<a href="#0" class="wish_bt"></a>
    									<div class="traner_sub_detail_page_profile">
    									<a href="course-detail.html">
    									    <?php if($course->image): ?>
    									        <img src="<?php echo e(asset('uploads/advancecourse/image/'.$course->image)); ?>" class="img-fluid traner_profile_image" alt=""></a>
    									    <?php else: ?>
    									        <img src="https://bootdey.com/img/Content/avatar/avatar7.png" class="card-img-top img_src_first_skill">
    									    <?php endif; ?>
    									</div>
    									<div class="price">$<?php echo e($course->cprice); ?></div>
    									<div class="preview"><span>Preview course</span></div>
    								</figure>
    								<div class="wrapper">
    									<small>Skilluva</small>
    									<h3 class="heading_para_limit"><?php echo e($course->ctitle); ?></h3>
    									<!--<p>Id placerat tacimates definitionem sea, prima quidam vim no. Duo nobis persecuti cu.</p>-->
    									<div class="rating"><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star"></i><i class="icon_star"></i> <small>(145)</small></div>
    								</div>
    								<ul>
    									<li>
    									    <!--<i class="icon_clock_alt"></i> 1h 30min-->
    									    </li>
    									<!--<li><i class="icon_like"></i> 890</li>-->
    									<li><a href="<?php echo e(url('course-details'.$course->id)); ?>">Preview</a></li>
    								</ul>
    							</div>
    						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<!-- /box_grid -->
						
					</div>
					<!-- /row -->
					<p class="text-center"><a href="#0" class="btn_1 rounded add_top_30">Load more</a></p>
					<?php else: ?>
				        <h1>No Course Found</h1>
				    <?php endif; ?>
				</div>
			
				<!-- /col -->
			</div>
			<!-- /row -->
		</div>
</section>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
   	<script type = "text/javascript">
	jQuery(document).ready(function(){
	    jQuery('.categorysearch').change(function (e) {
		    $('#searchform').submit();
	    });
    });

</script>


<?php $__env->stopSection(); ?>




















<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/training_material_details.blade.php ENDPATH**/ ?>