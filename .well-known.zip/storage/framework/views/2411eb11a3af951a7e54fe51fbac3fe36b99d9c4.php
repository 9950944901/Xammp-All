
<?php $__env->startSection('content'); ?>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js" ></script>

<style>
.box_grid_main_img {
    height: 360px;
}

.box_grid_main_img img {
    object-fit: fill;
    height: 100%;
    width: 100% !important;
}


  
    
    .box_grid_main .wrapper h3 {
          overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
}

    .box_grid_main .wrapper p {
          overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
}


.eboook_pagiantion_main svg {
    width: 13px;
}

.eboook_pagiantion_main .flex.justify-between.flex-1.sm\:hidden {
    display: none !important;
}

.eboook_pagiantion_main p.text-sm.text-gray-700.leading-5 {
    display: none !important;
}

#list_sidebar .box_list figure {
    min-height: 275px !important;
}

#list_sidebar .box_list .wrapper {
    min-height: 215px !important;
}

#list_sidebar .box_list {
    min-height: 260px !important;
}
</style>


<?php 

$data = App\Models\Bnner::first();

?>



<main>
    

		<section id="hero_in" class="courses" style="background-image:url(<?php echo e(url('uploads/banners/accredited_banner/'.$data['accredited_banner'])); ?>)">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span><?php echo e($data->accredited_banner_title); ?></h1>
				</div>
			</div>
		</section>
		<!--/hero_in-->
	
		
		

		<div class="filters_listing ">
			<div class="container">
				<ul class="clearfix">
					<!--<li>-->
					<!--	<div class="switch-field">-->
					<!--		<input type="radio" id="all" name="listing_filter" value="all" checked>-->
					<!--		<label for="all">All</label>-->
					<!--		<input type="radio" id="popular" name="listing_filter" value="popular">-->
					<!--		<label for="popular">Popular</label>-->
					<!--		<input type="radio" id="latest" name="listing_filter" value="latest">-->
					<!--		<label for="latest">Latest</label>-->
					<!--	</div>-->
					<!--</li>-->
					
					<!--<li>-->
					<!--	<div class="layout_view">-->
					<!--		<a href="#0" class="active"><i class="icon-th"></i></a>-->
					<!--		<a href="courses-list.html"><i class="icon-th-list"></i></a>-->
					<!--	</div>-->
					
					    
					
					<!--</li>-->
					<!--<li>-->
					<!--	<select name="orderby" class="selectbox">-->
					<!--		<option value="category">Category</option>-->
					<!--		<option value="category 2">Literature</option>-->
					<!--		<option value="category 3">Architecture</option>-->
					<!--		<option value="category 4">Economy</option>-->
					<!--	</select>-->
					<!--</li>-->
					<li>
					    <form method="get" action="searchbasiccourse">
                                <div class="input-group">
                                <div class="form-outline">
                                <input type="search" id="form1" class="form-control" name="title" placeholder="Search..."/>
                                
                                </div>
                                <button type="submit" class="btn btn-primary" style="height: 47px;">
                                <i class="icon-search"></i>
                                </button>
                                </div>
                                </form>
					</li>
				</ul>
			</div>
			<!-- /container -->
		</div>
		<!-- /filters -->

		<div class="container margin_60_35">
			<div class="row">
				<aside class="col-lg-3" id="sidebar">
					<div id="filters_col"> <a data-bs-toggle="collapse" href="#collapseFilters" aria-expanded="false" aria-controls="collapseFilters" id="filters_col_bt">Filters </a>
						<div class="collapse show" id="collapseFilters">
							<div class="filter_type">
								<h6>Category</h6>
								<ul>
									<li>
										<label>
											<input type="checkbox" class="icheck" checked>all <small>(945)</small>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">Architecture <small>(45)</small>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">Managment <small>(30)</small>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">Business <small>(25)</small>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">Litterature <small>(56)</small>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">Biology <small>(10)</small>
										</label>
									</li>
								</ul>
							</div>
							<div class="filter_type">
								<h6>Rating</h6>
								<ul>
									<li>
										<label>
											<input type="checkbox" class="icheck">
											<span class="rating"><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i> <small>(145)</small></span>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">
											<span class="rating"><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star"></i> <small>(25)</small></span>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">
											<span class="rating"><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star"></i><i class="icon_star"></i> <small>(68)</small></span>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">
											<span class="rating"><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star"></i><i class="icon_star"></i><i class="icon_star"></i> <small>(34)</small></span>
										</label>
									</li>
									<li>
										<label>
											<input type="checkbox" class="icheck">
											<span class="rating"><i class="icon_star voted"></i><i class="icon_star"></i><i class="icon_star"></i><i class="icon_star"></i><i class="icon_star"></i> <small>(10)</small></span>
										</label>
									</li>
								</ul>
							</div>
						</div>
						<!--/collapse -->
					</div>
					<!--/filters col-->
				</aside>
				<!-- /aside -->






<div class="col-lg-9" id="list_sidebar">
    	<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="box_list wow">
						<div class="row g-0">
							<div class="col-lg-5">
								<figure class="block-reveal">
									<div class="block-horizzontal"></div>
									<a href="<?php echo e(url('course-details'.$course->id)); ?>">
									    <div class="advanced_course_main_list">
									        <a href="<?php echo e(url('course-details'.$course->id)); ?>">
            							     <?php if($course->image): ?>
            							        <img src="<?php echo e(asset('public/uploads/advancecourse/image/'.$course->image)); ?>" class="img-fluid traner_profile_image" alt=""></a>
            							    <?php else: ?>
            							        <img src="https://bootdey.com/img/Content/avatar/avatar7.png" class="card-img-top img_src_first_skill">
            							    <?php endif; ?>
            							    </div>
									    </a>
									<div class="preview"><span>Preview course</span></div>
								</figure>
							</div>
							<div class="col-lg-7">
								<div class="wrapper">
									<a href="#0" class="wish_bt"></a>
									<div class="price">$<?php echo e($course->cprice); ?></div>
									
										<?php
							    $category = App\Models\category::where('id',$course->catagory)->first();
							?>
									<small><?php echo e($category->categroy); ?></small>
									<h3><?php echo e($course->ctitle); ?></h3>
									<p><?php echo $course->description; ?></p>
									<div class="rating"><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star"></i><i class="icon_star"></i> <small>(145)</small></div>
								</div>
								<ul>
								
									<li><a href="<?php echo e(url('course-details'.$course->id)); ?>">Enroll now</a></li>
								</ul>
							
							</div>
						</div>
					</div>
					
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="eboook_pagiantion_main">
		<?php echo $courses->links('pagination::bootstrap-4'); ?>

</div>
                <p class="text-center add_top_60"><a href="#0" class="btn_1 rounded">Load more</a></p>
		</div>



				
				<!-- /col -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
		<div class="bg_color_1">
			<div class="container margin_60_35">
				<div class="row">
					<div class="col-md-4">
						<a href="#0" class="boxed_list">
							<i class="pe-7s-help2"></i>
							<h4>Need Help? Contact us</h4>
							<p>Cum appareat maiestatis interpretaris et, et sit.</p>
						</a>
					</div>
					<div class="col-md-4">
						<a href="#0" class="boxed_list">
							<i class="pe-7s-wallet"></i>
							<h4>Payments and Refunds</h4>
							<p>Qui ea nemore eruditi, magna prima possit eu.</p>
						</a>
					</div>
					<div class="col-md-4">
						<a href="#0" class="boxed_list">
							<i class="pe-7s-note2"></i>
							<h4>Quality Standards</h4>
							<p>Hinc vituperata sed ut, pro laudem nonumes ex.</p>
						</a>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /bg_color_1 -->
	</main>
	<!--/main-->
	
	<script>
$('.like').click(function() 
{
alert('fdsz');
  
   
});
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/advanced_course.blade.php ENDPATH**/ ?>