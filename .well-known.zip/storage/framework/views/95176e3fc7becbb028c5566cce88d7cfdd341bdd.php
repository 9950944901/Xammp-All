
<?php $__env->startSection('page_title','Blog'); ?>
<?php $__env->startSection('contant'); ?>


			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Blogs</div>
			     <div class="card-body">
				    <form method="POSt" action="add_blog" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

					    <div class="form-group row">
						
						  
						  
						  		  <label for="basic-input" class="col-sm-2 col-form-label">Blog Title<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('title')); ?>" name="title" placeholder="Enter Blog Title" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  		  <label for="basic-input" class="col-sm-2 col-form-label">Author Name<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('auther_name')); ?>" name="auther_name" placeholder="Enter Author Name" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['auther_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  	  		  <label for="basic-input" class="col-sm-2 col-form-label">Author Image<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="file" class="form-control" value="<?php echo e(old('auther_img')); ?>" name="auther_img" placeholder="Enter Course Price" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['auther_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  	  <label for="basic-input" class="col-sm-2 col-form-label">Blog  Image<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="file" class="form-control" value="<?php echo e(old('blog_img')); ?>" name="blog_img" placeholder="Enter Course Title" value="" multiple>
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['blog_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  </div>
						 
                      
						    <div class="form-group row">
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Blog Description<span style="color:red;">*</span></label>
						  	  <div class="col-sm-10">
							<div class="input-group mb-3">
                            
								<textarea type="text" class="form-control" value="<?php echo e(old('editor')); ?>" name="editor" placeholder="Description" value=""></textarea>
							  </div>
							                                <p style="color:red;"><?php $__errorArgs = ['editor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>

						  </div>
						  </div> 
						 
						  

						  
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/admin/blog/add_blog.blade.php ENDPATH**/ ?>