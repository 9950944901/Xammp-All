
<?php $__env->startSection('content'); ?>



	<main>
		<section id="hero_in" class="general">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span>blog</h1>
				</div>
			</div>
		</section>
		<!--/hero_in-->

		<div class="container margin_60_35">
			<div class="row">
				<div class="col-lg-9">
				    
				      
					    <?php 
                
                $blogs= App\Models\Blog::where('status','1')->Paginate(6);
                
                ?>
                
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<article class="blog wow fadeIn">
					  
					    
						<div class="row g-0">
							<div class="col-lg-7">
								<figure>
									<a href="<?php echo e(url('blog-details'.$list->id)); ?>"><img src="<?php echo e(url('uploads/blog_images/'.$list->blog_img)); ?>"alt="">
										<!--<div class="preview"><span>Read more</span></div>-->
									</a>
								</figure>
							</div>
							<div class="col-lg-5">
								<div class="post_info">
									<small><?php echo e($list->created_at); ?></small>
									<h3><a href="<?php echo e(url('blog-details')); ?>"><?php echo e($list->title); ?></a></h3>
									<p><?php echo e($list->description); ?>...</p>
									<ul>
										<li>
											<div class="thumb"><img src="<?php echo e(url('uploads/blog_images/'.$list->auther_img)); ?>" alt=""></div> <?php echo e($list->auther_name); ?>

										</li>
										<li><i class="icon_comment_alt"></i> 20</li>
									</ul>
								</div>
							</div>
						</div>
					</article>
					
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					

					  <?php echo $blogs->links('pagination::bootstrap-4'); ?>

					<!-- /article -->

					<!--<article class="blog wow fadeIn">-->
					<!--	<div class="row g-0">-->
					<!--		<div class="col-lg-7">-->
					<!--			<figure>-->
					<!--				<a href="<?php echo e(url('blog-details')); ?>"><img src="<?php echo e(URL::asset('frontend/img/blog-2.jpg')); ?>" alt="">-->
					<!--					<div class="preview"><span>Read more</span></div>-->
					<!--				</a>-->
					<!--			</figure>-->
					<!--		</div>-->
					<!--		<div class="col-lg-5">-->
					<!--			<div class="post_info">-->
					<!--				<small>20 Nov. 2017</small>-->
					<!--				<h3><a href="<?php echo e(url('blog-details')); ?>">Nec nihil menandri appellantur ut</a></h3>-->
					<!--				<p>Quodsi sanctus pro eu, ne audire scripserit quo. Vel an enim offendit salutandi, in eos quod omnes epicurei, ex veri qualisque scriptorem mei.</p>-->
					<!--				<ul>-->
					<!--					<li>-->
					<!--						<div class="thumb"><img src="<?php echo e(URL::asset('frontend/img/thumb_blog.jpg')); ?>" alt=""></div> Jessica Hoops-->
					<!--					</li>-->
					<!--					<li><i class="icon_comment_alt"></i> 20</li>-->
					<!--				</ul>-->
					<!--			</div>-->
					<!--		</div>-->
					<!--	</div>-->
					<!--</article>-->
					<!-- /article -->

					<!--<article class="blog wow fadeIn">-->
					<!--	<div class="row g-0">-->
					<!--		<div class="col-lg-7">-->
					<!--			<figure>-->
					<!--				<a href="<?php echo e(url('blog-details')); ?>"><img src="<?php echo e(URL::asset('frontend/img/blog-3.jpg')); ?>" alt="">-->
					<!--					<div class="preview"><span>Read more</span></div>-->
					<!--				</a>-->
					<!--			</figure>-->
					<!--		</div>-->
					<!--		<div class="col-lg-5">-->
					<!--			<div class="post_info">-->
					<!--				<small>20 Nov. 2017</small>-->
					<!--				<h3><a href="<?php echo e(url('blog-details')); ?>">Nec nihil menandri appellantur ut</a></h3>-->
					<!--				<p>Quodsi sanctus pro eu, ne audire scripserit quo. Vel an enim offendit salutandi, in eos quod omnes epicurei, ex veri qualisque scriptorem mei.</p>-->
					<!--				<ul>-->
					<!--					<li>-->
					<!--						<div class="thumb"><img src="<?php echo e(URL::asset('frontend/img/thumb_blog.jpg')); ?>" alt=""></div> Jessica Hoops-->
					<!--					</li>-->
					<!--					<li><i class="icon_comment_alt"></i> 20</li>-->
					<!--				</ul>-->
					<!--			</div>-->
					<!--		</div>-->
					<!--	</div>-->
					<!--</article>-->
					<!-- /article -->

					<!--<article class="blog wow fadeIn">-->
					<!--	<div class="row g-0">-->
					<!--		<div class="col-lg-7">-->
					<!--			<figure>-->
					<!--				<a href="<?php echo e(url('blog-details')); ?>"><img src="<?php echo e(URL::asset('frontend/img/blog-4.jpg')); ?>" alt="">-->
					<!--					<div class="preview"><span>Read more</span></div>-->
					<!--				</a>-->
					<!--			</figure>-->
					<!--		</div>-->
					<!--		<div class="col-lg-5">-->
					<!--			<div class="post_info">-->
					<!--				<small>20 Nov. 2017</small>-->
					<!--				<h3><a href="<?php echo e(url('blog-details')); ?>">Nec nihil menandri appellantur ut</a></h3>-->
					<!--				<p>Quodsi sanctus pro eu, ne audire scripserit quo. Vel an enim offendit salutandi, in eos quod omnes epicurei, ex veri qualisque scriptorem mei.</p>-->
					<!--				<ul>-->
					<!--					<li>-->
					<!--						<div class="thumb"><img src="<?php echo e(URL::asset('frontend/img/thumb_blog.jpg')); ?>" alt=""></div> Jessica Hoops-->
					<!--					</li>-->
					<!--					<li><i class="icon_comment_alt"></i> 20</li>-->
					<!--				</ul>-->
					<!--			</div>-->
					<!--		</div>-->
					<!--	</div>-->
					<!--</article>-->
					<!-- /article -->

					<!--<nav aria-label="...">-->
					<!--	<ul class="pagination pagination-sm">-->
					<!--		<li class="page-item disabled">-->
					<!--			<a class="page-link" href="#" tabindex="-1">Previous</a>-->
					<!--		</li>-->
					<!--		<li class="page-item"><a class="page-link" href="#">1</a></li>-->
					<!--		<li class="page-item"><a class="page-link" href="#">2</a></li>-->
					<!--		<li class="page-item"><a class="page-link" href="#">3</a></li>-->
					<!--		<li class="page-item">-->
					<!--			<a class="page-link" href="#">Next</a>-->
					<!--		</li>-->
					<!--	</ul>-->
					<!--</nav>-->
					<!-- /pagination -->
				</div>
				<!-- /col -->

				<aside class="col-lg-3">
					<div class="widget">
						<form>
							<div class="form-group">
								<input type="text" name="search" id="search" class="form-control" placeholder="Search...">
							</div>
							<button type="submit" id="submit" class="btn_1 rounded"> Search</button>
						</form>
					</div>
					<!-- /widget -->
					<div class="widget">
						<div class="widget-title">
							<h4>Recent Posts</h4>
						</div>
						<ul class="comments-list">
							<li>
								<div class="alignleft">
									<a href="<?php echo e(url('blog-details')); ?>"><img src="<?php echo e(URL::asset('frontend/img/blog-5.jpg')); ?>" alt=""></a>
								</div>
								<small>11.08.2016</small>
								<h3><a href="<?php echo e(url('blog-details')); ?>" title="">Verear qualisque ex minimum...</a></h3>
							</li>
							<li>
								<div class="alignleft">
									<a href="<?php echo e(url('blog-details')); ?>"><img src="<?php echo e(URL::asset('frontend/img/blog-6.jpg')); ?>" alt=""></a>
								</div>
								<small>11.08.2016</small>
								<h3><a href="<?php echo e(url('blog-details')); ?>" title="">Verear qualisque ex minimum...</a></h3>
							</li>
							<li>
								<div class="alignleft">
									<a href="<?php echo e(url('blog-details')); ?>"><img src="<?php echo e(URL::asset('frontend/img/blog-4.jpg')); ?>" alt=""></a>
								</div>
								<small>11.08.2016</small>
								<h3><a href="<?php echo e(url('blog-details')); ?>" title="">Verear qualisque ex minimum...</a></h3>
							</li>
						</ul>
					</div>
					<!-- /widget -->
					<div class="widget">
						<div class="widget-title">
							<h4>Blog Categories</h4>
						</div>
						<ul class="cats">
							<li><a href="<?php echo e(('admission')); ?>">Admissions <span>(12)</span></a></li>
							<li><a href="<?php echo e(('blog')); ?>">News <span>(21)</span></a></li>
							<li><a href="#">Events <span>(44)</span></a></li>
							<li><a href="#">Focus in the lab <span>(31)</span></a></li>
						</ul>
					</div>
					<!-- /widget -->
					<div class="widget">
						<div class="widget-title">
							<h4>Popular Tags</h4>
						</div>
						<div class="tags">
							<a href="#">Information tecnology</a>
							<a href="#">Students</a>
							<a href="#">Community</a>
							<a href="#">Carreers</a>
							<a href="#">Literature</a>
							<a href="#">Seminars</a>
						</div>
					</div>
					<!-- /widget -->
				</aside>
				<!-- /aside -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</main>
	<!--/main-->
		
		<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/blog.blade.php ENDPATH**/ ?>