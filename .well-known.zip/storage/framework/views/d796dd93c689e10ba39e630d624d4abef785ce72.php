<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Skilluva a modern educational site template">
    <meta name="author" content="Ansonika">
    <title>Skilluva </title>

    <!-- Favicons-->
    <link rel="shortcut icon" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>">

    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&amp;display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="<?php echo e(URL::asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('frontend/css/style.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(URL::asset('frontend/css/vendors.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(URL::asset('frontend/css/icon_fonts/css/all_icons.min.css')); ?>" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="<?php echo e(URL::asset('frontend/css/custom.css')); ?>" rel="stylesheet">

</head>
<style>
    .aside_login_teb{
        min-height: 80vh !important;
    }
    .login_teb_skilluva{
            margin-top: 50px;
    }
</style>
<body id="login_bg">
	
	<nav id="menu" class="fake_menu"></nav>
	
	<div id="preloader">
		<div data-loader="circle-side"></div>
	</div>
	<!-- End Preload -->
	
	<div id="login" class="login_teb_skilluva">
		<aside class="aside_login_teb">
			<figure>
				<a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(URL::asset('frontend/img_skill/logo_skill.png')); ?>" width="149" height="42" alt=""></a>
			</figure>
												<div id="thank_you_msg"></div>

			  <form id="frmLogin" method="post">
			      <?php echo csrf_field(); ?>
				<!--<div class="access_social">-->
				<!--	<a href="#0" class="social_bt facebook">Login with Facebook</a>-->
				<!--	<a href="#0" class="social_bt google">Login with Google</a>-->
				<!--	<a href="#0" class="social_bt linkedin">Login with Linkedin</a>-->
				<!--</div>-->
				
				
				
				<!--<div class="divider"><span>Or</span></div>-->
				<div class="form-group">
					<span class="input">
					<input class="input_field" type="email" autocomplete="off" name="str_login_email">
						<label class="input_label">
						<span class="input__label-content">Your email</span>
					</label>
					</span>

					<span class="input">
					<input class="input_field" type="password" autocomplete="new-password" name="str_login_password">
						<label class="input_label">
						<span class="input__label-content">Your password</span>
					</label>
					</span>
					<!--<small><a href="#0">Forgot password?</a></small>-->
				</div>
																			            <div style="    margin-top: 7px; color:red;" id="login_msg"></div>

				<input type="submit" class="btn_1 rounded full-width add_top_60 add_top_54" id="btnLogin" value="Login to Skilluva">
				<div class="text-center add_top_10">New to Skilluva? <strong><a href="<?php echo e(('register')); ?>">Sign up!</a></strong></div>
			</form>

			<div class="copy">© 2022 Skilluva</div>
		</aside>
	</div>
	<!-- /login -->
		
	<!-- COMMON SCRIPTS -->
    <script src="<?php echo e(URL::asset('frontend/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('frontend/js/common_scripts.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('frontend/js/main.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('frontend/assets/validate.js')); ?>"></script>	
  
  
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  	<script>
	    
	    jQuery('#frmLogin').submit(function(e){
  jQuery('#login_msg').html("");
  e.preventDefault();
  jQuery.ajax({
    url:'login',
    data:jQuery('#frmLogin').serialize(),
    type:'post',
    success:function(result){
      if(result.status=="error"){
        jQuery('#login_msg').html(result.msg);
      }
      
      if(result.status=="success"){
       window.location.href='https://sindhisanskriti.com/skilluva.sindhisanskriti.com/skilluva/'
            //   window.location.href='<?php echo e(URL::previous()); ?>'

        //jQuery('#frmLogin')[0].reset();
        //jQuery('#thank_you_msg').html(result.msg);
      }
    }
  });
});
	    
	</script>
</body>

</html><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/login.blade.php ENDPATH**/ ?>