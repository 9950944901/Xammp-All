<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Skilluva</title>

    <!-- Favicons-->
    <link rel="shortcut icon" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>">

    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&amp;display=swap" rel="stylesheet">

   
    
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="<?php echo e(URL::asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('frontend/css/style.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(URL::asset('frontend/css/vendors.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(URL::asset('frontend/css/icon_fonts/css/all_icons.min.css')); ?>" rel="stylesheet">
	
	<!-- SPECIFIC CSS -->
	<link href="<?php echo e(URL::asset('frontend/css/skins/square/grey.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(URL::asset('frontend/css/wizard.css')); ?>" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="<?php echo e(URL::asset('frontend/css/custom.css')); ?>" rel="stylesheet">
 
<style>
    h3.main_question {
  
    font-size: 1.125rem;
}
.pointer_for_curser{
     cursor: pointer; 
}
.step_last_stag .radio_input a:hover{
     cursor: pointer;
    color: white !important;
}
.step_last_stag .radio_input a {
     cursor: pointer;
    color: white !important;
}
.form_to_retio_for_term{
        margin-top: 20px;
    border: 1px solid;
    text-align: center;
    padding: 19px 0px;
    font-size: 16px;
    background: black;
    cursor: pointer; 
}
.main_question.wizard-header:after {
    content: "";
    background: red;
    height: 4px;
    display: flex;
    width: 174px;
    margin: auto;
    margin-top: 12px;
}


/*model css===================================*/
   .list_for_member_ship_plan li {
    font-size: 15px;
    line-height: 24px;
}
.choose_your_member_ship_plan{
    padding-bottom: 8px;
    padding-top: 12px;
    font-family: 'FontAwesome';
}
  .icon_first_member_plan{
      color: white;
    font-size: 38px;
  } 
   .memeber_sip_plan_section{
    padding-top: 19px;
    padding-bottom: 32px;
   }
.member_shipp_plans {
    max-width: 330px;
    position: relative;
    padding: 20px;
    box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
    padding-bottom: 47px;
    border-radius: 27px;
}

.h-1 {
    text-transform: uppercase
}

.ribon {
    position: absolute;
    left: 50%;
    top: 0;
    transform: translate(-50%, -50%);
    width: 80px;
    height: 80px;
    background-color: #2b98f0;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center
}

.ribon .fas.fa-spray-can,
.ribon .fas.fa-broom,
.ribon .fas.fa-shower,
.ribon .fas.fa-infinity {
    font-size: 30px;
    color: white
}

.cmember_shipp_plans .price {
    color: #2b98f0;
    font-size: 30px
}

.member_shipp_plans ul {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center
}

.member_shipp_plans ul li {
     font-size: 15px;
    margin-bottom: 8px;
    text-align: center;
    line-height: 35px;
}

.member_shipp_plans ul .fa.fa-check {
    font-size: 8px;
    color: gold
}

.member_shipp_plans:hover {
    transform: translate(0,-13px);
    transition: .5s linear;
 
}

.member_shipp_plans:hover .fa.fa-check {
    color: #2b98f0
}

.member_shipp_plans .btn {
    width: 200px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #2b98f0;
    border: none;
    border-radius: 0px;
    box-shadow: none;
    border-radius: 32px;
    box-shadow: 0px 0px 2px #000000;
    font-weight: bolder;
    font-size: 16px;
}
.member_shipp_plans .btn:hover {
    background: #fff;
    color: black;
    
}
.memeber_ship_heading_plan_color{
    color: red;
    font-size: 20px;
    font-weight: bolder;
   margin-top: 6px;
    line-height: 0px;
}
.memeber_shipp_plan_month{
        font-size: 24px;
    text-align: center;
    font-weight: bolder;
    margin-top: 13px;
}

.add_employee_main h4 {
    margin-bottom: 10px;
    margin-top: 5px;
}

.append_data_main input {
    margin-bottom: 0px !important;
}

.append_data_main {
    border: solid 1px #eee;
    border-radius: 10px;
    padding: 12px;
        margin-top: 15px;
    margin-bottom: 10px;

}


.add_gift_main h4 {
    margin-bottom: 10px;
    margin-top: 5px;
}

.add_gift_main input {
    margin-bottom: 0px !important;
}

.add_gift_main {
    border: solid 1px #eee;
    border-radius: 10px;
    padding: 12px;
        margin-top: 15px;
    margin-bottom: 10px;

}

.append_gift_main {
    border: solid 1px #eee !important;
    border-radius: 10px !important;
    padding: 10px !important;
    margin-top: 10px !important;
    margin-bottom: 10px !important;
}
@media (max-width:500px) {
    .card {
        max-width: 100%
    }
} 
</style>

 


</head>

<body id="admission_bg">
	
	<div id="preloader">
		<div data-loader="circle-side"></div>
	</div>
	<!-- End Preload -->
	
	<div id="form_container" class="clearfix">
		<figure>
			<a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(URL::asset('frontend/img_skill/logo_skill.png')); ?>" width="149" height="42" alt=""></a>
		</figure>
		<div id="wizard_container">
			<div id="top-wizard">
				<div id="progressbar"></div>
			</div>
			<!-- /top-wizard -->
			<form name="example-1" id="wrapped" method="POST">
				<input id="website" name="website" type="text" value="">
				<!-- Leave for security protection, read docs for details -->
				<div id="middle-wizard">
				

					<div class=" step step_last_stag">
						<h3 class="main_question text-center">Select the Type of Membership</h3>
						
						
						
					
						<div class="form-group radio_input form_to_retio_for_term" data-bs-toggle="modal" data-bs-target="#standard_membership_table" class="pointer_for_curser">
							<a>Standard Membership</a>
						</div>
				
						
						
						<div class="form-group radio_input form_to_retio_for_term" data-bs-toggle="modal" data-bs-target="#corporate_membership_table" class="pointer_for_curser">
							<a>Corporate Membership</a>
						</div>
						
							
				
						<div class="form-group radio_input form_to_retio_for_term" data-bs-toggle="modal" data-bs-target="#gift_table" class="pointer_for_curser">
							<a>Gift to Friend/Family</a>
						</div>
					</div>
					<!-- /step-->
				</div>
				<!-- /middle-wizard -->
				<div id="bottom-wizard">
					<button type="button" name="backward" class="backward">Backward </button>
					<button type="button" name="forward" class="forward">Forward</button>
					<button type="submit" name="process" class="submit">Submit</button>
				</div>
				<!-- /bottom-wizard -->
			</form>
		</div>
		<!-- /Wizard container -->
	</div>
	<!-- /Form_container -->






<!-- standrad table -->
<div class="modal" id="standard_membership_table">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">

     
      <div class="modal-header">
        <h4 class="modal-title">Standard Membership</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      
      <div class="modal-body">

<section class="memeber_sip_plan_section">
    <div class="container">
    <div>
        <p class="h2 text-center mb-5 choose_your_member_ship_plan">Choose Your MemberShip Plans</p>
    </div>
    <div class="row mt-3">
        <div class="col-md-4">
            <div class="card d-flex align-items-center justify-content-center member_shipp_plans">
                <div class="ribon"><i class="fa fa-book icon_first_member_plan" aria-hidden="true"></i></div>
                <p class="h-1 pt-5 memeber_ship_heading_plan_color">New Born</p>
               
                <span class="price"> <sup class="sup">Rs</sup> <span class="number">199/-</span> </span>
                   <p class="memeber_shipp_plan_month">3 Months</p>
                <ul class="mb-5 list-unstyled text-muted list_for_member_ship_plan">
                    <li><span class="fa fa-check me-2"></span>Foundational Course</li>
                    <li><span class="fa fa-check me-2"></span>Blog</li>
                    <li><span class="fa fa-check me-2"></span>E-book Unlimited Downloads</li>
                    <li><span class="fa fa-check me-2"></span>Monthly Masterclass</li>
                    <li><span class="fa fa-check me-2"></span>Accredited Courses Discounts(5%)</li>
                     <li><span class="fa fa-check me-2"></span>Live Training Events Discounts
(Any Mode)(5%)</li>
                </ul>
                <div class="btn btn-primary"> get started </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card d-flex align-items-center justify-content-center member_shipp_plans">
                <div class="ribon"><i class="fa fa-users icon_first_member_plan" aria-hidden="true"></i></div>
                <p class="h-1 pt-5 memeber_ship_heading_plan_color">Infant</p>
             
                <span class="price"> <sup class="sup">Rs</sup> <span class="number">299/-</span> </span>
                   <p class="memeber_shipp_plan_month">6 Months</p>
                <ul class="mb-5 list-unstyled text-muted list_for_member_ship_plan">
                    <li><span class="fa fa-check me-2"></span>Foundational Course</li>
                    <li><span class="fa fa-check me-2"></span>Blog</li>
                    <li><span class="fa fa-check me-2"></span>E-book Unlimited Downloads</li>
                    <li><span class="fa fa-check me-2"></span>Monthly Masterclass</li>
                    <li><span class="fa fa-check me-2"></span>Accredited Courses Discounts(10%)</li>
                     <li><span class="fa fa-check me-2"></span>Live Training Events Discounts
(Any Mode)(10%)</li>
                </ul>
                <div class="btn btn-primary mb-1"> get started </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card d-flex align-items-center justify-content-center member_shipp_plans">
                <div class="ribon"><i class="fa fa-address-book  icon_first_member_plan" aria-hidden="true"></i> </div>
                <p class="h-1 pt-5 memeber_ship_heading_plan_color">Toddler</p>
                
                <span class="price"> <sup class="sup">Rs</sup> <span class="number">499/-</span> </span>
                  <p class="memeber_shipp_plan_month">12 Months</p>
                <ul class="mb-5 list-unstyled text-muted list_for_member_ship_plan">
                    <li><span class="fa fa-check me-2"></span>Foundational Course</li>
                    <li><span class="fa fa-check me-2"></span>Blog</li>
                    <li><span class="fa fa-check me-2"></span>E-book Unlimited Downloads</li>
                    <li><span class="fa fa-check me-2"></span>Monthly Masterclass</li>
                    <li><span class="fa fa-check me-2"></span>Accredited Courses Discounts(20%)</li>
                     <li><span class="fa fa-check me-2"></span>Live Training Events Discounts
(Any Mode)(20%)</li>
                </ul>
                <div class="btn btn-primary"> get started </div>
            </div>
        </div>

    </div>
</div>
</section>
      </div>

    
      <div class="modal-footer">
        <!--<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>-->

      </div>

    </div>
  </div>
</div>


<div class="modal" id="corporate_membership_table">
  <div class="modal-dialog modal-dialog-scrollable modal-lg">
    <div class="modal-content">

     
      <div class="modal-header">
        <h4 class="modal-title">Corporate Membership</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      
      <div class="modal-body">
          <div class="row">
              <div class="col-md-8">
                  <div class="add_employee_main">
                      <h4>Add Employee</h4>
                      <a class="btn btn-primary" id="add_empoylee"><i class="fa fa-plus" aria-hidden="true"></i></a>
                      <div>
                      <div class="append_data_main">
                          <form action="/action_page.php">
                          <div class="row">
                              <div class="col-md-4">
                                   <div class="">
                                    <label for="name" class="form-label">Name:</label>
                                    <input type="text" class="form-control" placeholder="Enter Name" name="name">
                                  </div>
                              </div>
                               <div class="col-md-4">
                                   <div class="">
                                    <label for="email" class="form-label">Email:</label>
                                    <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
                                  </div>
                               </div>
                               <div class="col-md-4">
                                    <div class="">
                                    <label for="amount" class="form-label">Amount:</label>
                                    <input type="number" class="form-control" placeholder="Enter Amount" name="amount">
                                  </div>
                               </div>
                          </div>
                           </form>
                      </div>
                      </div>
                      
                      
                  </div>
              </div>
              <div class="col-md-4">
                  <div class="sub_total_main">
                      <ul class="list-group">
                          <li class="list-group-item d-flex justify-content-between align-items-center">
                            Sub Tolal
                            <span class="">1400</span>
                          </li>
                          <li class="list-group-item d-flex justify-content-between align-items-center">
                            Discount
                            <span class="">20%</span>
                          </li>
                          <li class="list-group-item d-flex justify-content-between align-items-center">
                            GST
                            <span class="">18%</span>
                          </li>
                          <li class="list-group-item d-flex justify-content-between align-items-center">
                            Total
                            <span class="badge bg-primary rounded-pill">2000</span>
                          </li>
                        </ul>
                  </div>
              </div>
          </div>
      </div>

    
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


<div class="modal" id="gift_table">
  <div class="modal-dialog modal-dialog-scrollable modal-lg">
    <div class="modal-content">

     
      <div class="modal-header">
        <h4 class="modal-title">Gift to Friend/Family</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      
      <div class="modal-body">
          <div class="row">
              <div class="col-md-8">
                  <div class="add_gift_main">
                      <h4>Add Employee</h4>
                      <a class="btn btn-primary" onclick="appendText()" id="add_empoylee"><i class="fa fa-plus" aria-hidden="true"></i></a>
                      <div>
                      <div class="gift_main_inner">
                          <form action="/action_page.php">
                              <div class="append_gift_main">
                          <div class="row">
                              <div class="col-md-4">
                                   <div class="">
                                    <label for="name" class="form-label">Name:</label>
                                    <input type="text" class="form-control" placeholder="Enter Name" name="name">
                                  </div>
                              </div>
                               <div class="col-md-4">
                                   <div class="">
                                    <label for="email" class="form-label">Email:</label>
                                    <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
                                  </div>
                               </div>
                               <div class="col-md-4">
                                    <div class="">
                                    <label for="amount" class="form-label">Amount:</label>
                                    <input type="number" class="form-control" placeholder="Enter Amount" name="amount">
                                  </div>
                               </div>
                          </div>
                          </div>
                           </form>
                      </div>
                      </div>
                      
                      
                  </div>
              </div>
              <div class="col-md-4">
                  <div class="sub_total_main">
                      <ul class="list-group">
                          <li class="list-group-item d-flex justify-content-between align-items-center">
                            Sub Tolal
                            <span class="">1400</span>
                          </li>
                          <li class="list-group-item d-flex justify-content-between align-items-center">
                            Discount
                            <span class="">20%</span>
                          </li>
                          <li class="list-group-item d-flex justify-content-between align-items-center">
                            GST
                            <span class="">18%</span>
                          </li>
                          <li class="list-group-item d-flex justify-content-between align-items-center">
                            Total
                            <span class="badge bg-primary rounded-pill">2000</span>
                          </li>
                        </ul>
                  </div>
              </div>
          </div>
         </div>

    
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script>
$(document).ready(function(){
  $("#add_empoylee").click(function(){
    $(".append_data_main").append('<form action="" method="post"><div class="append_gift_main"><div class="row"><div class="col-md-4"><div class=""><label for="name" class="form-label">Name:</label><input type="text" class="form-control" placeholder="Enter Name" name="name"></div></div><div class="col-md-4"><div class=""><label for="email" class="form-label">Email:</label><input type="email" class="form-control" id="email" placeholder="Enter email" name="email"></div></div><div class="col-md-4"><div class=""><label for="amount" class="form-label">Amount:</label><input type="number" class="form-control" placeholder="Enter Amount" name="amount"></div></div></div></div></form>');
  });
});
</script>
	
<script>
function appendText() {
  var txt1 = '<form action=""><div class="append_gift_main"><div class="row"><div class="col-md-4"><div class=""><label for="name" class="form-label">Name:</label><input type="text" class="form-control" placeholder="Enter Name" name="name"></div></div><div class="col-md-4"><div class=""><label for="email" class="form-label">Email:</label><input type="email" class="form-control" id="email" placeholder="Enter email" name="email"></div></div><div class="col-md-4"><div class=""><label for="amount" class="form-label">Amount:</label> <input type="number" class="form-control" placeholder="Enter Amount" name="amount"></div></div></div></div></form>';
  $(".gift_main_inner").append(txt1);   
}
</script>



	<!-- COMMON SCRIPTS -->
    <!--<script src="<?php echo e(URL::asset('frontend/js/jquery-3.6.0.min.js')); ?>"></script>-->
    <script src="<?php echo e(URL::asset('frontend/js/common_scripts.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('frontend/js/main_admission.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('frontend/assets/validate.js')); ?>"></script>
	
	<!-- SPECIFIC SCRIPTS -->
	<script src="<?php echo e(URL::asset('frontend/js/jquery-ui-1.8.22.min.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('frontend/js/jquery.wizard.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('frontend/js/jquery.validate.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('frontend/js/admission_func.js')); ?>"></script>

</body>

</html><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/membership_plan.blade.php ENDPATH**/ ?>