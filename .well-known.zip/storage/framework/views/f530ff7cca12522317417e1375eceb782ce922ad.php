
<?php $__env->startSection('content'); ?>

<?php 

$data = App\Models\Bnner::first();

?>

<section id="hero_in" class="contacts" style="background-image:url(<?php echo e(url('uploads/banners/support_banner/'.$data['support_banner'])); ?>)">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span><?php echo e($data->support_banner_title); ?></h1>
				</div>
			</div>
		</section>
		<!--/hero_in-->

		<div class="contact_info">
			<div class="container">
				<ul class="clearfix">
					<li>
						<i class="pe-7s-map-marker"></i>
						<h4>Address</h4>
						<span><?php echo e($web->address); ?></span>
					</li>
					<li>
						<i class="pe-7s-mail-open-file"></i>
						<h4>Email address</h4>
						<span><?php echo e($web->email); ?><br><small>Monday to Friday 9am - 7pm</small></span>

					</li>
					<li>
						<i class="pe-7s-phone"></i>
						<h4>Contacts info</h4>
						<span><?php echo e($web->mobile); ?><br><small>Monday to Friday 9am - 7pm</small></span>
					</li>
				</ul>
			</div>
		</div>
		<!--/contact_info-->

		<div class="bg_color_1">
			<div class="container margin_120_95">
				<div class="row justify-content-between">
				
					<div class="col-md-3"></div>
					<div class="col-md-6">
					
				
		<div class="contact_us_form_div">

	<h4 class="send_message_contact_form">Send a message</h4>
	
	                       <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                             <form class="form_contact_skilluva_first" method="post" action="<?php echo e(url('add_contact')); ?>">
                                 <div class="row">
                                     <?php echo csrf_field(); ?>
<div class="col-md-12">
    <input type="text" class="form-control input_type_first_teb_design" name="name" id="exampleInputEmail1" placeholder="Enter Your Name">
  </div>
  
  <div class="col-md-12 mt-3">
    <input type="email" class="form-control input_type_first_teb_design" name="email" id="exampleInputEmail1" placeholder="Enter Your Email">
  </div><br>
  
  <div class="col-md-12 mt-3">
    <input type="text" class="form-control input_type_first_teb_design" name="sub" id="exampleInputPassword1" placeholder="Subject">
  </div><br>
  
<div class="col-md-12 mt-3">
  <textarea class="form-control input_type_first_teb_design" name="msg" id="exampleFormControlTextarea1" rows="3" placeholder="Message"></textarea>
</div><br>

   <div class="col-md-12 mt-3">
      <button type="submit" name="submit" class="btn btn-primary submit_contact_form_in_skill_uva">Submit</button>
  </div>
  
  </div>
</form>
		</div>
					</div>
					<div class="col-md-3"></div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /bg_color_1 -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/contact.blade.php ENDPATH**/ ?>