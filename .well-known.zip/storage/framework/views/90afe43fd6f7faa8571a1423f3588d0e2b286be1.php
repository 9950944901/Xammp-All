
<?php $__env->startSection('content'); ?>
<style>
.section_first_teb{

}
.section_first_teb p{
    color:white;
    height:50px;
}
.Advanced{
       text-align: center; 
}
.counter_main {
    display: flex;
    align-items: center;
    justify-content: center;
}
.counter_main h3 {
    font-size: 40px;
    color: #ffb606;
    font-weight: 700;
}

a.btn_explore:hover {
    bottom: 30px;
    color: #000 !important;
}
.text_color {
   filter: brightness(0.5);
    z-index: 99999 !important;
}

.counter {
    z-index: 99999999 !important;
    filter: drop-shadow(2px 4px 6px black);
}
/*<!--carosel-->*/
    @media (max-width: 767px){.carousel-inner .carousel-item >div{display: none}.carousel-inner .carousel-item
    >div:first-child{display: block}}.carousel-inner .carousel-item.active, .carousel-inner .carousel-item-next,
.carousel-inner .carousel-item-prev{display: flex}@media (min-width: 768px){.carousel-inner .carousel-item-end.active,
.carousel-inner .carousel-item-next{transform: translateX(25%)}.carousel-inner .carousel-item-start.active,
.carousel-inner .carousel-item-prev{transform: translateX(-25%)}}.carousel-inner .carousel-item-end, .carousel-inner
.carousel-item-start{transform: translateX(0)}

.student_color{
    color: white;
}

.ebook_main .swiper-slide img {
    width: 100%;
}

p.Trainers {
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
}

.aggrete_dots .owl-carousel .owl-dots.disabled{
    display: block;
}


@media(max-width:768px){
.vedio_section_term {
    height: 180px;
    background: rgb(0,0,0,0.9);
}

#hero_video div {
    display: table-cell;
    vertical-align: middle;
    text-align: center;
    padding: 0 3%;
}

#hero_video div p {
    padding: 0;
    font-size: 18px;
    font-size: 0.900rem;
}

#hero_video div h3 {
    font-size: 23px;
    font-size: 1rem;
    margin-top: 40px;
}
}
</style>

<?php 

$data = App\Models\Bnner::first();

?>

	<section >
	    <div class="vedio_section_term">
	           <video width="100%" class="vedio_lop_main" loop muted autoplay style="margin-bottom: -6px;">
                    <source src="<?php echo e(URL::asset('frontend/img_skill/7_sec.mp4')); ?>" type="video/mp4">
                </video>
	   
			<div id="hero_video">
				<div>
					<h3><strong><?php echo e($data['home_banner_title_2']); ?></strong><br><?php echo e($data['home_banner_title_1']); ?></h3>
					<p><?php echo e($data['home_banner_title_3']); ?></p>
				</div>
				<a href="#first_section" class="btn_explore hidden_tablet"><i class="ti-arrow-down"></i></a>
			</div>
		</div>
		</section>
		<!-- /header-video Jarallax -->

		<ul id="grid_home" class="clearfix">
			<li>
				<a href="#0" class="img_container">
					<img src="<?php echo e(URL::asset('frontend/img_skill/grid_home_1.jpg')); ?>" alt="">
					<div class="short_info">
						<h3><strong>Foundational </strong>Courses</h3>
						<div><span class="btn_1 rounded">Read more</span></div>
					</div>
				</a>
			</li>
			<li>
				<a href="#0" class="img_container">
					<img src="<?php echo e(URL::asset('frontend/img_skill/grid_home_1.jpg')); ?>" alt="">
					<div class="short_info">
						<h3><strong>Aggregate</strong>Courses</h3>
						<div><span class="btn_1 rounded">Read more</span></div>
					</div>
				</a>
			</li>
			<li>
				<a href="<?php echo e(url('admission')); ?>" class="img_container">
					<img src="<?php echo e(URL::asset('frontend/img_skill/grid_home_1.jpg')); ?>" alt="">
					<div class="short_info">
						<h3><strong>Membership</strong>Plan</h3>
						<!--<div><span class="btn_1 rounded">Submit</span></div>-->
						<div><span class="btn_1 rounded">Read more</span></div>
					</div>
				</a>
			</li>
		</ul>


<!--home page slider start======================================-->
<!--<section class="slider">-->
<!--			<div id="slider" class="flexslider">-->
<!--				<ul class="slides">-->
<!--					<li>-->
<!--						<img src="<?php echo e(URL::asset('frontend/img_skill/home_page_banner/home_banner1.jpg')); ?>" alt="">-->
<!--						<div class="meta">-->
<!--							<h3>LMS Advanced Course</h3>-->
<!--							<div class="info">-->
<!--								<p><strong>15</strong> Lessons - <strong>10</strong> Videos</p>-->
<!--							</div>-->
<!--							<a href="<?php echo e(url('course-details')); ?>" class="btn_1">Course By</a>-->
<!--						</div>-->
<!--					</li>-->
<!--					<li>-->
<!--						<img src="<?php echo e(URL::asset('frontend/img_skill/home_page_banner/home_banner2.png')); ?>" alt="">-->
<!--						<div class="meta">-->
<!--							<h3>Trending Courses</h3>-->
<!--							<div class="info">-->
<!--								<p><strong>25</strong> Lessons - <strong>20</strong> Videos</p>-->
<!--							</div>-->
<!--							<a href="<?php echo e(url('course-details')); ?>" class="btn_1">Course By</a>-->
<!--						</div>-->
<!--					</li>-->
<!--					<li>-->
<!--						<img src="<?php echo e(URL::asset('frontend/img_skill/home_page_banner/home_banner3.png')); ?>" alt="">-->
<!--						<div class="meta">-->
<!--							<h3> Best Selling Traning Courseware</h3>-->
<!--							<div class="info">-->
<!--								<p><strong>25</strong> Lessons - <strong>20</strong> Videos</p>-->
<!--							</div>-->
<!--							<a href="<?php echo e(url('course-details')); ?>" class="btn_1">Course By</a>-->
<!--						</div>-->
<!--					</li>-->
<!--					<li>-->
<!--						<img src="<?php echo e(URL::asset('frontend/img_skill/home_page_banner/home_banner4.png')); ?>" alt="">-->
<!--						<div class="meta">-->
<!--							<h3>Best Selling EBooks</h3>-->
<!--							<div class="info">-->
<!--								<p><strong>25</strong> Lessons - <strong>20</strong> Videos</p>-->
<!--							</div>-->
<!--							<a href="<?php echo e(url('course-details')); ?>" class="btn_1">Course By</a>-->
<!--						</div>-->
<!--					</li>-->
<!--				</ul>-->
<!--				<div id="icon_drag_mobile"></div>-->
<!--			</div>-->
<!--			<div id="carousel_slider_wp">-->
<!--				<div id="carousel_slider" class="flexslider">-->
<!--					<ul class="slides">-->
<!--						<li>-->
<!--							<img src="<?php echo e(URL::asset('frontend/img_skill/home_page_banner/home_banner1.jpg')); ?>" alt="">-->
<!--							<div class="caption">-->
<!--								<h3>LMS Advanced <span>Course</span></h3>-->
<!--								<small>$75 <em>$275</em></small>-->
<!--							</div>-->
<!--						</li>-->
<!--						<li>-->
<!--							<img src="<?php echo e(URL::asset('frontend/img_skill/home_page_banner/home_banner2.png')); ?>" alt="">-->
<!--							<div class="caption">-->
<!--								<h3>Best Selling <span>Course</span></h3>-->
<!--								<small>$85 <em>$320</em></small>-->
<!--							</div>-->
<!--						</li>-->
<!--						<li>-->
<!--							<img src="<?php echo e(URL::asset('frontend/img_skill/home_page_banner/home_banner3.png')); ?>" alt="">-->
<!--							<div class="caption">-->
<!--								<h3>Best Selling Traning <span>Course</span></h3>-->
<!--								<small>$55 <em>$150</em></small>-->
<!--							</div>-->
<!--						</li>-->
<!--						<li>-->
<!--							<img src="<?php echo e(URL::asset('frontend/img_skill/home_page_banner/home_banner4.png')); ?>" alt="">-->
<!--							<div class="caption">-->
<!--								<h3>Best Selling<span>Course</span></h3>-->
<!--								<small>$95 <em>$280</em></small>-->
<!--							</div>-->
<!--						</li>-->
<!--					</ul>-->
<!--				</div>-->
<!--			</div>-->
<!--</section>-->
<?php 

$data = App\Models\Bnner::first();

?>










<!--<section class="slider">-->
<!--			<div id="slider" class="flexslider">-->
<!--				<ul class="slides">-->
<!--					<li>-->
<!--						<img src="<?php echo e(url('uploads/banners/home_banner/'.$data['home_banner'])); ?>" alt="">-->
<!--						<div class="meta">-->
						    
						    
<!--<h1>-->
<!--  <a  class="typewrite text-white typerer_css_skilluva" data-period="2000" data-type='[ "Hi, Im Si.", "I am Creative.", "I Love Design.", "I Love to Develop." ]'>-->
<!--    <span class="wrap"></span>-->
<!--  </a>-->
<!--</h1>-->
<!--						    <h3 class="text-center skill_development_h1"><?php echo e($data['home_banner_title_2']); ?></h3>-->
<!--							<h3 class="text-center skill_development_h2"><?php echo e($data['home_banner_title_1']); ?></h3>-->
							
<!--							<h3 class="text-center skill_development_h3"><?php echo e($data['home_banner_title_3']); ?></h3>-->

<!--							<div class="info">-->
								<!--<p><strong>15</strong> Lessons - <strong>10</strong> Videos</p>-->
<!--							</div>-->
							<!--<a href="<?php echo e(url('course-details')); ?>" class="btn_1">Course By</a>-->
<!--						</div>-->
<!--					</li>-->
<!--				</ul>-->
<!--				<div id="icon_drag_mobile"></div>-->
<!--			</div>-->

<!--		</section>-->

<!--section best selling course=======================================-->
<section>
    
    
    
    <div class="container-fluid margin_120_0 aggrete_dots">
			<div class="main_title_2">
				<span><em></em></span>
				<h2 id="first_section">Trending Aggregate Courses</h2>
				<p>Here are our top Selling Courses, Get one for Yourself Now.</p>
			</div>
			<div id="reccomended" class="owl-carousel owl-theme">
			    <?php 

$course = App\Models\course::where('status','1')->where('course_type','advance')->get();

?>


<?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coursees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="item">
					<div class="box_grid">
						<figure>
							<a href="#0" class="wish_bt"></a>
							<a href="<?php echo e(url('course-details'.$coursees->id)); ?>">
								<div class="preview"><span>Preview course</span></div>
								<div class="img_tranding_layout">
								<img src="<?php echo e(url('uploads/advancecourse/image/'.$coursees->image)); ?>" class="img-fluid" alt="">
								</div>
								</a>
							<div class="price">₹<?php echo e($coursees->cprice); ?></div>

						</figure>
						<div class="wrapper">
							<small>Skilluva</small>
							<!--<h3>Time Management For Entrepreneurs</h3>-->
							<p class="tranding_description"><?php echo e($coursees->ctitle); ?></p>
							<div class="rating"><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star"></i><i class="icon_star"></i> <small>(145)</small></div>
						</div>
						<ul>
							<li> ₹<?php echo e($coursees->cmrp); ?></li>
							<li> ₹<?php echo e($coursees->cprice); ?></li>
							<li><a href="<?php echo e(url('course-details'.$coursees->id)); ?>">Preview</a></li>
						</ul>
					</div>
				</div>
				
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<!-- /item -->
			        
			</div>
			<!-- /carousel -->
				<div class="container">
            				<p class="btn_home_align"><a href="advanced-course" class="btn_1 rounded">View all courses</a></p>
            			</div>
		
			<hr>
		</div>
</section>	

<!--Bootstrap Multi Slide Carousel=======================================-->
<section class="images_slider_bar">
<div class="container text-center my-3">
    	<div class="main_title_2">
				<span><em></em></span>
					<h2>Trending Foundational Courses</h2>
				<p class="mt-2">Here are our top Selling Courses, Get one for Yourself Now.</p>
			</div>
    <div class="row mx-auto my-auto justify-content-center">
        <div id="recipeCarousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner" role="listbox">
                
                <?php 
                
                $courses= App\Models\Foundational_course::where('status','1')->get();
                
                ?>
                
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="carousel-item  <?php echo e($key == 0 ? 'active' : ''); ?>">
                  <div class="col-md-3">
                      <a href="<?php echo e(url('basic-course')); ?>">
                        <div class="card">
                            <div class="card-img"> 
                            <div class="best_selling_section">
                            <img class="home_page_slider" src="<?php echo e(url('uploads/Foundational_course/image/'.$list->image)); ?>" class="img-fluid ebook_libray_skill_yua">
                            </div>
                            </div>
                                     <div class="images_span">
                             <p class="Trainers"><?php echo e($list['title']); ?></p>
                             <p class="Trainers">SkillUVA</p>
                                <span><i class="fa fa-group price Trainers"></i></span><span><i class="fa fa-comment price Trainers"> <span class="ml-1"> 0</span></i></span>
							                <span class="course-origin-price"><del class="text-danger">₹ &nbsp;<?php echo e($list['mrp']); ?></del></span><span class="price11">₹ &nbsp;<?php echo e($list['price']); ?> </span>
                            </div>
                        </div>
                        </a>
                    </div>
                </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div> 
            <a class="carousel-control-prev bg-transparent w-aut" href="#recipeCarousel" role="button"
                data-bs-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true">
                    <i class="fa fa-chevron-left" style="color: black; font-size: 30px;" aria-hidden="true"></i></span> </a>
                    <a
                class="carousel-control-next bg-transparent w-aut" href="#recipeCarousel" role="button"
                data-bs-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true">
                    <i class="fa fa-chevron-right" style="color: black; font-size: 30px;" aria-hidden="true"></i></span> </a>
        </div>
    </div>
</div>
</section>


<section class="category_section_start">
    <div class="container margin_30_95">
			<div class="main_title_2">
				<span><em></em></span>
				<h2> Categories Courses</h2>
				<p>Cum doctus civibus efficiantur in imperdiet deterruisset.</p>
			</div>
			<div class="row">
				<div class="col-lg-4 col-md-6 wow" data-wow-offset="150">
					<a href="#0" class="grid_item">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="<?php echo e(URL::asset('frontend/img_skill/course_1.jpg')); ?>" class="img-fluid" alt="">
							<div class="info">
								<small><i class="ti-layers"></i>15 Programmes</small>
								<h3>Arts and Humanities</h3>
							</div>
						</figure>
					</a>
				</div>
				<!-- /grid_item -->
				<div class="col-lg-4 col-md-6 wow" data-wow-offset="150">
					<a href="#0" class="grid_item">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="<?php echo e(URL::asset('frontend/img_skill/course_2.jpg')); ?>" class="img-fluid" alt="">
							<div class="info">
								<small><i class="ti-layers"></i>23 Programmes</small>
								<h3>Engineering</h3>
							</div>
						</figure>
					</a>
				</div>
				<!-- /grid_item -->
				<div class="col-lg-4 col-md-6 wow" data-wow-offset="150">
					<a href="#0" class="grid_item">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="<?php echo e(URL::asset('frontend/img_skill/course_3.jpg')); ?>" class="img-fluid" alt="">
							<div class="info">
								<small><i class="ti-layers"></i>23 Programmes</small>
								<h3>Architecture</h3>
							</div>
						</figure>
					</a>
				</div>
				<!-- /grid_item -->
				<div class="col-lg-4 col-md-6 wow" data-wow-offset="150">
					<a href="#0" class="grid_item">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="<?php echo e(URL::asset('frontend/img_skill/course_4.jpg')); ?>" class="img-fluid" alt="">
							<div class="info">
								<small><i class="ti-layers"></i>23 Programmes</small>
								<h3>Science and Biology</h3>
							</div>
						</figure>
					</a>
				</div>
				<!-- /grid_item -->
				<div class="col-lg-4 col-md-6 wow" data-wow-offset="150">
					<a href="#0" class="grid_item">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="<?php echo e(URL::asset('frontend/img_skill/course_5.jpg')); ?>" class="img-fluid" alt="">
							<div class="info">
								<small><i class="ti-layers"></i>23 Programmes</small>
								<h3>Law and Criminology</h3>
							</div>
						</figure>
					</a>
				</div>
				<!-- /grid_item -->
				<div class="col-lg-4 col-md-6 wow" data-wow-offset="150">
					<a href="#0" class="grid_item">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="<?php echo e(URL::asset('frontend/img_skill/course_6.jpg')); ?>" class="img-fluid" alt="">
							<div class="info">
								<small><i class="ti-layers"></i>23 Programmes</small>
								<h3>Medical</h3>
							</div>
						</figure>
					</a>
				</div>
				<!-- /grid_item -->
			</div>
			<!-- /row -->
		</div>
    
</section>


<section class="about_newssec">
    <div class="bg_color_1">
			<div class="container margin_120_95">
				<div class="main_title_2">
					<span><em></em></span>
					<h2>Blogs</h2>
					<p>News and Events...</p>
				</div>
				<div class="row">
				    
				<?php 
                
                $blogs= App\Models\Blog::where('status','1')->take(4)->get();;
                
                ?>
                
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-lg-6">
						<a class="box_news" href="<?php echo e(url('blog_details'.$list->id)); ?>">
							<figure><img  src="<?php echo e(url('uploads/blog_images/'.$list->blog_img)); ?>" alt="">
								<!--<figcaption><strong>28</strong>Dec</figcaption>-->
							</figure>
							<ul>
								<li><?php echo e($list['auther_name']); ?></li>
								<li><?php echo e($list['created_at']); ?></li>
							</ul>
							<h4><?php echo e($list['title']); ?></h4>
							<div class="blog_descr_main">
							<p><?php echo $list['description']; ?></p>
							</div>
						</a>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
					
					<!-- /box_news -->
					<!--<div class="col-lg-6">-->
					<!--	<a class="box_news" href="<?php echo e(url('blog-details')); ?>">-->
					<!--		<figure><img src="<?php echo e(URL::asset('frontend/img_skill/news_home_2.jpg')); ?>" alt="">-->
					<!--			<figcaption><strong>28</strong>Dec</figcaption>-->
					<!--		</figure>-->
					<!--		<ul>-->
					<!--			<li>Jhon Doe</li>-->
					<!--			<li>20.11.2017</li>-->
					<!--		</ul>-->
					<!--		<h4>Duo eius postea suscipit ad</h4>-->
					<!--		<p>Cu eum alia elit, usu in eius appareat, deleniti sapientem honestatis eos ex. In ius esse ullum vidisse....</p>-->
					<!--	</a>-->
					<!--</div>-->
					<!-- /box_news -->
					<!--<div class="col-lg-6">-->
					<!--	<a class="box_news" href="<?php echo e(url('blog-details')); ?>">-->
					<!--		<figure><img src="<?php echo e(URL::asset('frontend/img_skill/news_home_3.jpg')); ?>" alt="">-->
					<!--			<figcaption><strong>28</strong>Dec</figcaption>-->
					<!--		</figure>-->
					<!--		<ul>-->
					<!--			<li>Luca Robinson</li>-->
					<!--			<li>20.11.2017</li>-->
					<!--		</ul>-->
					<!--		<h4>Elitr mandamus cu has</h4>-->
					<!--		<p>Cu eum alia elit, usu in eius appareat, deleniti sapientem honestatis eos ex. In ius esse ullum vidisse....</p>-->
					<!--	</a>-->
					<!--</div>-->
					<!-- /box_news -->
					<!--<div class="col-lg-6">-->
					<!--	<a class="box_news" href="<?php echo e(url('blog-details')); ?>">-->
					<!--		<figure><img src="<?php echo e(URL::asset('frontend/img_skill/news_home_4.jpg')); ?>" alt="">-->
					<!--			<figcaption><strong>28</strong>Dec</figcaption>-->
					<!--		</figure>-->
					<!--		<ul>-->
					<!--			<li>Paula Rodrigez</li>-->
					<!--			<li>20.11.2017</li>-->
					<!--		</ul>-->
					<!--		<h4>Id est adhuc ignota delenit</h4>-->
					<!--		<p>Cu eum alia elit, usu in eius appareat, deleniti sapientem honestatis eos ex. In ius esse ullum vidisse....</p>-->
					<!--	</a>-->
					<!--</div>-->
					<!-- /box_news -->
				</div>
				<!-- /row -->
				<p class="btn_home_align"><a href="<?php echo e(('blog')); ?>" class="btn_1 rounded">View all news</a></p>
			</div>
			<!-- /container -->
		</div>
</section>



<section class="images_slider_bar">
<div class="container text-center my-3">
    	<div class="main_title_2">
				<span><em></em></span>
					<h2>Trending eBooks Courses</h2>
				<p class="mt-2">Here are our top Selling Courses, Get one for Yourself Now.</p>
			</div>
    <div class="row">
        <?php 
                
                $book= App\Models\course::where('status','1')->where('course_type','Ebook')->orderby('id','DESC')->take(4)->get();
                
                ?>
                
                <?php $__currentLoopData = $book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-md-3">
                     <a href="<?php echo e(url('ebook')); ?>" class="home_page_ebook_libry_index">
                        <div class="card">
                            <div class="card-img">
                                <div class="imgage_first_download_div">
                                <img src="<?php echo e(url('uploads/advancecourse/image/'.$boo->image)); ?>" class="img-fluid imgage_first_download_div_img">
                                </div>
                                </div>
                                     <div class="images_span">
                             <p  class="Trainers"><?php echo e($boo->ctitle); ?></p>
                             <p  class="Trainers"><?php echo e($boo->cname); ?></p>
                                <span><i class="fa fa-group price Trainers"></i></span><span><i class="fa fa-comment price Trainers"><span class="ml-1">0</span></i></span>
							                <span class="course-origin-price"><del class="text-danger">₹<?php echo e($boo->cmrp); ?></del></span><span class="price11">₹<?php echo e($boo->cprice); ?></span>
                            </div>
                        </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
    </div>
</div>
</section>
<div class="container margin_120_95 our_trainers_main">
			<div class="main_title_2">
				<span><em></em></span>
				<h2>Tranding Our Trainers </h2>
				<p class="mt-2">Here is our Top Trainers, Choose one for you Now.</p>
			</div>
			<div id="carousel" class="owl-carousel owl-theme">
			    
			 <?php 
                $Trainer= App\Models\user::where('type','Trainer')->limit(8)->get();
            ?>
                
                <?php $__currentLoopData = $Trainer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $train): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="item">
					<a href="#0">
						<div class="title">
							<h4><?php echo e($train->fname); ?>&nbsp;<?php echo e($train->lname); ?>

						
							</h4>
						</div>
						<div class="trainers_image_fit">
						    <img src="<?php echo e(url('uploads/user_images/'.$train->image)); ?>"  alt="">
						</div>
					</a>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<!-- /carousel -->
		</div>
<!--testimonial section end-->
<!--js counter start============================================================-->
<!--<section class="counts-section section_images">-->
<!--            <div class="overlay_counter">&nbsp;</div>-->
<!--            <div class="our_achievment_main">-->
<!--                <h1 class="text_color my-5">Our Achievement</h1>-->
<!--                <div class=" text-white">-->
<!--                    <div class="container">-->
<!--                        <div class="row">-->
<!--                            <div class="col-md-3 text-center span_pan">                            -->
<!--                               <div class="counter" style="border-right: 1px solid;">-->
<!--                    <div class="counter_main"> -->
<!--                    <h3 data-target="15000" class="count1">0</h3>-->
<!--                    <h3> +</h3>-->
<!--                    </div>-->
<!--                    <h6 class="student_color">STUDENTS</h6>-->
<!--                </div>-->
<!--                            </div>-->
<!--                            <div class="col-md-3 text-center span_pan">-->
<!--                               <div class="counter" style="border-right: 1px solid;">-->
<!--                    <div class="counter_main"> -->
<!--                    <h3 data-target="1200" class="count1">0</h3>-->
<!--                    <h3> +</h3>-->
<!--                    </div>-->
<!--                    <h6 class="student_color">COURSES</h6>-->
<!--                </div>-->
<!--                            </div>-->
<!--                            <div class="col-md-3 text-center span_pan">-->
<!--                            <div class="counter" style="border-right: 1px solid;">-->
                      
<!--                      <div class="counter_main">         -->
<!--                    <h3 data-target="500" class="count1">0</h3>-->
<!--                   <h3> +</h3>-->
<!--                   </div>-->
<!--                    <h6 class="student_color">ACTIVE LEARNERS</h6>-->
<!--                </div>-->
<!--                            </div>-->
<!--                            <div class="col-md-3 text-center span_pan">-->
<!--                               <div class="counter">-->
                                   
<!--                    <div class="counter_main">   -->
<!--                    <h3 data-target="300" class="count1">0</h3>-->
<!--                    <h3> +</h3>-->
<!--                    </div>-->
<!--                    <h6 class="student_color">CERTIFICATIONS</h6>-->
<!--                </div>-->
<!--                            </div>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </section>-->
   <!--carosel   =============================================  -->
   <section class="counts-section section_images">
       <div class="overlay_for_counter_section"></div>
    <div class="container js_counter_for_section">
      <div class="count-area" data-diff="100">
        <div class="row">
            <div class="col-md-3">
                <div class="count-area-content">
                    <div class="count-icon">  <i class="fa fa-home"></i></div>
                    <div class="count-digit">15000</div>
                    <div class="count-title"><h6 class="student_color">STUDENTS</h6></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="count-area-content">
                    <div class="count-icon"><i class="fa fa-graduation-cap"></i></div>
                    <div class="count-digit">12000</div>
                    <div class="count-title"><h6 class="student_color">COURSES</h6></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="count-area-content">
                    <div class="count-icon">  <i class="fa fa-user"></i></div>
                    <div class="count-digit">5000</div>
                    <div class="count-title"><h6 class="student_color">ACTIVE LEARNERS</h6></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="count-area-content">
                    <div class="count-icon">  <i class="fa fa-book"></i></div>
                    <div class="count-digit">3000</div>
                    <div class="count-title"> <h6 class="student_color">CERTIFICATIONS</h6></div>
                </div>
            </div>
        </div>
    </div>
  </div>
   </section>
   
   
   <section>
       <div class="subscribe_main">
           <div class="container">
               <div class="subscribeux text-center mb-5">
                   <h4 class="text-white">News Letter</h4>
                   <span class="text-white">Subscribe UX</span>
               </div>
               
               <form>
                  <div class="row">
                    <div class="col">
                      <input type="text" name="name" placeholder="Enter Name" class="form-control" required>
                    </div>
                    <div class="col">
                      <input type="email" name="email" placeholder="Enter Email" class="form-control" required>
                    </div>
                    <div class="col">
                      <input type="number" name="mobile" placeholder="Enter Mobile" class="form-control" required>
                    </div>
                    <div class="col">
                      <button type="submit" class="form-control" >SUBSCRIBE</button>
                    </div>
                  </div>
               </form>
           </div>
       </div>
   </section>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script>
       function visible(partial) {
    var $t = partial,
        $w = jQuery(window),
        viewTop = $w.scrollTop(),
        viewBottom = viewTop + $w.height(),
        _top = $t.offset().top,
        _bottom = _top + $t.height(),
        compareTop = partial === true ? _bottom : _top,
        compareBottom = partial === true ? _top : _bottom;

    return ((compareBottom <= viewBottom) && (compareTop >= viewTop) && $t.is(':visible'));

}

$(window).scroll(function(){

  if(visible($('.count-digit')))
    {
      if($('.count-digit').hasClass('counter-loaded')) return;
      $('.count-digit').addClass('counter-loaded');
      
$('.count-digit').each(function () {
  var $this = $(this);
  jQuery({ Counter: 0 }).animate({ Counter: $this.text() }, {
    duration: 5000,
    easing: 'swing',
    step: function () {
      $this.text(Math.ceil(this.Counter));
    }
  });
});
    }
})
   </script>
<!--js by skill js counter===================================-->
  <script>
    const counters = document.querySelectorAll(".count1");
    const speed = 200;
    counters.forEach((counter) => {
    const updateCount = () => {
    const target = parseInt(+counter.getAttribute("data-target"));
    const count1 = parseInt(+counter.innerText);
    const increment = Math.trunc(target / speed);
    console.log(increment);
    if (count1 < target) {
      counter.innerText = count1 + increment;
      setTimeout(updateCount, 1);
    } else {
      count1.innerText = target;
    }
   };
    updateCount();
   });
 </script>
<!--js by skill js counter===================================-->
 <script>
     let items = document.querySelectorAll('.carousel .carousel-item')
     items.forEach((el) => {
    const minPerSlide = 4
    let next = el.nextElementSibling
    for (var i=1; i<minPerSlide; i++) {
        if (!next) {
        	next = items[0]
      	}
        let cloneChild = next.cloneNode(true)
        el.appendChild(cloneChild.children[0])
        next = next.nextElementSibling
    }
})
 </script>
 
 
  <script>
//      let items = document.querySelectorAll('.testimonial .carosel_first')
//      items.forEach((el) => {
//     const minPerSlide = 4
//     let next = el.nextElementSibling
//     for (var i=1; i<minPerSlide; i++) {
//         if (!next) {
   
//         	next = items[0]
//       	}
//         let cloneChild = next.cloneNode(true)
//         el.appendChild(cloneChild.children[0])
//         next = next.nextElementSibling
//     }
// })
 </script>

<!--js by skill js counter===================================-->	


<script>
    $(()=>{
  var createSlick = ()=>{
    let slider = $(".slider");

    slider.not('.slick-initialized').slick({
      autoplay: false,
      infinite: true,
      dots: true,
      slidesToShow: 4,
      slidesToScroll: 1,
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
            adaptiveHeight: true,
          },
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
      ],
    });	
  }

  createSlick();

 $(window).on( 'resize orientationchange', createSlick );
})

</script>
	
<!--carosel bootstrap=======================-->

<!--carosel bootstrap=======================-->


<script>
var TxtType = function(el, toRotate, period) {
        this.toRotate = toRotate;
        this.el = el;
        this.loopNum = 0;
        this.period = parseInt(period, 10) || 2000;
        this.txt = '';
        this.tick();
        this.isDeleting = false;
    };

    TxtType.prototype.tick = function() {
        var i = this.loopNum % this.toRotate.length;
        var fullTxt = this.toRotate[i];

        if (this.isDeleting) {
        this.txt = fullTxt.substring(0, this.txt.length - 1);
        } else {
        this.txt = fullTxt.substring(0, this.txt.length + 1);
        }

        this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

        var that = this;
        var delta = 200 - Math.random() * 100;

        if (this.isDeleting) { delta /= 2; }

        if (!this.isDeleting && this.txt === fullTxt) {
        delta = this.period;
        this.isDeleting = true;
        } else if (this.isDeleting && this.txt === '') {
        this.isDeleting = false;
        this.loopNum++;
        delta = 500;
        }

        setTimeout(function() {
        that.tick();
        }, delta);
    };

    window.onload = function() {
        var elements = document.getElementsByClassName('typewrite');
        for (var i=0; i<elements.length; i++) {
            var toRotate = elements[i].getAttribute('data-type');
            var period = elements[i].getAttribute('data-period');
            if (toRotate) {
              new TxtType(elements[i], JSON.parse(toRotate), period);
            }
        }
        // INJECT CSS
        var css = document.createElement("style");
        css.type = "text/css";
        css.innerHTML = ".typewrite > .wrap { border-right: 0.08em solid #fff}";
        document.body.appendChild(css);
    };
</script>

		  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/index.blade.php ENDPATH**/ ?>