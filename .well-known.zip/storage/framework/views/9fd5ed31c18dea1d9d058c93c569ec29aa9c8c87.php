
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Course</li>
      </ol>
	  <!-- Icon Cards-->
      <div class="row">
<div class="card-body">
				    <form method="POSt" action="<?php echo e(url('teacher-course-save')); ?>" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

<?php $id= session()->get('FRONT_USER_ID') ?>

<input type="hidden" name="user_id" value="<?php echo e($id); ?>" >

					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Course Categroy<span style="color:red;">*</span></label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            <select class="form-select form-control mb-2 single-select " id="catagory" name="catagory" aria-label="Default select example" >
                                <option value="">--Select Course Categroy type--</option>
                                <?php $__currentLoopData = $categoryslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $settingees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option  value = "<?php echo e($settingees->id); ?>"><?php echo e($settingees->categroy); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <p style="color:red;"><?php $__errorArgs = ['catagory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                            </select>
								
							</div>
                              <p style="color:red;"><?php $__errorArgs = ['categroy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Course Subcategroy<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
                                <select id="subcategory" class="form-control" name="subcategory"  >
                                
                                <option value="">--Select Course Subcategroy type--</option>
                                </select>							  
                            </div>
                              <p style="color:red;"><?php $__errorArgs = ['subcategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  
						  
						        <label for="basic-input" class="col-sm-2 col-form-label">Course Title<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('ctitle')); ?>" name="ctitle" placeholder="Enter Course Title" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['ctitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  
						  
						  		  <label for="basic-input" class="col-sm-2 col-form-label">Course MRP<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('cmrp')); ?>" name="cmrp" placeholder="Enter Course MRP" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['cmrp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  	  		  <label for="basic-input" class="col-sm-2 col-form-label">Course Price<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('cprice')); ?>" name="cprice" placeholder="Enter Course Price" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['cprice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Image<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="file" accept="image/*" class="form-control" value="<?php echo e(old('image')); ?>" name="image" placeholder="" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  	  <label for="basic-input" class="col-sm-2 col-form-label">Course Video<span style="color:red;">*</span></label>
						  	  <div class="col-sm-10">
							<div class="input-group mb-3">
                            
								<input type="file" accept="video/*" class="form-control maxFileLimit" data-filelimit="25" value="<?php echo e(old('cvideo')); ?>" name="cvideo[]" placeholder="Enter Course Title" value="" multiple>
							  </div>
                              <p style="color:red; " class="maxFileLimitError"><?php $__errorArgs = ['cvideo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  </div>
						 

						    <div class="form-group row">
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Course Description<span style="color:red;">*</span></label>
						  	  <div class="col-sm-10">
							<div class="input-group mb-3">
                            
								<textarea type="text" class="form-control" value="<?php echo e(old('editor')); ?>" name="editor" placeholder="Description" value=""></textarea>
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['editor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  </div>
						  

						  
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>          
		</div>
	  </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
   	<script type = "text/javascript">
	jQuery(document).ready(function(){
			jQuery('#catagory').change(function(){
				let cid=jQuery(this).val();
				jQuery.ajax({
					url:'getSubcat',
					type:'post',
					data:'cid='+cid+'&_token=<?php echo e(csrf_token()); ?>',
					success:function(result){

						jQuery('#subcategory').html(result)
					}
				});
			});
    });

</script>
   	
   	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/teacherdashboard/course.blade.php ENDPATH**/ ?>