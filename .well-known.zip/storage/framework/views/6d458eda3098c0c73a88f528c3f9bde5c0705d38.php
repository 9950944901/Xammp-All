<?php $__env->startSection('page_title','Categroy'); ?>
<?php $__env->startSection('contant'); ?>

			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> <?php echo e($title ?? ''); ?></div>
			     <div class="card-body">
				    <form method="POSt" action="<?php echo e(Route::has('admin.master-class.update') ? route('admin.master-class.update',$data->id ?? '') : '#'); ?>" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

<?php echo method_field("put"); ?>

					    <div class="form-group row">
						  
						  <div class="col-md-12">
						  <label for="basic-input" class=" col-form-label">Title</label>
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('title') ?? $data['title'] ?? ''); ?>" name="title" placeholder="Title" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						<div class="col-md-12">
						  <div> 
						   <img src="<?php echo e(asset("uploads/masterclass/".$data['image'])); ?>" height="100px" >
						  </div>
						  <label for="basic-input" class=" col-form-label">Image</label>
							<div class="input-group mb-3">
                            
								<input type="file" accept="image/*" class="form-control" value="<?php echo e(old('image')); ?>" name="image" placeholder="image" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>

						   <div class="col-md-12">
						    <div> 
						   <video width="320" height="150" controls>
  <source src="<?php echo e(asset("uploads/masterclass/".$data['video'])); ?>" type="video/mp4">
  <source src="<?php echo e(asset("uploads/masterclass/".$data['video'])); ?>" type="video/ogg">
 
</video>
						  </div>
						  <label for="basic-input" class="col-form-label">Video</label>
							<div class="input-group mb-3">
                            
								<input type="file" accept="video/*" class="form-control" value="<?php echo e(old('video')); ?>" name="video" placeholder="video" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  
			              <div class="col-md-12">
						  <label for="basic-input" class="col-form-label">Description</label>
							<div class="input-group mb-3">  
                                <textarea class="form-control" value="<?php echo e(old('description')); ?>" name="description" > <?php echo e($data['description'] ?? ''); ?></textarea>
							
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
					
						  
						 
						</div>
						<div>
						    <button class="btn btn-primary"> Submit </button>
						 </div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/admin/master-class/edit.blade.php ENDPATH**/ ?>