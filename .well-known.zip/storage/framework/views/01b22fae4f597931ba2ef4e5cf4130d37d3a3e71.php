
<?php $__env->startSection('content'); ?>
<style>
    .student_progerss {
    background: #fff;
    padding: 15px 15px;
    border-radius: 10px;
}
</style>
<div class="container mt-3">
  <h2>Students Progress Bar</h2>
  <div class="row">
      <div class="col-md-6">
          <div class="student_progerss">
           <h6>Anil</h6>
      <div class="progress">
        <div class="progress-bar progress-bar-striped progress-bar-animated" style="width:95%"></div>
      </div>
      </div>
      </div>
      <div class="col-md-6">
          <div class="student_progerss">
           <h6>Ankita</h6>
      <div class="progress">
        <div class="progress-bar progress-bar-striped progress-bar-animated" style="width:90%"></div>
      </div>
      </div>
      </div>
  </div>
      
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/teacherdashboard/student_progress.blade.php ENDPATH**/ ?>