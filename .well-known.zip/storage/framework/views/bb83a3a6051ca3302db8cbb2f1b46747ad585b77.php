
<?php $__env->startSection('content'); ?>


		<!--<section id="hero_in" class="cart_section">-->
		<!--    <div class="wrapper">-->
		<!--		<div class="container">-->
		<!--			<h1 class="fadeInUp"><span></span>Checkout</h1>-->
		<!--		</div>-->
		<!--	</div>-->
		<!--	-->
		<!--</section>-->
		
		<section id="hero_in" class="cart_section">
			<div class="wrapper">
				<div class="container">
					<div class="bs-wizard clearfix">
						<div class="bs-wizard-step active">
							<div class="text-center bs-wizard-stepnum">Your cart</div>
							<div class="progress">
								<div class="progress-bar"></div>
							</div>
							<a href="#0" class="bs-wizard-dot"></a>
						</div>

						<div class="bs-wizard-step">
							<div class="text-center bs-wizard-stepnum">Payment</div>
							<div class="progress">
								<div class="progress-bar"></div>
							</div>
							<a href="#0" class="bs-wizard-dot"></a>
						</div>

						<div class="bs-wizard-step disabled">
							<div class="text-center bs-wizard-stepnum">Finish!</div>
							<div class="progress">
								<div class="progress-bar"></div>
							</div>
							<a href="#0" class="bs-wizard-dot"></a>
						</div>
					</div>
					<!-- End bs-wizard -->
				</div>
			</div>
		</section>
		
		
		<!--/hero_in-->

		<div class="bg_color_1">
			<div class="container margin_60_35">
			 <form  method="post" action="<?php echo e(route('confirmorder')); ?>" enctype="multipart/form-data" id="checkoutform">
                <?php echo csrf_field(); ?>
                <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<div class="row">
					<div class="col-lg-8">
						<div class="box_cart">
						<div class="message">
							<p>Exisitng Customer? <a href="<?php echo e(url('login')); ?>">Click here to login</a></p>
						</div>
						<div class="form_title">
							<h3><strong>1</strong>Your Details</h3>
							<p>
								Mussum ipsum cacilds, vidis litro abertis.
							</p>
						</div>
						<div class="step">
							<div class="row">
								<div class="col-sm-6">
									<span class="input">
										<input class="input_field" type="text" name="billing_first_name" required>
										<label class="input_label">
											<span class="input__label-content">First name</span>
										</label>
									</span>
								</div>
								<div class="col-sm-6">
									<span class="input">
										<input class="input_field" type="text" name="billing_last_name" required>
										<label class="input_label">
											<span class="input__label-content">Last name</span>
										</label>
									</span>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-6">
									<span class="input">
										<input class="input_field" name="billing_email" type="email" required>
										<label class="input_label">
											<span class="input__label-content">Email</span>
										</label>
									</span>
								</div>
								<div class="col-sm-6">
									<span class="input">
										<input class="input_field" type="text" name="billing_phone" required>
										<label class="input_label">
											<span class="input__label-content">Telephone</span>
										</label>
									</span>
								</div>
							
							</div>
						
						</div>
						<hr>
						<!--End step -->

						<div class="form_title">
							<h3><strong>2</strong>Payment Information</h3>
							<p>
								Mussum ipsum cacilds, vidis litro abertis.
							</p>
						</div>
						<div class="step">
							<span class="input">
								<input class="input_field" type="text">
								<label class="input_label">
								  <span class="input__label-content">Name on card</span>
								</label>
							</span>
							<div class="row">
								<div class="col-md-6">
									<span class="input">
										<input class="input_field" type="text">
										<label class="input_label">
										  <span class="input__label-content">Card number</span>
										</label>
									</span>
								</div>
								<div class="col-md-6 col-sm-6">
									<img src="<?php echo e(URL::asset('frontend/img/payments.png')); ?>" alt="Cards" class="cards">
								</div>
							</div>
							<div class="row">
								<div class="col-md-6 add_top_30">
									<label>Expiration date</label>
									<div class="row">
										<div class="col-md-6">
											<span class="input">
												<input class="input_field" type="text">
												<label class="input_label">
												  <span class="input__label-content">MM</span>
												</label>
											</span>
										</div>
										<div class="col-md-6">
											<span class="input">
												<input class="input_field" type="text">
												<label class="input_label">
												  <span class="input__label-content">Year</span>
												</label>
											</span>
										</div>
									</div>
								</div>
								<div class="col-md-6 add_top_30">
									<div class="form-group">
										<label>Security code</label>
										<div class="row">
											<div class="col-md-4">
												<span class="input">
													<input class="input_field" type="text">
													<label class="input_label">
													  <span class="input__label-content">CCV</span>
													</label>
												</span>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!--End row -->

							<h5>Or checkout with Paypal</h5>
							<p>
								Lorem ipsum dolor sit amet, vim id accusata sensibus, id ridens quaeque qui. Ne qui vocent ornatus molestie, reque fierent dissentiunt mel ea.
							</p>
							<p>
								<img src="<?php echo e(URL::asset('frontend/img/paypal_bt.png')); ?>" alt="Image">
							</p>
						</div>
						<hr>
						<!--End step -->

						<div class="form_title">
							<h3><strong>3</strong>Billing Address</h3>
							<p>
								Mussum ipsum cacilds, vidis litro abertis.
							</p>
						</div>
						<div class="step">
							<div class="row">
								<div class="col-md-6 col-sm-6">
									<span class="input">
										<input class="input_field" type="text" name="billing_country" required>
										<label class="input_label">
											<span class="input__label-content">Country</span>
										</label>
									</span>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12 col-sm-12">
									<span class="input">
										<input class="input_field" type="text" name="billing_address" required>
										<label class="input_label">
											<span class="input__label-content">Address</span>
										</label>
									</span>
								</div>
							
							</div>
							<div class="row">
								<div class="col-md-6">
									<span class="input">
										<input class="input_field" type="text" name="billing_city" required>
										<label class="input_label">
											<span class="input__label-content">City</span>
										</label>
									</span>
								</div>
								<div class="col-md-3">
									<span class="input">
										<input class="input_field" type="text" name="billing_state" required>
										<label class="input_label">
											<span class="input__label-content" >State</span>
										</label>
									</span>
								</div>
								<div class="col-md-3">
									<span class="input">
										<input class="input_field" type="text" name="billing_code" required>
										<label class="input_label">
											<span class="input__label-content">Postal code</span>
										</label>
									</span>
								</div>
							</div>
							<!--End row -->
						</div>
						<hr>
						<!--End step -->
						<div id="policy">
							<h5>Cancellation policy</h5>
							<p class="nomargin">Lorem ipsum dolor sit amet, vix <a href="#0">cu justo blandit deleniti</a>, discere omittantur consectetuer per eu. Percipit repudiare similique ad sed, vix ad decore nullam ornatus.</p>
						</div>
						</div>
					</div>
					<!-- /col -->
					
					<aside class="col-lg-4" id="sidebar">
					    <?php
                            $i=1;
                            $total = 0;
                        ?>
                       
                        <?php $__currentLoopData = $cartdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $price = $item->cprice;
                                $quantity = $item->quantity;
                                $subtotal = ($price*$quantity);
                                $total = $total + $subtotal;
                            ?>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="box_detail">
						    <input type="hidden" name="total" value="<?php echo e($total); ?>">
							<div id="total_cart">
								Total <span class="float-right">$<?php echo e($total); ?></span>
							</div>
							<div class="add_bottom_30">Lorem ipsum dolor sit amet, sed vide <strong>moderatius</strong> ad. Ex eius soleat sanctus pro, enim conceptam in quo, <a href="#0">brute convenire</a> appellantur an mei.</div>
							<!--<a href="<?php echo e(url('order-success')); ?>" class="btn_1 full-width">Order Now</a>-->
							<button id="checkoutsubmit" type ="submit" class="btn_1 full-width">Order Now</button>
							<a href="<?php echo e(url('/')); ?>" class="btn_1 full-width outline"><i class="icon-right"></i> Continue Shopping</a>
						</div>
					</aside>
				</div>
				</form>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /bg_color_1 -->
		
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/checkout.blade.php ENDPATH**/ ?>