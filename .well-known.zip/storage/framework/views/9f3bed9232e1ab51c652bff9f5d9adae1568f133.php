
<?php $__env->startSection('page_title','Enquiry'); ?>
<?php $__env->startSection('contant'); ?>


<style>

.active{
font-size: 14px;
background-image: linear-gradient(to right, rgb(218, 34, 255) 0%, rgb(151, 51, 238) 51%, rgb(218, 34, 255) 100%);

}


.inactive{
font-size: 14px;
background-image: linear-gradient(to right, rgb(255, 81, 47) 0%, rgb(240, 152, 25) 51%, rgb(255, 81, 47) 100%);
}


</style>




<div class="col-sm-12">
<div class="container-fluid">
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header"><i class="fa fa-table"></i>Enquiry</div>
<div class="card-body">
<div class="table-responsive">


<table id="example2" class="table table-bordered" style="width:100%">
<thead>
<tr>
<th>Sr.No.</th>
<th>Name</th>
<th>Email</th>
<th>Subject</th>
<th>Message</th>
<th>Action</th>
</tr>
</thead>
<tbody>

<?php $i=0;?>
<?php $__currentLoopData = $conatct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $settingee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




<tr role="row" class="odd">
<td><?php $i++;?><?php echo e($i); ?></td>
<td><?php echo e($settingee['name']); ?></td>
<td><?php echo e($settingee['email']); ?></td>
<td><?php echo e($settingee['sub']); ?></td>
<td><?php echo e($settingee['msg']); ?></td>


<td>    
<a class="btn btn-danger" href="con_delete/<?php echo e($settingee['id']); ?>" onclick="return confirm('Are you sure?')"><i class="fa fa-trash-o"></i></a>
</td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

</table>

<div class="d-flex justify-content-flex-end Pagination_1" >
<?php echo $conatct->links("pagination::bootstrap-4"); ?>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>






<style>

.w-5 {
display: none;
}

.h-5{
display: none;
}

</style>


<?php $__env->stopSection(); ?>
<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/admin/support.blade.php ENDPATH**/ ?>