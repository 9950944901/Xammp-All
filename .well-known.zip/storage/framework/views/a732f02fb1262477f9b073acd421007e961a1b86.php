
<?php $__env->startSection('content'); ?>


<style>

.active{
font-size: 14px;
background-image: linear-gradient(to right, rgb(218, 34, 255) 0%, rgb(151, 51, 238) 51%, rgb(218, 34, 255) 100%);

}


.inactive{
font-size: 14px;
background-image: linear-gradient(to right, rgb(255, 81, 47) 0%, rgb(240, 152, 25) 51%, rgb(255, 81, 47) 100%);
}


</style>

<div class="page-wrapper">
<div class="page-content">


<div class="col-sm-12">
<div class="container-fluid">

<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header"></div>
<div class="card-body">
<div class="table-responsive">

<?php if($foundationcourse): ?>
        <table id="example2" class="table table-bordered" style="width:100%">
        <thead>
        <tr>
        <th>Sr.No.</th>
        <th>Name</th>
        <th>Price</th>
        <th>Description</th>
        <th>Image</th>
        <th>Action</th>
        </tr>
        </thead>
        <?php
        
        $i=1;
        ?>
        <?php $__currentLoopData = $foundationcourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
        
        
        <tr role="row" class="odd">
        <td><?php echo e($i++); ?></td>
        
        <td><?php echo e($list->title); ?></td>
        <td><?php echo e($list->price); ?></td>
        <td><?php echo $list->description; ?></td>
        <td><img src="<?php echo e(url('uploads/Foundational_course/image/',$list->image)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;"></td>
        <td>
             
        <a class="btn btn-dark" href="foundationview<?php echo e($list->id); ?>" onclick=""><i class="fa fa-eye"></i></a>
        
        </td>
        
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        
        <?php else: ?>
            <h1>No Subscription plan</h1>
        <?php endif; ?>

<div class="d-flex justify-content-flex-end Pagination_1" >

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>







<style>

.w-5 {
display: none;
}

.h-5{
display: none;
}

</style>


<?php $__env->stopSection(); ?>
<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('layouts.master_student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/studentdashboard/foundation/index.blade.php ENDPATH**/ ?>