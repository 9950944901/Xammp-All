<?php $__env->startSection('page_title','Password'); ?>
<?php $__env->startSection('contant'); ?>

			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Change Password</div>
			     <div class="card-body">
				    <form method="post" action="<?php echo e(url('admin/updateadminpassword')); ?>" enctype= "multipart/form-data">
						        <?php echo csrf_field(); ?>
							<div class="row mb-3">
								<div class="col-sm-3">
									<h6 class="mb-0">Old Password</h6>
								</div>
								<div class="col-sm-9 text-secondary">
									<input type="text" name="old_password" class="form-control" value="">
									<?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <small class="text-danger"><?php echo e($message ?? ''); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
								<div class="row mb-3">
								<div class="col-sm-3">
									<h6 class="mb-0">New Password</h6>
								</div>
								<div class="col-sm-9 text-secondary">
									<input type="text" name="new_password"  class="form-control" value="">
									<?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <small class="text-danger"><?php echo e($message ?? ''); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="row mb-3">
								<div class="col-sm-3">
									<h6 class="mb-0">Confirm Password</h6>
								</div>
								<div class="col-sm-9 text-secondary">
									<input type="text" name="confirm_pass" class="form-control" value="">
									<?php $__errorArgs = ['confirm_pass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <small class="text-danger"><?php echo e($message ?? ''); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-3"></div>
								<div class="col-sm-9 text-secondary">
									<input type="submit" name="submit" class="btn btn-primary px-4" value="Change Password">
								</div>
							</div>
						    </form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skilluva/pandatji.com/resources/views/admin/changepassword.blade.php ENDPATH**/ ?>