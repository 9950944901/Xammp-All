
<?php $__env->startSection('contant'); ?>
 <style>
   select.form-control.select_main_langugage {
    height: 70px !important;
}

.select_main_puja option{
  color: #fff !important;
}

.select_main_langugage{
  color: #fff !important;
}

#main {
    background-image: url(../frontend_asset/assets/img/form_img.jpg);
    background-size: 100% 100%;
    background-attachment: fixed;
}
 </style>


  <main id="main">


    <!-- ======= Contact Us Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2>Register Form</h2>
        </div>

        <!-- <div class="row justify-content-center">

          <div class="col-lg-10">

            <div class="info-wrap">
              <div class="row">
                <div class="col-lg-4 info">
                  <i class="bi bi-geo-alt"></i>
                  <h4>Location:</h4>
                  <p>A108 Adam Street<br>New York, NY 535022</p>
                </div>

                <div class="col-lg-4 info mt-4 mt-lg-0">
                  <i class="bi bi-envelope"></i>
                  <h4>Email:</h4>
                  <p>info@example.com<br>contact@example.com</p>
                </div>

                <div class="col-lg-4 info mt-4 mt-lg-0">
                  <i class="bi bi-phone"></i>
                  <h4>Call:</h4>
                  <p>+1 5589 55488 51<br>+1 5589 22475 14</p>
                </div>
              </div>
            </div>

          </div>

        </div> -->

        <div class="row justify-content-center ">
          <div class="col-lg-10">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form pt-4">
              <div class="row">
                <div class="col-md-6 form-group">
                  <!-- <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required> -->
                  <label for="comment">Title:</label>
                  <select class="form-control form-select">
                    <option>--Select Title--</option>
                    <option>Acharya</option>
                    <option>Shashtri </option>
                    <option>Others</option>
                  </select>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <label for="comment">First Name:</label>
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your First Name" required>
                </div>
              </div>

               <div class="row">
                <div class="col-md-6 form-group">
                 
                 <label for="comment">Last Name:</label>
                <input type="text" class="form-control"  id="subject" placeholder="Your Last Name" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <label for="comment">State:</label>
                  
                        <select class="form-control form-select" id="sel1">
                        <option value="">Please choose a state...</option>
                        <option value="AN">Andaman and Nicobar</option>
                        <option value="AP">Andhra Pradesh</option>
                        <option value="AR">Arunachal Pradesh</option>
                        <option value="AS">Assam</option>
                        <option value="BH">Bihar</option>
                        <option value="CH">Chandigarh</option>
                        <option value="CT">Chhattisgarh</option>
                        <option value="DN">Dadra and Nagar Haveli</option>
                        <option value="DD">Daman and Diu</option>
                        <option value="DL">Delhi</option>
                        <option value="GA">Goa</option>
                        <option value="GJ">Gujarat</option>
                        <option value="HR">Haryana</option>
                        <option value="HP">Himachal Pradesh</option>
                        <option value="JK">Jammu Kashmir</option>
                        <option value="JH">Jharkhand</option>
                        <option value="KA">Karnataka</option>
                        <option value="KL">Kerala</option>
                        <option value="LD">Lakshadweep</option>
                        <option value="MP">Madhya Pradesh</option>
                        <option value="MH">Maharashtra</option>
                        <option value="MN">Manipur</option>
                        <option value="ML">Meghalaya</option>
                        <option value="MZ">Mizoram</option>
                        <option value="NL">Nagaland</option>
                        <option value="OR">Odisha</option>
                        <option value="PY">Pondicherry</option>
                        <option value="PB">Punjab</option>
                        <option value="RJ">Rajasthan</option>
                        <option value="SK">Sikkim</option>
                        <option value="TN">Tamil Nadu</option>
                        <option value="TS">Telangana</option>
                        <option value="TR">Tripura</option>
                        <option value="UP">Uttar Pradesh</option>
                        <option value="UT">Uttarakhand</option>
                        <option value="WB">West Bengal</option>

                        </select>
              </div>
            </div>

            <div class="row">
                <div class="col-md-6 form-group">
                 
                  <label for="comment">City:</label>
                  <select class="form-select form-control" id="sel1">
                        <option value="">Please choose a Town/City...</option>
                          <option value="Alwar">Alwar</option>
                          <option value="Ajmer">Ajmer</option>
                          <option value="Bharatpur">Bharatpur</option>
                          <option value="Bikaner">Bikaner</option>
                          <option value="Bundi">Bundi</option>
                          <option value="Chittaurgarh">Chittaurgarh</option>
                          <option value="Jaipur">Jaipur</option>
                          <option value="Jaisalmer">Jaisalmer</option>
                          <option value="Jodhpur">Jodhpur</option>
                          <option value="Mt.Abu">Mt.Abu</option>
                          <option value="Pushkar">Pushkar</option>
                          <option value="Ranakpur">Ranakpur</option>
                          <option value="Shekhawati">Shekhawati</option>
                          <option value="Sariska">Sariska</option>
                          <option value="Udaipur">Udaipur</option>
                          <option value="Ranthambore">Ranthambore</option>
                      </select>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <label for="comment">Pincode:</label>
                  <input type="number" class="form-control" name="email" id="email" placeholder="Your Pincode" required>
                </div>
              </div>


              <div class="row">
                <div class="col-md-6 form-group">
                  
                  <label for="comment">Email:</label>
                 <input type="email" class="form-control" placeholder="Email" />
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <label for="comment">Mobile:</label>
                  <input type="number" class="form-control" placeholder="Mobile"  />
                </div>
              </div>

               <div class="row">
                <div class="col-md-6 form-group">
                  
                  <label for="comment">How did you find us:</label>
                 <select class="form-select form-control">
                        <option value="">--Select--</option>
                        <option value="From Website">From Website</option>
                        <option value="From Google">From Google</option>
                        <option value="From Friends">From Friends</option>
                        <option value="From Facebook">From Facebook</option>
                        </select>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <label for="comment">Community:</label>
                  <select class="form-select form-control">
                        <option value="">Choose Option..</option>
                        <option value="Oriya"> Oriya</option>
                        <option value="Bengali">Bengali</option>
                        <option value="Assamese">Assamese</option>
                        <option value="Telugu">Telugu</option>
                        <option value="Tamil">Tamil</option>
                        <option value="Malyali">Malyali</option>
                        <option value="Marathi">Marathi</option>
                        <option value="Kannada">Kannada</option>
                        <option value="Gujarati">Gujarati</option>
                        <option value="Marwari">Marwari</option>
                        <option value="Punjabi">Punjabi</option>
                        <option value="North Indian">North Indian</option>
                        <option value="Others">Others</option>
                        </select>
                </div>
              </div>

              
              <div class="form-group mt-3">
                <label for="comment">Address:</label>
                <textarea class="form-control" name="message" rows="3" placeholder="Address" ></textarea>
              </div>


              <div class="row">
                <div class="col-md-6 form-group">
                  <label for="comment">Language:</label>
                 <select multiple class="form-select form-control select_main_langugage" data-placeholder="Choose a Language...">
                        <option value="AF">-- Option Language--</option>
                          <option value="AF">Afrikaans</option>
                          <option value="SQ">Albanian</option>
                          <option value="AR">Arabic</option>
                          <option value="HY">Armenian</option>
                          <option value="EU">Basque</option>
                          <option value="BN">Bengali</option>
                          <option value="BG">Bulgarian</option>
                          <option value="CA">Catalan</option>
                          <option value="KM">Cambodian</option>
                          <option value="ZH">Chinese (Mandarin)</option>
                          <option value="HR">Croatian</option>
                          <option value="CS">Czech</option>
                          <option value="DA">Danish</option>
                          <option value="NL">Dutch</option>
                          <option value="EN">English</option>
                          <option value="ET">Estonian</option>
                          <option value="FJ">Fiji</option>
                          <option value="FI">Finnish</option>
                          <option value="FR">French</option>
                          <option value="KA">Georgian</option>
                          <option value="DE">German</option>
                          <option value="EL">Greek</option>
                          <option value="GU">Gujarati</option>
                          <option value="HE">Hebrew</option>
                          <option value="HI">Hindi</option>
                          <option value="HU">Hungarian</option>
                          <option value="IS">Icelandic</option>
                          <option value="ID">Indonesian</option>
                          <option value="GA">Irish</option>
                          <option value="IT">Italian</option>
                          <option value="JA">Japanese</option>
                          <option value="JW">Javanese</option>
                          <option value="KO">Korean</option>
                          <option value="LA">Latin</option>
                          <option value="LV">Latvian</option>
                          <option value="LT">Lithuanian</option>
                          <option value="MK">Macedonian</option>
                          <option value="MS">Malay</option>
                          <option value="ML">Malayalam</option>
                          <option value="MT">Maltese</option>
                          <option value="MI">Maori</option>
                          <option value="MR">Marathi</option>
                          <option value="MN">Mongolian</option>
                          <option value="NE">Nepali</option>
                          <option value="NO">Norwegian</option>
                          <option value="FA">Persian</option>
                          <option value="PL">Polish</option>
                          <option value="PT">Portuguese</option>
                          <option value="PA">Punjabi</option>
                          <option value="QU">Quechua</option>
                          <option value="RO">Romanian</option>
                          <option value="RU">Russian</option>
                          <option value="SM">Samoan</option>
                          <option value="SR">Serbian</option>
                          <option value="SK">Slovak</option>
                          <option value="SL">Slovenian</option>
                          <option value="ES">Spanish</option>
                          <option value="SW">Swahili</option>
                          <option value="SV">Swedish </option>
                          <option value="TA">Tamil</option>
                          <option value="TT">Tatar</option>
                          <option value="TE">Telugu</option>
                          <option value="TH">Thai</option>
                          <option value="BO">Tibetan</option>
                          <option value="TO">Tonga</option>
                          <option value="TR">Turkish</option>
                          <option value="UK">Ukrainian</option>
                          <option value="UR">Urdu</option>
                          <option value="UZ">Uzbek</option>
                          <option value="VI">Vietnamese</option>
                          <option value="CY">Welsh</option>
                          <option value="XH">Xhosa</option>
                        </select>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <label for="comment">Puja's you can perform?:</label>
                <select multiple class="form-select form-control select_main_puja" id="sel1" style="height:70px !important;">
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                  <option>4</option>
                </select>
                  
                 
                </div>
              </div>

              <div class="row">
                <div class="col-md-6 form-group">
                  
                  <label for="comment">Educational Qualification:</label>
                 <select class="form-select form-control">
                        <option value="">-- select one --</option>
                        <option value="High School">High School</option>
                        <option value="Graduation">Graduation</option>
                        <option value="Post Graduation">Post Graduation</option>
                        <option value="Doctorate">Doctorate</option>
                        <option value="Others">Others</option>
                        </select>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <label for="comment">Experience:</label>
                  <select class="form-select form-control">
                        <option value="0 - 2 Years"> 0 - 2 Years</option>
                        <option value="2 - 5 Years"> 2 - 5 Years</option>
                        <option value="5 - 10 Years"> 5 - 10 Years</option>
                        <option value="10 Years and above"> 10 Years and above </option>
                        </select>

                    </div>
              </div>

              <div class="row">
                <div class="col-md-6 form-group">
                  
                  <label for="comment">Notice of Advance booking:</label>
                <select class="form-select form-control">
                        <option value="4 - 12 hrs">4 - 12 hrs</option>
                        <option value="12 - 24 hrs">12 - 24 hrs </option>
                        <option value="1 Days">1 Days </option>
                        <option value="2 Days">2 Days </option>
                        <option value="3 Days">3 Days </option>
                        <option value="4 Days">4 Days </option>
                        <option value="5 Days">5 Days </option>
                        </select>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <label for="comment">Are you working in temple?:</label>
                  <select class="form-select form-control">
                        <option value="">--Select One--</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                        </select>

                    </div>
              </div>

               


            <div class="row">
                <div class="col-md-6 form-group">
               <label for="comment">Preferred working hours:</label>
                  <select class="form-select form-control">
                        <option value="">-- select one --</option>
                        <option value="9 a.m. - 1 p.m">9 a.m. -1 p.m </option>
                        <option value="1 p.m. - 5 p.m">1 p.m. - 5 p.m </option>
                        <option value="5 p.m. - 9 p.m">5 p.m. - 9 p.m </option>
                        <option value="9 p.m. - 1 a.m">9 p.m. - 1 a.m </option>
                        <option value="Anytime">Anytime </option>
                        </select>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <label for="comment">Upload Your Image:</label>
                  <input type="file" name="" class="form-control">

                    </div>
              </div>







              <div class="form-group mt-3">
                <label for="comment">Any other details:</label>
                <textarea class="form-control" rows="5" id="comment" name="text" placeholder="Any other details"></textarea>
              </div>


              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Submit</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Us Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>ComingSoon</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
      
        Designed by <a href="#">GTS</a>
      </div>
    </div>
  </footer><!-- End #footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\skilluvademo\resources\views/frontend/register_form.blade.php ENDPATH**/ ?>