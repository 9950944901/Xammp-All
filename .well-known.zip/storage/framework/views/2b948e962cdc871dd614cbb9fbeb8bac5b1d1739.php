<footer>

		
		
		<?php

$da = App\Models\websetting::first();

?>

		
		
		<div class="container margin_120_95">
			<div class="row justify-content-between">
				<div class="col-lg-5 col-md-5">
					<p><img src="<?php echo e(asset('uploads/system_setting/'.$da->footerlogo)); ?>" width="149" height="42" alt=""></p>
						<h5>SUPPORT</h5>
					<ul class="contacts">
						<li><a href="tel://8769955456"><i class="ti-mobile"></i> <?php echo e($da->mobile); ?></a></li>
						<li><a href="mailto:support@skilluva.com"><i class="ti-email"></i> <?php echo e($da->email); ?></a></li>
					</ul>
	
					
				</div>
		
								<div class="col-lg-5 col-md-5 ml-lg-auto">
					<h5>LINKS</h5>
					<ul class="links">
						<li><a href="<?php echo e(url('/')); ?>">Home</a></li>
						<!--<li><a href="#0">Activity</a></li>-->
						<li><a href="<?php echo e(url('about-us')); ?>">About Us</a></li>
						<li><a href="<?php echo e(url('basic-course')); ?>">Courses</a></li>
						<li><a href="<?php echo e(url('training_material')); ?>">Find Trainers </a></li>
							<li><a href="<?php echo e(url('ebook')); ?>">eBook Library</a></li>
							
					</ul>
				</div>
								
				<div class="col-lg-2 col-md-2">
				<h5>SUPPORT</h5>
					<ul class="links">
						<li><a href="<?php echo e(url('login')); ?>">My Account</a></li>
						<li><a href="<?php echo e(url('contact')); ?>">Contact us</a></li>
						<li><a href="<?php echo e(url('Privacy-Policy')); ?>">Privacy Policy</a></li>
						<li><a href="<?php echo e(url('Term-Condition')); ?>">Term & Conditions</a></li>
							<li><a href="<?php echo e(url('FAQs')); ?>">FAQ's</a></li>
					</ul>
				</div>
			</div>
			
			<hr>
			<div class="row">
				<div class="col-md-8">
					<ul id="additional_links">
						<li><a href="#0">Terms and conditions</a></li>
						<li><a href="#0">Privacy</a></li>
					</ul>
				</div>
				<div class="col-md-4">
					<div id="copy" style="color:#fbfbfb !important;">© Skilluva</div>
				</div>
			</div>
		</div>
		
		
		
		
		

	</footer><?php /**PATH E:\xampp\htdocs\skilluvademo\resources\views/frontend/footer.blade.php ENDPATH**/ ?>