
<?php $__env->startSection('content'); ?>

<style>
    .now_traner{
        text-align: center;
    }
    .card_bill_tex_dom{
        
    }
  .card_title_skill_uva_para{
     color: #857979;
     font-size: 15px;
     text-transform: capitalize;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
     overflow: hidden;
     display: -webkit-box;
     
}  
</style>
<?php 

$data = App\Models\Bnner::first();

?>


<section id="hero_in" class="courses" style="background-image:url(<?php echo e(url('uploads/banners/trainer_banner/'.$data['trainer_banner'])); ?>)">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span><?php echo e($data->trainer_banner_title); ?></h1>
				</div>
			</div>
		</section>
		<section class="skill_tranner_uva_first_tranner_section">
		    <div class="container">
		        <div class="row">
		            <form method="get" action="gettrainer">
                                <div class="input-group">
                                <div class="form-outline">
                                <input type="search" id="form1" class="form-control" name="fname" placeholder="Search..."/>
                                
                                </div>
                                <button type="submit" class="btn btn-primary" style="height: 47px;">
                                <i class="icon-search"></i>
                                </button>
                                </div>
                                </form>
		            <div class="col-md-4"></div>
		             <div class="col-md-2">
		    <!--            <div class="mt-2">-->
		    <!--                	<select name="orderby" class="selectbox">-->
						<!--	<option value="category">Category</option>-->
						<!--	<option value="category 2">Literature</option>-->
						<!--	<option value="category 3">Architecture</option>-->
						<!--	<option value="category 4">Economy</option>-->
						<!--</select>-->
		    <!--            </div>-->
		            </div>
		        </div>
		        
		    </div>
		</section>
		
		<section class="tranner_section_sidebar_body_bar">
		   <div class="container">
              <div class="row">
        <!--      <div class="col-md-3 bg-dark" style="height: fit-content;">-->
        <!--     <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">-->
        <!--        <a href="/" class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none">-->
        <!--            <span class="fs-5  d-sm-inline">Select Trainers</span>-->
        <!--        </a>-->
        <!--        <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start skill_uva_navbar_list" id="menu">-->
        <!--            <li class="nav-item">-->
        <!--                <a href="#" class="nav-link align-middle px-0">-->
        <!--                    <i class="fs-4 bi-house"></i> <span class="ms-1 d-sm-inline">Home</span>-->
        <!--                </a>-->
        <!--            </li>-->
        <!--            <li>-->
        <!--                <a href="#submenu1" data-bs-toggle="collapse" class="nav-link px-0 align-middle">-->
        <!--                    <i class="fs-4 bi-speedometer2"></i> <span class="ms-1  d-sm-inline">Dashboard<i class="icon-down-dir"></i></span> </a>-->
        <!--                <ul class="collapse show nav flex-column ms-1" id="submenu1" data-bs-parent="#menu">-->
        <!--                    <li class="w-100">-->
        <!--                        <a href="#" class="nav-link px-0"> <span class=" d-sm-inline">Item</span> 1 </a>-->
        <!--                    </li>-->
        <!--                    <li>-->
        <!--                        <a href="#" class="nav-link px-0"> <span class=" d-sm-inline">Item</span> 2 </a>-->
        <!--                    </li>-->
        <!--                </ul>-->
        <!--            </li>-->
        <!--            <li>-->
        <!--                <a href="#" class="nav-link px-0 align-middle">-->
        <!--                    <i class="fs-4 bi-table"></i> <span class="ms-1  d-sm-inline">Orders</span></a>-->
        <!--            </li>-->
                   
        <!--            <li>-->
        <!--                <a href="#submenu3" data-bs-toggle="collapse" class="nav-link px-0 align-middle">-->
        <!--                    <i class="fs-4 bi-grid"></i> <span class="ms-1 d-none d-sm-inline">Products</span><i class="icon-down-dir"></i></a>-->
        <!--                    <ul class="collapse nav flex-column ms-1" id="submenu3" data-bs-parent="#menu">-->
        <!--                    <li class="w-100">-->
        <!--                        <a href="#" class="nav-link px-0"> <span class="d-sm-inline">Product</span> 1</a>-->
        <!--                    </li>-->
        <!--                    <li>-->
        <!--                        <a href="#" class="nav-link px-0"> <span class="d-sm-inline">Product</span> 2</a>-->
        <!--                    </li>-->
        <!--                    <li>-->
        <!--                        <a href="#" class="nav-link px-0"> <span class="d-sm-inline">Product</span> 3</a>-->
        <!--                    </li>-->
        <!--                    <li>-->
        <!--                        <a href="#" class="nav-link px-0"> <span class="d-sm-inline">Product</span> 4</a>-->
        <!--                    </li>-->
        <!--                </ul>-->
        <!--            </li>-->
        <!--            <li>-->
        <!--                <a href="#" class="nav-link px-0 align-middle">-->
        <!--                    <i class="fs-4 bi-people"></i> <span class="ms-1d-sm-inline">Customers</span> </a>-->
        <!--            </li>-->
        <!--        </ul>-->
        <!--        <hr>-->
        <!--        <div class="dropdown pb-4">-->
        <!--            <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">-->
        <!--                <img src="https://github.com/mdo.png" alt="hugenerd" width="30" height="30" class="rounded-circle">-->
        <!--                <span class="d-sm-inline mx-1">loser</span>-->
        <!--            </a>-->
        <!--            <ul class="dropdown-menu dropdown-menu-dark text-small shadow">-->
        <!--                <li><a class="dropdown-item" href="#">New project...</a></li>-->
        <!--                <li><a class="dropdown-item" href="#">Settings</a></li>-->
        <!--                <li><a class="dropdown-item" href="#">Profile</a></li>-->
        <!--                <li>-->
        <!--                    <hr class="dropdown-divider">-->
        <!--                </li>-->
        <!--                <li><a class="dropdown-item" href="#">Sign out</a></li>-->
        <!--            </ul>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--</div>-->
        <div class="col-md-12">
            <h1 class="select_your_traner">Select Your Trainer</h1>
            <div class="row">
                <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                
                    <div class="col-md-4 mb-3">
                        <a href="<?php echo e(url('training_material_details',$trainer->id)); ?>">
                            <div class="card card_box_shadow_skill">
                                <div class="card_bill_tex_dom">
                                <?php if($trainer->image): ?>
                                    <img src="<?php echo e(asset('uploads/user_images/'.$trainer->image)); ?>" class="card-img-top img_src_first_skill">
                                <?php else: ?>
                                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" class="card-img-top img_src_first_skill">
                                <?php endif; ?>
                                </div>
                                   <div class="card-body">
                                   <h5 class="card-title card_title_skill_uva"><?php echo e($trainer->fname); ?></h5>
                                    <p class="card_title_skill_uva_para"><?php echo e($trainer->brief_intro); ?></p>
                                    <div class="now_traner">
                                        <a href="<?php echo e(url('training_material_details',$trainer->id)); ?>" class="enroll_now_traner">Enroll now</a>
                                        </div>
                                  </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo $trainers->links("pagination::bootstrap-4"); ?>

               
          </div>
        </div>
    </div>
</div>
		</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/training_material.blade.php ENDPATH**/ ?>