
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--<section id="hero_in" class="cart_section">-->
<!--                <div class="wrapper">-->
<!--				<div class="container">-->
<!--					<h1 class="fadeInUp"><span></span>Order completed!</h1>-->
<!--					<p>You'll receive a confirmation email at mail@example.com</p>-->
<!--				</div>-->
<!--			</div>-->
<!--		<div class="wrapper">-->
<!--				<div class="container">-->
<!--					<div class="bs-wizard clearfix">-->
<!--						<div class="bs-wizard-step">-->
<!--							<div class="text-center bs-wizard-stepnum">Your cart</div>-->
<!--							<div class="progress">-->
<!--								<div class="progress-bar"></div>-->
<!--							</div>-->
<!--							<a href="cart-1.html" class="bs-wizard-dot"></a>-->
<!--						</div>-->

<!--						<div class="bs-wizard-step">-->
<!--							<div class="text-center bs-wizard-stepnum">Payment</div>-->
<!--							<div class="progress">-->
<!--								<div class="progress-bar"></div>-->
<!--							</div>-->
<!--							<a href="cart-2.html" class="bs-wizard-dot"></a>-->
<!--						</div>-->

<!--						<div class="bs-wizard-step active">-->
<!--							<div class="text-center bs-wizard-stepnum">Finish!</div>-->
<!--							<div class="progress">-->
<!--								<div class="progress-bar"></div>-->
<!--							</div>-->
<!--							<a href="#0" class="bs-wizard-dot"></a>-->
<!--						</div>-->
<!--					</div>-->
<!--					<div id="confirm">-->
<!--						<h4>Order completed!</h4>-->
<!--						<p>You'll receive a confirmation email at mail@example.com</p>-->
<!--					</div>-->
<!--				</div>-->
<!--			</div>--}}-->
<!--		</section>-->
		<!--/hero_in-->
	
		<section id="hero_in" class="cart_section">
			<div class="wrapper">
				<div class="container">
					<div class="bs-wizard clearfix">
						<div class="bs-wizard-step active">
							<div class="text-center bs-wizard-stepnum">Your cart</div>
							<div class="progress">
								<div class="progress-bar"></div>
							</div>
							<a href="#0" class="bs-wizard-dot"></a>
						</div>

						<div class="bs-wizard-step">
							<div class="text-center bs-wizard-stepnum">Payment</div>
							<div class="progress">
								<div class="progress-bar"></div>
							</div>
							<a href="#0" class="bs-wizard-dot"></a>
						</div>

						<div class="bs-wizard-step">
							<div class="text-center bs-wizard-stepnum">Finish!</div>
							<div class="progress">
								<div class="progress-bar"></div>
							</div>
							<a href="#0" class="bs-wizard-dot"></a>
						</div>
					</div>
					<!-- End bs-wizard -->
				</div>
			</div>
		</section>	
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/order_success.blade.php ENDPATH**/ ?>