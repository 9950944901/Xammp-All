
<?php $__env->startSection('content'); ?>

	<main>
		

<style>
.animated .block-reveal img {
    width: 100%;
    animation: color .5s ease-in-out;
    animation-delay: .5s;
    -webkit-animation-delay: .5s;
    -moz-animation-delay: .5s;
    animation-fill-mode: forwards;
    -webkit-animation-fill-mode: forwards;
    -moz-animation-fill-mode: forwards;
    opacity: 0;
    -webkit-backface-visibility: hidden;
    -moz-backface-visibility: hidden;
    -ms-backface-visibility: hidden;
    -o-backface-visibility: hidden;
    backface-visibility: hidden;
}


.videodata{
    
        position: inherit!important;

}

  .images_benner {
          width: 100%;
height: 370px;
}
  .images_benner img {
   height: 370px;
}
.Benefits{
        text-align: justify;
}


.couraes_img{
           height: 190px !important;
}
    @media    only screen and (max-width: 991px) {

.box_list ul li:last-child a {
    padding: 5px 12px;
    font-size: 12px;
}

.traner_profile_image {
    width: 100%;
    height: 100%;
    /* object-fit: contain; */
    filter: blur(1px);
}
</style>




<section id="hero_in" class="courses" style="background-image:url(https://sindhisanskriti.com/p1/skilluva/uploads/banners/accredited_banner/62df96d0680b7_1658820304.jpg)">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span>Accredited-Course</h1>
				</div>
			</div>
		</section>
		<!--/hero_in-->

		<!--<div class="filters_listing">-->
		<!--	<div class="container">-->
		<!--		<ul class="clearfix">-->
		<!--			<li>-->
		<!--				<div class="switch-field">-->
		<!--					<input type="radio" id="all" name="listing_filter" value="all" checked>-->
		<!--					<label for="all">All</label>-->
						
		<!--				</div>-->
		<!--			</li>-->
		<!--			<li>-->
					
		<!--			</li>-->
		<!--			<li>-->
		<!--				<select name="orderby" class="selectbox">-->
		<!--					<option value="category">Category</option>-->
		<!--					<option value="category 2">Literature</option>-->
		<!--					<option value="category 3">Architecture</option>-->
		<!--					<option value="category 4">Economy</option>-->
		<!--				</select>-->
		<!--			</li>-->
		<!--		</ul>-->
		<!--	</div>-->
		
		<!--</div>-->
<!--	-->


			<section  class="courses">
			<!--<div class="wrapper">-->
			<!--	<div class="container">-->
			<!--		<h1 class="fadeInUp"><span></span>Online course detail</h1>-->
			<!--	</div>-->
			<!--</div>-->
		</section>
		<div class="bg_color_1">
	
			<div class="container margin_60_35">
				<div class="row">
					<div class="col-lg-8">
						
						<section id="description">
							<h2>Description</h2>
							
							<p><?php echo e($cour->description); ?></p>
													<h3><?php echo e($cour->ctitle); ?></h3>

						</section>
						<!-- /section -->
						
						<section id="lessons">
							<div class="intro_title">
								<h2>Lessons</h2>
								<!--<ul>-->
								<!--	<li>18 lessons</li>-->
								<!--	<li>01:02:10</li>-->
								<!--</ul>-->
							
							    <video width="320" height="240" controls class="videodata" >
  <source src="<?php echo e(url('uploads/trainer_course/video/'.$videos->video)); ?>" type="video/mp4" >
</video>
							</div>
							
				
					</div>
					<!-- /col -->
					
					<aside class="col-lg-4" id="sidebar">
						<div class="box_detail">
							<figure>
  <img src="<?php echo e(url('uploads/advancecourse/image/'.$cour->image)); ?>" width="100%" / >
							</figure>
							<div class="price">
							    
								₹<?php echo e($cour->cprice); ?><span class="original_price"><em>₹<?php echo e($cour->cmrp); ?></em>60% discount price</span>
							</div>
							<a href="<?php echo e(url('add-to-cart',$cour->id)); ?>" class="btn_1 full-width">Add to Cart</a>
							<a href=" <?php echo e(url('/')); ?>" class="btn_1 full-width outline">Continue Shoping</a>
							<div id="list_feat">
								<!--<h3>What's includes</h3>-->
								<!--<ul>-->
								<!--	<li><i class="icon_mobile"></i>Mobile support</li>-->
								<!--	<li><i class="icon_archive_alt"></i>Lesson archive</li>-->
								<!--	<li><i class="icon_mobile"></i>Mobile support</li>-->
								<!--	<li><i class="icon_chat_alt"></i>Tutor chat</li>-->
								<!--	<li><i class="icon_document_alt"></i>Course certificate</li>-->
								<!--</ul>-->
							</div>
						</div>
					</aside>
				</div>
				
	
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		


	</main>
	<!-- /main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/course-details.blade.php ENDPATH**/ ?>