
<?php $__env->startSection('contant'); ?>



            <div class="container-fluid">
 

 <div class="row">
<?php $__currentLoopData = $viewwebsettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-lg-12">
          <div class="card">

          <div class="row">
          <div class="col-md-6"> <h5 class="card-header text-uppercase"> <?php echo e($setting['companynames']); ?> Details </h5></div>
           <?php $catupdate= Crypt::encrypt($setting->id);?>
          <div class="col-md-6 text-end"> <a style="color: white;" href="update<?php echo e($catupdate); ?>" ><button type="button" class="btn btn-primary"><i class="fa fa-pencil" aria-hidden="true"></i></button></a></div>
          
          </div>
		 
         
            <div class="card-body">
              
			<div class="table-responsive">
	          <table class="table table-bordered">
            <thead>
              <!--<tr>-->
              <!--  <th>User Name</th>-->
              <!--  <td><?php echo e($setting['companynames']); ?></td>-->
              <!--</tr>-->

			  
			  <tr>
                <th>Mobile Number </th>
                <td><?php echo e($setting['mobile']); ?></td>
              </tr>
              <tr>
                <th>E-mail </th>
                <td><?php echo e($setting['email']); ?></td>
              </tr>
              
              
              <!-- <tr>-->
              <!--  <th>Tagline </th>-->
              <!--  <td><?php echo e($setting['tagline']); ?></td>-->
              <!--</tr>-->

              <tr>
                <th>Address </th>
                <td><?php echo e($setting['address']); ?></td>
              </tr>

              <tr>
                <th>Logo</th>
                <td>             <a href="<?php echo e(('../uploads/system_setting/'.$setting->logo)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(('../uploads/system_setting/'.$setting->logo)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;">
</a></td>
              </tr>


              <tr>
                <th>Favicon</th>
                <td>             <a href="<?php echo e(('../uploads/system_setting/'.$setting->favicon)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(('../uploads/system_setting/'.$setting->favicon)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;">
</a></td>
              </tr>


              <tr>
                <th>Footer Logo </th>
                <td>             <a href="<?php echo e(('../uploads/system_setting/'.$setting->footerlogo)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(('../uploads/system_setting/'.$setting->footerlogo)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;">
</a></td>
              </tr>


<!--              <tr>-->
<!--                <th>Aboutus image </th>-->
<!--                <td>            <?php $__currentLoopData = json_decode($setting->Aboutimg, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media_gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
<!--<a href="<?php echo e(url('/uploads/system_setting/'.$media_gallery)); ?>" data-fancybox="images" data-caption="This image has a caption">-->
<!--<img src="<?php echo e(url('/uploads/system_setting/'.$media_gallery)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;">-->
<!--</a>-->
<!--<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>-->
<!--              </tr>-->


              <!--<tr>-->
              <!--  <th>Aboutus title </th>-->
              <!--  <td><?php echo e($setting['abouttitle']); ?></td>-->
              <!--</tr>-->


              <!--<tr>-->
              <!--  <th>Aboutus Description </th>-->
              <!--  <td><?php echo e($setting['Description']); ?></td>-->
              <!--</tr>-->


              <tr>
                <th>Facebook </th>
                <td><?php echo e($setting['facebook']); ?></td>
              </tr>

              <tr>
                <th>Instagram </th>
                <td><?php echo e($setting['instagram']); ?></td>
              </tr>

              <tr>
                <th>Twitter </th>
                <td><?php echo e($setting['twitter']); ?></td>
              </tr>


              <tr>
                <th>Pinterest </th>
                <td><?php echo e($setting['pinterest']); ?></td>
              </tr>


              <tr>
                <th>Linkdin </th>
                <td><?php echo e($setting['linkdin']); ?></td>
              </tr>


              <tr>
                <th>Youtube </th>
                <td><?php echo e($setting['youtube']); ?></td>
              </tr>


             

    
			  
          </thead>
          </table>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>
            </div>
          </div>     
          </div>
          	</div>  
             
	 
	

            <?php $__env->stopSection(); ?>



<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skilluva/pandatji.com/resources/views/admin/viewwebsetting.blade.php ENDPATH**/ ?>