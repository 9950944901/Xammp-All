
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Course</li>
      </ol>
	  <!-- Icon Cards-->
	  <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="row">
	  
<div class="card-body">
	<form method="POSt" action="<?php echo e(url('update_traniner_course')); ?>" class="form-horizontal" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($data['id']); ?>" >


					    <div class="form-group row">
					        <label for="basic-input" class="col-sm-2 col-form-label">Course Categroy<span style="color:red;">*</span></label>
						    <div class="col-sm-4">
							    <div class="input-group mb-3">
                                    <select class="form-select form-control mb-2 single-select " id="catagory" name="catagory" aria-label="Default select example" >
                                        <option value="">--Select Course Categroy type--</option>
                                        <?php $__currentLoopData = $categoryslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $settingees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  value = "<?php echo e($settingees->id); ?>" <?php echo e($settingees->id == $data->catagory ? 'selected' : ''); ?>><?php echo e($settingees->categroy); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <p style="color:red;"><?php $__errorArgs = ['catagory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </select>
        								
							    </div>
                                <p style="color:red;"><?php $__errorArgs = ['categroy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						    </div>
						  
						  
    						<label for="basic-input" class="col-sm-2 col-form-label">Course Subcategroy<span style="color:red;">*</span></label>
    						    <div class="col-sm-4">
    							<div class="input-group mb-3">
                                    <select id="subcategory" class="form-control" name="subcategory">
                                        <option value="">--Select Course Subcategroy type--</option>
                                        <?php $__currentLoopData = $subcategoryslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $settingees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  value = "<?php echo e($settingees->id); ?>" <?php echo e($settingees->id == $data->subcategory ? 'selected' : ''); ?>><?php echo e($settingees->sub_categroy); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>							  
                                </div>
                                <p style="color:red;"><?php $__errorArgs = ['subcategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
    						  </div>
						  
						  
						  
						  	<label for="basic-input" class="col-sm-2 col-form-label">Course Title<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e($data['ctitle']); ?>" name="ctitle" placeholder="Enter Course Title" value="">
							  </div>
						  </div>
						  
						  
						  
						  
						  		  <label for="basic-input" class="col-sm-2 col-form-label">Course MRP<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e($data['cmrp']); ?>" name="cmrp" placeholder="Enter Course MRP" value="">
							  </div>
						  </div>
						  
						  	  		  <label for="basic-input" class="col-sm-2 col-form-label">Course Price<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e($data['cprice']); ?>" name="cprice" placeholder="Enter Course Price" value="">
							  </div>
						  </div>
						  
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Image<span style="color:red;">*</span></label>
						    
						  	  <div class="col-sm-4">
							  <?php if($data['image']): ?>
                    	        <img class="mb-3 w-25" style="height:100px;"src="<?php echo e(asset('uploads/advancecourse/image/'.$data['image'])); ?>">
                            <?php endif; ?>
							<div class="input-group mb-3">
                            
								<input type="file" class="form-control" value="<?php echo e(old('image')); ?>" name="image" placeholder="" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Course Video<span style="color:red;">*</span></label>
						 
						   <div class="col-sm-10">
							<div class="input-group mb-3">
                            
								<input type="file" accept="video/*" class="form-control maxFileLimit" data-filelimit="25" value="<?php echo e(old('cvideo')); ?>" name="cvideo[]" placeholder="Enter Course Title" value="" multiple>
							  </div>
							   <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <div class="parc d-inline" style="position: relative;">
						    <video width="220" height="140" controls>
                              <source src="<?php echo e(asset('uploads/trainer_course/video/'.$video->video)); ?>" type="video/mp4">
                            </video>
                            <a class="btn videodelete" style="    position: absolute;
    right: -13px;
    background: red;
    color: white;
    border-radius: 50%;
	z-index: 1;" data-id = "<?php echo e($video->id); ?>" ><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                         </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						  </div>
						  
						  </div>
						 

						 <div class="form-group row">
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Course Description<span style="color:red;">*</span></label>
						  	  <div class="col-sm-10">
							<div class="input-group mb-3">
                            
								<textarea type="text" class="form-control" value="" name="editor" placeholder="Description" value=""><?php echo e($data['description']); ?></textarea>
							  </div>
						  </div>
						  </div>
						  

						  
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>          
		</div>
	  </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
   	<script type = "text/javascript">
	jQuery(document).ready(function(){
			jQuery('#catagory').change(function(){
				let cid=jQuery(this).val();
				jQuery.ajax({
					url:'getSubcat',
					type:'post',
					data:'cid='+cid+'&_token=<?php echo e(csrf_token()); ?>',
					success:function(result){

						jQuery('#subcategory').html(result)
					}
				});
			});
    });

</script>

<script type="text/javascript">
    $(document).on('click', '.videodelete', function(){
        var id = $(this).attr('data-id');
        $this = $(this);
   
        $.ajax({
            url:"coursevideodelete",
            type:'post',
            data:{
                 id:id,
                _token:'<?php echo e(csrf_token()); ?>'
            },
            success: function(data) {
               $this.parents(".parc").remove();  
            }
        });
    });
</script>
   	
   	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/teacherdashboard/update_trainer_course.blade.php ENDPATH**/ ?>