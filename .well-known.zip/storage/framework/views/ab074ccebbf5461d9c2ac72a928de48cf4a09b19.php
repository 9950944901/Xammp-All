<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Skilluva</title>

    <!-- Favicons-->
    <link rel="shortcut icon" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>">

    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&amp;display=swap" rel="stylesheet">

   
    
    
    
    <link href="<?php echo e(URL::asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('frontend/css/style.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(URL::asset('frontend/css/vendors.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(URL::asset('frontend/css/icon_fonts/css/all_icons.min.css')); ?>" rel="stylesheet">
	
	<!-- SPECIFIC CSS -->
	<link href="<?php echo e(URL::asset('frontend/css/skins/square/grey.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(URL::asset('frontend/css/wizard.css')); ?>" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="<?php echo e(URL::asset('frontend/css/custom.css')); ?>" rel="stylesheet">

<style>
    h3.main_question {
  
    font-size: 1.125rem;
}
.add_to_member{
    padding-top:15px;
}
.step_last_stag .radio_input a {
    color: #bc4648 !important;
    /* font-size: 15px; */
    cursor: pointer;
}
.next_for_content:hover{
    background-color:#662d91;
    color:#fff;
}
.next_for_content{
    background: #fff;
    border: 2px solid #662d91;
    color: #662d91;
    padding: 13px 39px;
    font-weight: 500;
    line-height: 1;
    border-radius: 40px;
    font-size: 18px;
}
</style>
</head>

<body id="admission_bg">
	
	<div id="preloader">
		<div data-loader="circle-side"></div>
	</div>
	<!-- End Preload -->
	
	<div id="form_container" class="clearfix">
		<figure>
			<a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(URL::asset('frontend/img_skill/logo_skill.png')); ?>" width="149" height="42" alt=""></a>
		</figure>
		<div id="wizard_container">
			<div id="top-wizard">
				<div id="progressbar"></div>
			</div>
			<!-- /top-wizard -->
			<form name="example-1" id="wrapped" method="POST">
				<input id="website" name="website" type="text" value="">
				<!-- Leave for security protection, read docs for details -->
				<div id="middle-wizard">
					<div class="step">
						<div id="intro">
							<figure><img src="<?php echo e(URL::asset('frontend/img/wizard_intro_icon.svg')); ?>" alt=""></figure>
							<h1>Membership Enrollment</h1>
							<p>Enroll Yourself to India's Most Hi-Tech Lerning Platform with India's Most Famous Trainers. Get Complete Access to All Foundational Courses of Skilluva with this Membership Enrollment.</p>
							<p><strong>Enroll as Corporate Team, Gift to Friends & Family and More.</strong></p>
							<div class="add_to_member">
							  <a href="<?php echo e(url('membership-plan')); ?>" class="next_for_content">Enroll Now</a>
							</div>
						</div>
					</div>

					<!--<div class="step">-->
					<!--	<h3 class="main_question"><strong>1/3</strong>Please fill with your details</h3>-->
					<!--	<div class="form-group">-->
					<!--		<input type="text" name="firstname" class="form-control required" value="anil" placeholder="First name">-->
					<!--	</div>-->
					<!--	<div class="form-group">-->
					<!--		<input type="text" name="lastname" class="form-control required" value="yogi" placeholder="Last name">-->
					<!--	</div>-->
					<!--	<div class="form-group">-->
					<!--		<input type="email" name="email" class="form-control required" value="a@gmail.com" placeholder="Your Email">-->
					<!--	</div>-->
					<!--	<div class="form-group">-->
					<!--		<input type="text" name="telephone" class="form-control"  value="432242423443" placeholder="Your Telephone">-->
					<!--	</div>-->
					<!--	<div class="form-group">-->
					<!--		<input type="text" name="age" class="form-control"  value="21" placeholder="Age">-->
					<!--	</div>-->
					<!--	<div class="form-group select">-->
					<!--		<div class="styled-select">-->
					<!--			<select class="required" name="education_apply" id="education_apply">-->
					<!--				<option value="" selected="">Select your education level</option>-->
					<!--				<option value="Less than high school">Less than high school</option>-->
					<!--				<option value="High school diploma or equivalent">High school diploma or equivalent</option>-->
					<!--				<option value="Some college no degree">Some college, no degree</option>-->
					<!--				<option value="Bachelor degree">Bachelor’s degree</option>-->
					<!--				<option value="Doctoral or professional degree">Doctoral or professional degree</option>-->
					<!--			</select>-->
					<!--		</div>-->
					<!--	</div>-->
					<!--	<div class="form-group radio_input">-->
					<!--		<label><input type="radio" value="Male" checked name="gender" class="icheck">Male</label>-->
					<!--		<label><input type="radio" value="Female" name="gender" class="icheck">Female</label>-->
					<!--	</div>-->
					<!--</div>-->
					<!-- /step-->

					<!--<div class="submit step">-->
					<!--	<h3 class="main_question"><strong>2/3</strong>Please fill your address</h3>-->
					<!--	<div class="form-group">-->
					<!--		<input type="text" name="address" class="form-control required"  placeholder="Address">-->
					<!--	</div>-->
					<!--	<div class="form-group">-->
					<!--		<input type="text" name="city" class="form-control required" placeholder="City">-->
					<!--	</div>-->
					<!--	<div class="form-group">-->
					<!--		<input type="text" name="zip_code" class="form-control required" placeholder="Zip code">-->
					<!--	</div>-->
					<!--	<div class="form-group">-->
					<!--		<div class="styled-select">-->
					<!--			<select class="required" name="country">-->
					<!--				<option value="" selected>Select your country</option>-->
					<!--				<option value="Europe">Europe</option>-->
					<!--				<option value="Asia">Asia</option>-->
					<!--				<option value="North America">North America</option>-->
					<!--				<option value="South America">South America</option>-->
					<!--			</select>-->
					<!--		</div>-->
					<!--	</div>-->
					<!--</div>-->
					<!-- /step-->

					<!--<div class=" step step_last_stag">-->
					<!--	<h3 class="main_question"><strong>3/3</strong>Select the Type of Membership</h3>-->
					<!--	<div class="form-group radio_input">-->
					<!--		<a data-bs-toggle="modal" data-bs-target="#standard_membership_table">Standard Membership</a>-->
					<!--	</div>-->
					<!--	<div class="form-group radio_input">-->
					<!--		<a  data-bs-toggle="modal" data-bs-target="#corporate_membership_table">Corporate Membership</a>-->
					<!--	</div>-->
					<!--	<div class="form-group radio_input">-->
					<!--		<a  data-bs-toggle="modal" data-bs-target="#gift_table">Gift to Friend/Family</a>-->
					<!--	</div>-->
					
					<!--</div>-->
					<!-- /step-->
				</div>
				<!-- /middle-wizard -->
				<div id="bottom-wizard">
					<!--<button type="button" name="backward" class="backward">Backward </button>-->
					<button type="button" name="forward" class="forward"><a href="<?php echo e(url('membership-plan')); ?>"></a>Forward</button>
					<!--<button type="submit" name="process" class="submit">Submit</button>-->
				</div>
				<!-- /bottom-wizard -->
			</form>
		</div>
		<!-- /Wizard container -->
	</div>
	<!-- /Form_container -->

	<!-- Modal terms -->
	<div class="modal fade" id="terms-txt" tabindex="-1" role="dialog" aria-labelledby="termsLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title" id="termsLabel">Terms and conditions</h4>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body">
					<p>Lorem ipsum dolor sit amet, in porro albucius qui, in <strong>nec quod novum accumsan</strong>, mei ludus tamquam dolores id. No sit debitis meliore postulant, per ex prompta alterum sanctus, pro ne quod dicunt sensibus.</p>
					<p>Lorem ipsum dolor sit amet, in porro albucius qui, in nec quod novum accumsan, mei ludus tamquam dolores id. No sit debitis meliore postulant, per ex prompta alterum sanctus, pro ne quod dicunt sensibus. Lorem ipsum dolor sit amet, <strong>in porro albucius qui</strong>, in nec quod novum accumsan, mei ludus tamquam dolores id. No sit debitis meliore postulant, per ex prompta alterum sanctus, pro ne quod dicunt sensibus.</p>
					<p>Lorem ipsum dolor sit amet, in porro albucius qui, in nec quod novum accumsan, mei ludus tamquam dolores id. No sit debitis meliore postulant, per ex prompta alterum sanctus, pro ne quod dicunt sensibus.</p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn_1" data-dismiss="modal">Close</button>
				</div>
			</div>
			<!-- /.modal-content -->
		</div>
		<!-- /.modal-dialog -->
	</div>
	<!-- /.modal -->














	
	<!-- COMMON SCRIPTS -->
    <script src="<?php echo e(URL::asset('frontend/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('frontend/js/common_scripts.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('frontend/js/main_admission.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('frontend/assets/validate.js')); ?>"></script>
	
	<!-- SPECIFIC SCRIPTS -->
	<script src="<?php echo e(URL::asset('frontend/js/jquery-ui-1.8.22.min.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('frontend/js/jquery.wizard.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('frontend/js/jquery.validate.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('frontend/js/admission_func.js')); ?>"></script>
  
</body>

</html><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/frontend/admission.blade.php ENDPATH**/ ?>