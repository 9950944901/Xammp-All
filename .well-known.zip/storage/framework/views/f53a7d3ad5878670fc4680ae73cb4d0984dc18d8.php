
<?php $__env->startSection('contant'); ?>
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



            <div class="container-fluid">
 

 <div class="row">

	<div class="col-lg-12">
          <div class="card">

          <div class="row">
          <div class="col-md-12"> <h5 class="card-header text-uppercase"> Banner's Setting <a style="float: right;" class="btn btn-primary" href="banner_edit<?php echo e($data->id); ?>"><i class="fa fa-pencil" style="margin-right: 0;" aria-hidden="true"></i></a></h5></div>

          </div>
		 
         
            <div class="card-body">
              
			<div class="table-responsive">
	          <table class="table table-bordered">
            <thead>

               <tr>
                <th>Home Banner Title 1 </th>
                <td><?php echo e($data->home_banner_title_1); ?></td>
              </tr>

              <tr>
                <th>Home Banner Title 2</th>
                <td><?php echo e($data->home_banner_title_2); ?></td>
              </tr>
              
               <tr>
                <th>Home Banner Title 3</th>
                <td><?php echo e($data->home_banner_title_3); ?></td>
              </tr>
              
                <tr>
                <th>About Banner Title</th>
                <td><?php echo e($data->about_banner_title); ?></td>
              </tr>

                    <tr>
                <th>Foundational Banner Title </th>
                <td><?php echo e($data->foundational_banner_title); ?></td>
              </tr>

              <tr>
                <th>Aggregate Banner Title</th>
                <td><?php echo e($data->accredited_banner_title); ?></td>
              </tr>
              
               <tr>
                <th>Trainer Banner Title</th>
                <td><?php echo e($data->trainer_banner_title); ?></td>
              </tr>
              
                <tr>
                <th>Ebook Banner Title</th>
                <td><?php echo e($data->ebookbanner_title); ?></td>
              </tr>

               <tr>
                <th>Support Banner Title</th>
                <td><?php echo e($data->support_banner_title); ?></td>
              </tr>



     <tr>
                <th>Home Banner Image</th>
                <td>            
<a href="<?php echo e(url('uploads/banners/home_banner/'.$data->home_banner)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(url('uploads/banners/home_banner/'.$data->home_banner)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;">
</a>
</td>
              </tr>

              <tr>
                <th>About Banner Image</th>
                <td>            
<a href="<?php echo e(url('uploads/banners/about_banner/'.$data->about_banner)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(url('uploads/banners/about_banner/'.$data->about_banner)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;">
</a>
</td>
              </tr>


<tr>
                <th>Foundational Banner Image</th>
                <td>            
<a href="<?php echo e(url('uploads/banners/foundational_banner/'.$data->foundational_banner)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(url('uploads/banners/foundational_banner/'.$data->foundational_banner)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;">
</a>
</td>
              </tr>
              
       <tr>
       
                <th>Accredited Banner Image</th>
                <td>            
<a href="<?php echo e(url('uploads/banners/accredited_banner/'.$data->accredited_banner)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(url('uploads/banners/accredited_banner/'.$data->accredited_banner)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;">
</a>
</td>
              </tr>
              
              
     <tr>
         
                <th>Trainer Banner Image</th>
                <td>            
<a href="<?php echo e(url('uploads/banners/trainer_banner/'.$data->trainer_banner)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(url('uploads/banners/trainer_banner/'.$data->trainer_banner)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;">
</a>
</td>
              </tr>
              
           <tr>
   
                <th>Ebook Banner Title</th>
                <td>            
<a href="<?php echo e(url('uploads/banners/ebookbanner/'.$data->ebookbanner)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(url('uploads/banners/ebookbanner/'.$data->ebookbanner)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;">
</a>
</td>
              </tr>
              
            <tr>
  
                <th>Support Banner Image</th>
                <td>            
<a href="<?php echo e(url('uploads/banners/support_banner/'.$data->support_banner)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(url('uploads/banners/support_banner/'.$data->support_banner)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;">
</a>
</td>
              </tr>
       
             

    
			  
          </thead>
          </table>
        </div>


			</div>
            </div>
          </div>     
          </div>
          	</div>  
            
	 
	

            <?php $__env->stopSection(); ?>



<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/admin/banner/index.blade.php ENDPATH**/ ?>