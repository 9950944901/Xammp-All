<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Udema a modern educational site template">
    <meta name="author" content="Ansonika">
    <title>SkillUVA</title>

    <!-- Favicons-->
    <link rel="shortcut icon" href="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>" type="image/x-icon">
    <link rel="apple-touch-icon" type="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>" href="img/apple-touch-icon-57x57-precomposed.png">
    <link rel="apple-touch-icon" type="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon" type="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon" type="<?php echo e(URL::asset('frontend/img_skill/skill_icon.png')); ?>" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&amp;display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="<?php echo e(URL::asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('frontend/css/style.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(URL::asset('frontend/css/vendors.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(URL::asset('frontend/css/icon_fonts/css/all_icons.min.css')); ?>" rel="stylesheet">
    <!-- YOUR CUSTOM CSS -->
    <link href="<?php echo e(URL::asset('frontend/css/custom.css')); ?>" rel="stylesheet">
     <link href="<?php echo e(URL::asset('frontend/css/tables.css')); ?>" rel="stylesheet">
	<!-- SPECIFIC CSS -->
	<link href="<?php echo e(URL::asset('frontend/css/skins/square/grey.css')); ?>" rel="stylesheet">

    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&amp;display=swap" rel="stylesheet">

    <link href="<?php echo e(URL::asset('frontend/css/blog.css')); ?>" rel="stylesheet">

    
	
	<!-- MODERNIZR SLIDER -->
	<script src="<?php echo e(URL::asset('frontend/js/modernizr_slider.js')); ?>"></script>
<?php echo $__env->yieldPushContent('webpage'); ?>
</head>

<body>
		
	<div id="page">
		
	<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- /header -->
	
	<main>
		<?php echo $__env->yieldContent('content'); ?>
	</main>
	<!-- /main -->

	<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!--/footer-->
	</div>
	<!-- page -->
	


	<!-- COMMON SCRIPTS -->
    <script src="<?php echo e(URL::asset('frontend/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('frontend/js/common_scripts.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('frontend/js/main.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('frontend/assets/validate.js')); ?>"></script>
	
	<!-- FlexSlider -->
	<script defer src="<?php echo e(URL::asset('frontend/js/jquery.flexslider.js')); ?>"></script>

	
	<!-- SPECIFIC SCRIPTS -->
	<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyBvyh3GjnIHWnr3nzQ6uYt6Hb3_0ehJMn0"></script>
	<script type="text/javascript" src="<?php echo e(URL::asset('frontend/js/mapmarker.jquery.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(URL::asset('frontend/js/mapmarker_func.jquery.js')); ?>"></script>
	
	
	
	
	
 	<script>

        // $(document).ready(function(){
        //   $(".btn_mobile_hide_moile").click(function(){
        //     $("nav#mm-menu").hide();
        //   });
        // });
</script>


	</script>
	
	<script>
		$(window).on('load',function() {
			'use strict';
			$('#carousel_slider').flexslider({
				animation: "slide",
				controlNav: false,
				animationLoop: false,
				slideshow: false,
				itemWidth: 280,
				itemMargin: 25,
				asNavFor: '#slider'
			});
			$('#carousel_slider ul.slides li').on('mouseover', function() {
				$(this).trigger('click');
			});
			$('#slider').flexslider({
				animation: "fade",
				controlNav: false,
				animationLoop: false,
				slideshow: false,
				sync: "#carousel_slider",
				start: function(slider) {
					$('body').removeClass('loading');
				}
			});
		});
		
		   jQuery(document).ready(function() {
            // Carousel with dynamic min/max ranges
            (function() {

                // store the slider in a local variable
                var $window = $(window),
                    flexslider = {
                        vars: {}
                    };

                // tiny helper function to add breakpoints
                function getGridSize() {
                    return (window.innerWidth < 480) ? 1 :
                        (window.innerWidth < 900) ? 2 : 3;
                }

                $(window).on('load', function() {
                    $('.flexslider').flexslider({
                        animation: "slide",
                        animationLoop: true,
                        itemWidth: 280,
                        itemMargin: 25,

                        controlNav: true,
                        minItems: getGridSize(), // use function to pull in initial value
                        maxItems: getGridSize(), // use function to pull in initial value
                        start: function(slider) {
                            flexslider = slider;
                        }
                    });
                });

                // check grid size on resize event
                $window.resize(function() {
                    var gridSize = getGridSize();
                    flexslider.vars.minItems = gridSize;
                    flexslider.vars.maxItems = gridSize;
                });
            }());
        });

		</script>
	

	
</body>

<!-- Mirrored from www.ansonika.com/udema/index-6.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 24 May 2022 06:33:05 GMT -->
</html><?php /**PATH /home/abgj4nxz6fww/public_html/skilluva.sindhisanskriti.com/skilluva/resources/views/layouts/app.blade.php ENDPATH**/ ?>