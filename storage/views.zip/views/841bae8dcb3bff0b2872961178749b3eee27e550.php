
<?php $__env->startSection('page_title','Update CLIENT'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Update CLIENT
</div>
			     <div class="card-body">
				    <form method="POSt" action="admin/update_client" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
 <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<input type="hidden" name="id" value="<?php echo e($upadatecli['id']); ?>">
					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Client id </label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e($upadatecli->Client_id); ?>" name="Client_id" placeholder="Client id" value="">
							  </div>
                             
						  </div>
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Client name </label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e($upadatecli->client_name); ?>" name="client_name" placeholder="Client name" >
							  </div>
                            
						  </div>
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Contact number </label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e($upadatecli->Contact_number); ?>" name="Contact_number" placeholder="Contact number" value="">
							  </div>
                            
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Email </label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="email" class="form-control" value="<?php echo e($upadatecli->email); ?>" name="email" placeholder="Enter email" value="">
							  </div>
                           
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Service </label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e($upadatecli->Service); ?>" name="Service" placeholder="Enter Service" value="">
							  </div>
               
						  </div>
						  
						  
						
						 

						  <label for="basic-input" class="col-sm-2 col-form-label">Source </label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
<select name="Source" class="form-control single-select">
<option value="">--Select Option--</option>
<option value="Twitter" <?php echo e(($upadatecli->Source) == 'Twitter' ? 'selected' : ''); ?>>Twitter</option>
<option value="Website" <?php echo e(($upadatecli->Source) == 'Website' ? 'selected' : ''); ?>>Website</option>
<option value="Google" <?php echo e(($upadatecli->Source) == 'Google' ? 'selected' : ''); ?>>Google</option>
<option value="Facebook" <?php echo e(($upadatecli->Source) == 'Facebook' ? 'selected' : ''); ?>>Facebook</option>
</select> 
</div>

</div>


						  <label for="basic-input" class="col-sm-2 col-form-label">Assigned to </label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
<select name="Assigned_to" class="form-control single-select">
<option value="">--Select Option--</option>
<option value="Rakesh" <?php echo e(($upadatecli->Assigned_to)=='Rakesh' ? 'selected' : ''); ?>>Rakesh</option>
<option value="Anil" <?php echo e(($upadatecli->Assigned_to)=='Anil' ? 'selected' : ''); ?>>Anil</option>
<option value="Aman" <?php echo e(($upadatecli->Assigned_to)=='Aman' ? 'selected' : ''); ?>>Aman</option>
</select> 
</div>

</div>



						  	   <label for="basic-input" class="col-sm-2 col-form-label">Gender </label>
						  						  <div class="col-sm-4">
							<div class="input-group mb-3">
<select name="Gender" class="form-control single-select">
<option value="">--Select Option--</option>
<option value="1"  <?php echo e(($upadatecli->Gender)=='1' ? 'selected' : ''); ?>>Male</option>
<option value="0"  <?php echo e(($upadatecli->Gender)=='0' ? 'selected' : ''); ?>>Female</option>


</select> 
</div>

</div>


						  	   <label for="basic-input" class="col-sm-2 col-form-label">Status </label>
						  						  <div class="col-sm-4">
							<div class="input-group mb-3">
<select name="Status" class="form-control single-select">
<option value="">--Select Option--</option>
<option value="1"  <?php echo e(($upadatecli->Status)=='1' ? 'selected' : ''); ?>>Active</option>
<option value="0"  <?php echo e(($upadatecli->Status)=='0' ? 'selected' : ''); ?>>Inactive</option>


</select> 
</div>
<p style="color:red;"><?php $__errorArgs = ['Status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
						  
						  
						  
						  </div>
						  
						  
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtsdigital/public_html/Gts_salon/resources/views/admin/update_client.blade.php ENDPATH**/ ?>