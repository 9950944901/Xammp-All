<?php $__env->startSection('page_title','ADD USED PRODUCTS'); ?>
<?php $__env->startSection('contant'); ?>




<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase">ADD USED PRODUCTS
</div>
			     <div class="card-body">
				    <form method="POST" action="add_product_used" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
 <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!--<button type="button" id="btnAdd" class="btn btn-success pull-right"><i class="fa fa-plus" aria-hidden="true"></i>Add product</button>-->

					    				<div class="clearfix"></div>
							
							<div class="table-responsive">
								<table id="myTable" class="table table-bordered">
									<thead>
										<tr>
											<th style="width:20%" colspan="2">Products</th>
											<th style="width:3%">Quantity</th>
											<th style="width:15%">Service provider</th>
											<th style="width:15%">Remarks</th>
										</tr>
									</thead>
									<tbody>
										
										<tr  id="TextBoxContainer" class="TextBoxContainer">
											<td class="sno text-center" style="vertical-align:middle;"><span class="fa fa-ellipsis-v"></span></td>
											<td><input type="text" class="ser form-control sal" id="service" name="product[]" onBlur="" placeholder="Product" value="" required> 
											</td>
											<td><input type="number" class="qt form-control sal" id="quantity" name="quantity[]" value="0" min='0' required></td>
											<td><select name="staffid[]" data-validation="required" class="form-control ">
												<option value=""> --Select Service Provider--</option>
													<option value="1"> Aman</option>
	
													<option value="2"> Anil</option>
	
													<option value="3"> Rakesh</option>
													
													
												</select>
											</td>
											<td><input type="text" class="form-control" id="quantity" name="notes[]" value="" placeholder="Remarks" required></td>
										</tr>
										
										<tr id="addBefore">
											<td colspan="5"><button type="button" id="btnAdd" class="btn btn-success pull-right"><i class="fa fa-plus" aria-hidden="true"></i>Add product</button></td>
											
										</tr>
										
										<tr>
											<td colspan="5"><input type="submit" value="submit" name="submit" class="btn btn-success pull-right"></td>
																						
										</tr>
									</tbody>
								</table>
							</div>
							
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>

<script>
$("#btnAdd").bind("click", function() {
		var clonetr = $("#TextBoxContainer").clone().addClass('TextBoxContainer');
		clonetr.removeAttr('id');
		clonetr.find("table.add_row").remove();
		clonetr.find('.sno').html('<span class="fa fa-trash-o" style="color:red;" onclick="$(this).parent().parent().remove();"></span>');
		clonetr.find('input').val('');
		clonetr.find('.staff option[value=""]').prop('selected',true);
		$("#addBefore").before(clonetr);
		autocomplete_serr();
		$('.TextBoxContainer').last().children().find('.qt').removeAttr('readonly');
		$('.TextBoxContainer').last().children().find('.package_service_quantity').remove();
		$('.TextBoxContainer').last().children().find('.package_service_inv').remove();
		change_event();
	});
	
	

	
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtsdigital/p4.gts.digital/Gts_salon/resources/views/admin/product_used.blade.php ENDPATH**/ ?>