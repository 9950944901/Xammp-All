                        
                        <?php $__env->startSection('page_title','View Branches'); ?>
                        <?php $__env->startSection('contant'); ?>
                        
                        
                        <style>
                        
                        .active{
                        font-size: 14px;
                        background-image: linear-gradient(to right, rgb(218, 34, 255) 0%, rgb(151, 51, 238) 51%, rgb(218, 34, 255) 100%);
                        
                        }
                        
                        
                        .inactive{
                        font-size: 14px;
                        background-image: linear-gradient(to right, rgb(255, 81, 47) 0%, rgb(240, 152, 25) 51%, rgb(255, 81, 47) 100%);
                        }
                        
                        
                        </style>
                        
                        <div class="page-wrapper">
                        <div class="page-content">
                        
                        
                        <div class="col-sm-12">
                        <div class="container-fluid">
                        <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row">
                        <div class="col-lg-12">
                        <div class="card">
                        <div class="card-header"><i class="fa fa-table"></i>View Branches<a style="float: right;" class="btn btn-primary" href="branches_add"><i class="fa fa-plus-circle" style="margin-right: 0;" aria-hidden="true"></i></a></div>
                        <div class="card-body">
                        <div class="table-responsive">
                        
                        
                        <table id="example2" class="table table-bordered" style="width:100%">
                        <thead>
                           
                        <tr>
                        <th>Sr.No.</th>
                        <th>Branch name</th>
                        <th>Salon name</th>
                        <th>Logo</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Website</th>
                        <th>GST</th>
                        <th>Working hours</th>
                        <th>Status</th>
                        <th>Action</th>
                        </tr>
                        
                        </thead>
                        <tbody>
                        
                        <?php $i=0;?>
                        
                        
                         <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        <tr role="row" class="odd text-center">
                        <td><?php $i++;?><?php echo e($i); ?></td>
                        <td><?php echo e($item->branchname); ?></td>
                        <td><?php echo e($item->salonname); ?></td>
                        <td><a href="<?php echo e(('../uploads/brands/'.$item->logo)); ?>" data-fancybox="images" data-caption="This image has a caption">
                        <img src="<?php echo e(('../uploads/brands/'.$item->logo)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;">
                        </a></td>
                        <td><?php echo e($item->phone); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <td><?php echo e($item->website); ?></td>
                        <td><?php echo e($item->gst); ?></td>
                        <td><?php echo e($item->working_hourse_start); ?>:<?php echo e($item->working_hourse_end); ?></td>
                         <td><?php echo e($item->status); ?></td>
                            <td>
                                  
                                <a class="btn btn-primary" href="branches_edit<?php echo e($item->id); ?>"><i class="fa fa-pencil"></i></a>
                            <a class="btn btn-danger" onclick="return confirm('Are you sure?')" href="branches_delete<?php echo e($item->id); ?>"><i class="fa fa-trash-o"></i></a>
                            </td>
                        
                       
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                            
                        </tbody>
                        
                        </table>
                        
                        <div class="d-flex justify-content-flex-end Pagination_1" >
                       
                        </div>
                        </div>
                        </div>
                        </div>
                        </div>
                        </div>
                        </div>
                        </div>
                        </div>
                        </div>
                        
                        
                        <script>let elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
                        
                        elems.forEach(function(html) {
                        let switchery = new Switchery(html,  { size: 'small' });
                        });</script>
                        
                        
                        <script>
                        
                        
                        $(document).ready(function(){
                        $('.js-switch').change(function () {
                        let status = $(this).prop('checked') === true ? 1 : 0;
                        let userId = $(this).data('id');
                        $.ajax({
                        type: "GET",
                        dataType: "json",
                        url: 'expense.update.Status',
                        data: {'Status': status, 'id': userId},
                        success: function (data) {
                        alert(data.message);
                        }
                        });
                        });
                        });
                        
                        </script>
                        
                        <script>
                        
                        success: function (data) {
                        toastr.options.closeButton = true;
                        toastr.options.closeMethod = 'fadeOut';
                        toastr.options.closeDuration = 100;
                        toastr.success(data.message);
                        }
                        </script>
                        
                        
                        
                        
                        <style>
                        
                        .w-5 {
                        display: none;
                        }
                        
                        .h-5{
                        display: none;
                        }
                        
                        </style>
                        
                        
                        <?php $__env->stopSection(); ?>
                        <?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/allbranches/index.blade.php ENDPATH**/ ?>