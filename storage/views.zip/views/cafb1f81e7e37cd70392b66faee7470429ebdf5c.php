
<?php $__env->startSection('contant'); ?>


<div class="page-wrapper">
<div class="page-content">


<div class="container-fluid">

<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header text-uppercase">Update Child-Categroy</div>
<div class="card-body">
<form method="POST" action="admin/update-childcategroy" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<input type="hidden" name="id" value="<?php echo e($upadatechildcat['id']); ?>">


<div class="form-group row">
<label for="basic-input" class="col-sm-3 col-form-label">Child Category Name</label>
<div class="col-sm-9">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($upadatechildcat['child_categroy']); ?>" name="childcategory" placeholder="some text" value="">
</div>

</div>
</div>



<div class="form-group row">
<label for="basic-input" class="col-sm-3 col-form-label">Image</label>
<div class="col-sm-9">
<div class="col-sm-3">
<P> <span><input type="file" name="image" class="form-control" autocomplete="nope" ></span></P>
<input type="hidden" name="logohidden" value="<?php echo e($upadatechildcat['image']); ?>">
<img src="<?php echo e(('../uploads/Child_categroy/'.$upadatechildcat->image)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 70px; height: 35px;">
</div>
</div>
</div>




<div class="form-group row">
<label for="basic-input" class="col-sm-3 col-form-label">Description</label>
<div class="col-sm-9">
<div class="input-group mb-3">
<textarea name="editor" ><?php echo e($upadatechildcat['description']); ?></textarea>
</div>
</div>
</div>

</div>

<p class="text-center"><button type="submit" value="submit"  class="btn btn-success" name="submit">Update</button></p>

</form>

</div>
</div>
</div><!--end row-->
</div>



<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->
<?php $__env->stopSection(); ?>



<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hypergroups/public_html/newlaravel/resources/views/admin/update-childcategroy.blade.php ENDPATH**/ ?>