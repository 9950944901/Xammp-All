<?php $__env->startSection('contant'); ?>

<style>
    .panel-heading {
    position: relative;
    border: 0;
    background-color: #f2f2f2;
    border-radius: 4px;
}
.btn-filter, .btn-filter:hover, .btn-filter:active, .btn-filter:visited, .btn-filter:focus {
       background: #9d4ee8;
    color: #fff;
    padding: 8px 13px;
}
  .btn-danger:hover {
    padding: 8px 14px;
    color: #fff;
    background-color: #d10b1e;
    border-color: #b02a37;
}
.btn-danger {
      padding: 8px 14px;
    color: #fff;
    background-color: #fd3550;
    border-color: #fd3550;
}
.form-group1{
      float: right;
}
</style>

<div class="page-wrapper form_wraper_icon">
			<div class="page-content">

            <div class="container-fluid">
 <div class="panel-heading heading-with-btn">
						<h4 class="pull-left">Daily reports</h4>
						    <!--<a href="email-report.php" target="_blank">-->
						    <!--<a href="#" target="_blank">-->
    						<!--    <button type="button" class="btn btn-warning pull-right">-->
    						<!--        <i class="fa fa-file-pdf-o" aria-hidden="true"></i>PDF report-->
    						<!--    </button>-->
    						<!--</a>-->
						<span id="download-btn"><div class="btn-group d-block custom-download-btn pull-right"><a class="btn buttons-excel buttons-html5 btn-warning pull-right download-btn mr-left-5" tabindex="0" aria-controls="mytable" title="Export to Excel"><span><i class="fa fa-file-excel-o" aria-hidden="true"></i> Export</span></a></div></span>					
						<div class="clearfix"></div>
							
					    <div class="clearfix"></div>
					</div>
					
					<div class="col-md-12">
						        <div class="row">
    						        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
    									<div class="form-group">
    										<label for="date">Select dates</label>
    										<input type="text" class="form-control" range-attr="daterange" id="daterange" name="date" value="07/02/2022 - 07/02/2022" placeholder="01/01/1990 - 12/05/2000" required="" readonly="">		
    									</div>
    								</div>
    								<div class="col-md-5 col-md-5 col-sm-5 col-xs-12">
    								    <lable>&nbsp;</lable>
    								    <div class="form-group">
    								        <button class="btn btn-filter btn-sm" onclick="filterDailyreport()"><i class="fa fa-filter" aria-hidden="true"></i>Filter</button>&nbsp;&nbsp;&nbsp;&nbsp;<button class="btn btn-danger btn-sm" onclick="window.location.href='dailyreport.php'"><i class="fa fa-times" aria-hidden="true"></i>Clear</button>
    								    </div>
    								</div>
    									<div class="col-md-3 col-md-3 col-sm-3 col-xs-12">
    								    <lable>&nbsp;</lable>
    								    <div class="form-group1">
    								        	<div id="mytable_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control input-sm" placeholder="" aria-controls="mytable"></label></div>
    								    </div>
    								</div>
    							</div>
						    </div>
						    	
    						
    						
 <div class="row">
	<div class="col-lg-12">
          <div class="card">

          <div class="row">
                     <!--<div class="col-md-6 text-end"> </div>-->
          
          </div>
		 
         
            <div class="card-body">
              
			<div class="table-responsive">
	          <table class="table table-bordered">
            <thead>
                 <tr>
                <th><b>Total invoice amount</b></th>
                <th>48.00</th>
              </tr>
              <tr>
                <th>Total invoice amount</th>
                <td>48.00</td>
              </tr>

			  
			  <tr>
                <th>Mobile Number</th>
             <td>	0.00   </td>
              </tr>
              <tr>
                <th>Total Collection</th>
                <td>655.00</td>
              </tr>
              
              
               <tr>
                <th>Product Sales</th>
                <td>0.00</td>
              </tr>

              <tr>
                <th>Service Sales</th>
                <td>60.00</td>
              </tr>

              <tr>
                <th>Pending payment received</th>
                <td>605.00</td>
              </tr>


              <tr>
                <th>Pending payment received</th>
                <td>0.00</td>
              </tr>


              <tr>
                <th>Appointment advance</th>
                <td>2.00</td>
              </tr>


              <tr>
                <th>Wallet re-charged</th>
                <td>30.00</td>
              </tr>


              <tr>
                <th>Cash</th>
                <td>0.00</td>
              </tr>


              <tr>
                <th>Online payment</th>
                <td>0.00</td>
              </tr>


              <tr>
                <th>Credit/Debit Card </th>
                <td>0.00</td>
              </tr>

              <tr>
                <th>Cheque</th>
                <td>0.00</td>
              </tr>

              <tr>
                <th>Paid by wallet </th>
                <td>0.00</td>
              </tr>


              <tr>
                <th>Paytm </th>
                <td>0.00</td>
              </tr>


              <tr>
                <th>PhonePe</th>
                <td>0.00</td>
              </tr>


              <tr>
                <th>Paid by Reward points</th>
                <td><b>Inclusive tax</b> : 0.00<br><b>Inclusive tax</b> : 0.00</td>
              </tr>
 <tr>
                <th>Total Discount given</th>
                <td>0.96</td>
              </tr>
               <tr>
                <th>Total TAX</th>
                <td>1</td>
              </tr>
               <tr>
                <th>Total commisions payable</th>
                <td>1</td>
              </tr>
               <tr>
                <th>Total Clients</th>
                <td>0.00</td>
              </tr>
               <tr>
                <th>Total new clients</th>
                <td>3.00</td>
              </tr>
               <tr>
                <th>Expenses Total</th>
                <td>2.00</td>
              </tr>
          </thead>
          </table>
        </div>

			</div>
            </div>
          </div>     
          </div>
          	</div>  
              </div>
             </div>	 
	<?php $__env->stopSection(); ?>




<?php echo $__env->yieldPushContent('footer_script'); ?>
































<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/day_summary_view.blade.php ENDPATH**/ ?>