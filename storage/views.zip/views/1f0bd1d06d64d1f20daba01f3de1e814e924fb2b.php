

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<div class="page-wrapper form_wraper_icon">
	<div class="page-content">
        <div class="container-fluid">
 

<div class="row">
	<div class="col-lg-5">
	        <div style="text-align:center;font-size:40px">
                    <!--<p><img src="<?php echo e(URL::asset('assets/images/logo_salon.png')); ?>" style="max-width:200px"></p>-->
					<p style="font-size:12px;max-width:250px;text-align:center;margin:0px auto;text-transform:uppercase;margin-bottom:2px;"><b></b></p>
			                <p style="font-size:12px;max-width:250px;text-align:center;margin:0px auto;"><b>Contact : <?php echo e($setting->mobile); ?></b></p>
							<p style="font-size:12px;max-width:250px;text-align:center;margin:0px auto;"><b>Email : <?php echo e($setting->email); ?></b></p>
							<!--<p style="font-size:12px;max-width:250px;text-align:center;margin:0px auto;"><b>Website : <?php echo e($setting->mobile); ?></b></p>-->
					</div>
					
			<!--<h4 style="letter-spacing:4px;text-align:center;">SALES INVOICE</h4>-->
	  <!--      <p style="font-size:14px;max-width:250px;text-align:center;margin:0px auto;"><b>(Branch : </b>Branch 1)</p>-->
	        <hr style="margin-top:9px;margin-bottom:9px;border-color:#8c8c8c;">
	    
	    
          <div style="padding:0px 12px;">
        <table style="width:100%;font-size:12px;font-weight:600;">
                        <tbody><tr style="vertical-align: top;">
                <td>Customer Name</td>
                <td> : <?php echo e($billdata->client_name); ?></td>
            </tr>
                                    <tr style="vertical-align: top;">
                <td>Mobile No</td>
                <td> : <?php echo e($billdata->number); ?></td>
            </tr>
            <!--                        <tr style="vertical-align: top;">-->
            <!--    <td>Email Id </td>-->
            <!--    <td> : proskincareesthetics@gmail.com</td>-->
            <!--</tr>-->
             <!--                                               	<tr style="vertical-align: top;">-->
	            <!--    <td>Wallet Balance:</td>-->
	            <!--    <td> : INR 2 /-</td>-->
            	<!--</tr>-->
                                    <tr style="vertical-align: top;">
                <td>Invoice No </td>
                <td> : #INV<?php echo e($billdata->id); ?></td>
            </tr>
            <!--                        <tr style="vertical-align: top;">-->
            <!--    <td>Membership id</td>-->
            <!--    <td> : #MEM0004</td>-->
            <!--</tr>-->
            <!--                        <tr style="vertical-align: top;">-->
            <!--    <td>Membership name</td>-->
            <!--    <td> : Gold Membership</td>-->
            <!--</tr>-->
            <!--                        <tr style="vertical-align: top;">-->
            <!--    <td>Invoice Date </td>-->
            <!--    <td> : 02-07-2022 11:03 AM</td>-->
            <!--</tr>-->
                    </tbody></table>
    </div>
        <hr style="margin-top:9px;margin-bottom:9px;border-color:#8c8c8c;">
            <div>
        		<table style="width:100%;font-size:12px;font-weight:600;border-collapse:collapse;">
        			<thead>
        				<tr style="font-size: 11px;">
        					<td style="padding:0px 7px 12px 7px;border-bottom:1px solid #8c8c8c;"><strong>Service &amp; Product</strong></td>
        					<td style="padding:0px 7px 12px 7px;border-bottom:1px solid #8c8c8c;"><strong>Provider</strong></td>
        					<td style="padding:0px 7px 12px 7px;border-bottom:1px solid #8c8c8c;"><strong>Rate</strong></td>
        					<td style="padding:0px 7px 12px 7px;border-bottom:1px solid #8c8c8c;"><strong>Dis</strong></td>
        					<td style="padding:0px 7px 12px 7px;border-bottom:1px solid #8c8c8c;"><strong>Qty</strong></td>
        					<td style="padding:0px 7px 12px 7px;border-bottom:1px solid #8c8c8c;"><strong>Total</strong></td>
        				</tr>
        			</thead>
        			<tbody>
        			        				<tr style="font-size:12px;">
            					<td style="padding:5px 7px;vertical-align:top;">Service Eyebrows </td>
            					<td style="padding:5px 7px;vertical-align:top;">
            					    Rashmi <br>    					</td>
            					<td style="padding:5px 7px;vertical-align:top;"><?php echo e($billmeta->price); ?></td>
            					<?php
            				        if($billmeta->discount_type == '1'){
                					    $type = 'INR';
                					    $prc = $billmeta->price;
                					    $qty = $billmeta->quantity;
                					    $subtotal = $prc*$qty;
                					    $total = $subtotal-$billmeta->discount;
            					    }else{
                					    $type = '%';
                					    $prc = $billmeta->price;
                					    $qty = $billmeta->quantity;
                					    $subtotal = $prc*$qty;
                			
                					    $per_discount = $subtotal * ($billmeta->discount/100);
                                        $total = $subtotal-$per_discount;
            					   
            					        
            					    }
            					?>
            					<td style="padding:5px 7px;vertical-align:top;"><?php echo e($billmeta->discount); ?> <?php echo e($type); ?></td>
            					<td style="padding:5px 7px;vertical-align:top;"><?php echo e($billmeta->quantity); ?></td>
            					<td style="padding:5px 7px;vertical-align:top;"><?php echo e($total); ?>.00</td>
            				</tr>
        					    </tbody>
        		</table>
        		<hr style="margin-top:9px;margin-bottom:9px;border-color:#8c8c8c;">
        		<table style="width:100%;font-size:12px;font-weight:600;border-collapse:collapse;">
        		    <tbody>
        		    <!--<tr>-->
        		    <!--    <td style="padding:0px 7px;"><strong>Total Qty </strong></td>-->
        		    <!--    <td style="padding:0px 7px;"> : <?php echo e($billmeta->quantity); ?></td>-->
        		    <!--    <td style="text-align:right;padding:0px 7px;">Total :</td>-->
        		    <!--    <td style="text-align:right;padding:0px 7px;"><?php echo e($total); ?>.00</td>-->
        		    <!--</tr>-->
        		    <!--<tr>-->
        		    <!--    <td rowspan="10" colspan="2" style="vertical-align:top;padding:0px 7px;">Payment Mode : <br>-->
        		    <!--        Reward points<br>Cash<br>		        </td>-->
        		    <!--    <td style="text-align:right;padding:0px 7px;">Coupon Dis :</td>-->
        		    <!--    <td style="text-align:right;padding:0px 7px;">0 </td>-->
        		    <!--</tr>-->
        		    <!--<tr>-->
        		    <!--    <td style="text-align:right;padding:0px 7px;">Discount : </td>-->
        		    <!--    <td style="text-align:right;padding:0px 7px;">12.00</td>-->
        		    <!--</tr>-->
        		    			<tr>
        				<td style="text-align:right;padding:0px 7px;"><strong>Tax : </strong></td>
        				<td style="text-align:right;padding:0px 7px;"><?php echo e($billdata->tax); ?></td>
        			</tr>
        			<?php 
        			    if($billdata->tax){
        			        $gstotal =  $total* (18/100);
        			        $gtotal = $gstotal+$total;
        			    }else{
        			        $gtotal =  $total;
        			    }
        			        $dueamount = $gtotal-$billdata->advance_amount;
        			?>
        			
        			<tr>
        				<td style="text-align:right;padding:0px 7px;"><strong>Total : </strong></td>
        				<td style="text-align:right;padding:0px 7px;"><?php echo e($gtotal); ?>.00</td>
        			</tr>
        			<tr>
        				<td style="text-align:right;padding:0px 7px;"><strong>Advance : </strong></td>
        				<td style="text-align:right;padding:0px 7px;"><?php echo e($billdata->advance_amount); ?>.00</td>
        			</tr>
        			<!--<tr>-->
        			<!--	<td style="text-align:right;padding:0px 7px;"><strong>Amount Paid : </strong></td>-->
        			<!--	<td style="text-align:right;padding:0px 7px;">50.00</td>-->
        			<!--</tr>-->
        			
        			<tr>
        				<td style="text-align:right;padding:0px 7px;"><strong>Amount Due : </strong></td>
        				<td style="text-align:right;padding:0px 7px;"><?php echo e($dueamount); ?>.00</td>
        			</tr>
        		</tbody></table>
        		<hr style="margin-top:9px;margin-bottom:9px;border-color:#8c8c8c;">
        		<br>
        		<p style="text-align:center;font-size:12px;font-weight:600;">****THANK YOU. PLEASE VISIT AGAIN****</p>
        	</div>
        	<div><center><button onclick="window.print();" class="printbtn btn btn-info">Print</button>
			<a href="billing.php" class="printbtn"><button class="printbtn btn btn-info">Back</button></a></center><br></div>
    </div>     
          </div>
          	</div>  
              </div>
             </div>	 
<?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/billing/billview.blade.php ENDPATH**/ ?>