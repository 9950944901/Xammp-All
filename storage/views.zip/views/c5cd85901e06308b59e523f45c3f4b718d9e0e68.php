<?php $__env->startSection('page_title','ADD COUPON'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> UPDATE COUPON
</div>
			     <div class="card-body">
				    <form method="POSt" action="admin/update_coupon" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
 <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<input type="hidden" name="id" value="<?php echo e($upadatecoupon['id']); ?>">
					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Coupon code </label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e($upadatecoupon->coupon_code); ?>" name="coupon_code" placeholder="Coupon code" value="">
							  </div>
							   <p style="color:red;"><?php $__errorArgs = ['coupon_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Discount </label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e($upadatecoupon->discount); ?>" name="discount" placeholder="Discount" >
							  </div>
						  </div>
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Discount type </label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            <select   name="discount_type" class="form-control single-select">
                            <option value="">--Select Option--</option>
                            <option value="1" <?php echo e(($upadatecoupon->discount_type)=='1' ? 'selected' : ''); ?>>%</option>
                            <option value="0" <?php echo e(($upadatecoupon->discount_type)=='0' ? 'selected' : ''); ?>>FIXED AMOUNT</option>
                            </select> 
                            </div>
                            </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Minimum bill amount</label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e($upadatecoupon->min_bill_amount); ?>" name="min_bill_amount" placeholder="Minimum bill amount" value="">
							  </div>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Maximum discount amount  </label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e($upadatecoupon->max_discount_amount); ?>" name="max_discount_amount" placeholder="Maximum discount amount " value="">
							  </div>
						  </div>
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Coupons per user </label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e($upadatecoupon->coupon_per_user); ?>" name="coupon_per_user" placeholder="Coupons per user " value="">
							  </div>
						  </div>
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Valid till </label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input  class="form-control" id="date_picker" type="date" value="<?php echo e($upadatecoupon->valid_till); ?>" name="valid_till" placeholder="Valid till " value="">
							  </div>
						  </div>
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Reward points </label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e($upadatecoupon->reward_points); ?>" name="reward_points" placeholder="Reward points " value="">
							  </div>
						  </div>
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Status </label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            <select name="status"  class="form-control single-select">
                            <option value="">--Select Option--</option>
                            <option value="1" <?php echo e(($upadatecoupon->status)=='1' ? 'selected' : ''); ?>>Active</option>
                            <option value="0" <?php echo e(($upadatecoupon->status)=='0' ? 'selected' : ''); ?>>Inactive</option>
                            </select> 
                            </div>
                            </div>
						  
						  </div>
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>

    
    <script>
   var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0');
    var yyyy = today.getFullYear();

    today = yyyy + '-' + mm + '-' + dd;
    $('#date_picker').attr('min',today);
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtsdigital/public_html/Gts_salon/resources/views/admin/update_coupon.blade.php ENDPATH**/ ?>