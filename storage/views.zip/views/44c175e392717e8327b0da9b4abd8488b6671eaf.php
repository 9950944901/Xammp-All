
<?php $__env->startSection('page_title','Edit MEMBERSHIP'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
<div class="page-content">

<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header text-uppercase"> Edit Membership
</div>
<div class="card-body">
<form method="POSt" action="membership_update" class="form-horizontal"  enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <input type="hidden" name="id" value="<?php echo e($membership->id); ?>">
<div class="form-group row">
<label for="basic-input" class="col-sm-2 col-form-label">Membership type name <span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($membership->membership_name); ?>" name="membership_name" placeholder="Enter Membership type name" value="">
</div>
<p style="color:red;"><?php $__errorArgs = ['membership_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Membership price <span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($membership->membership_price); ?>" name="membership_price" placeholder="Membership price " value="">
</div>
<p style="color:red;"><?php $__errorArgs = ['membership_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Duration (in days start from day of purchase)<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($membership->duration_day_purchase); ?>" name="duration_day_purchase" placeholder="Duration (in days start from day of purchase)" value="">
</div>
<p style="color:red;"><?php $__errorArgs = ['duration_day_purchase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Reward points on purchase <span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($membership->reward_points); ?>" name="reward_points" placeholder="Reward points on purchase" >
</div>
<p style="color:red;"><?php $__errorArgs = ['reward_points'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>


<label for="basic-input" class="col-sm-2 col-form-label">Discount on services<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($membership->discount_on_service); ?>" name="discount_on_service" placeholder="0" value="">&nbsp;
<p style="color:red;"><?php $__errorArgs = ['discount_on_service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
 <select name="discount_on_service_type" class="form-control single-select">
    <option value="1" <?php echo e($membership->discount_on_service_type == '1' ? 'selected' : ''); ?>>%</option>
    <option value="2" <?php echo e($membership->discount_on_service_type == '2' ? 'selected' : ''); ?>>INR</option>
</select> 
<p style="color:red;"><?php $__errorArgs = ['discount_on_service_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

</div>

<label for="basic-input" class="col-sm-2 col-form-label">Discount on products<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($membership->discount_on_product); ?>" name="discount_on_product" placeholder="0" value="">&nbsp;
<p style="color:red;"><?php $__errorArgs = ['discount_on_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
 <select name="discount_on_product_type" class="form-control single-select">
    <option value="1" <?php echo e($membership->discount_on_product_type == '1' ? 'selected' : ''); ?>>%</option>
    <option value="2" <?php echo e($membership->discount_on_product_type == '2' ? 'selected' : ''); ?>>INR</option>
</select> 
<p style="color:red;"><?php $__errorArgs = ['discount_on_product_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

</div>

<label for="basic-input" class="col-sm-2 col-form-label">Discount on packages <span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($membership->discount_on_packages); ?>" name="discount_on_packages" placeholder="0" value="">&nbsp;
<p style="color:red;"><?php $__errorArgs = ['discount_on_packages'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
 <select name="discount_on_package_type" class="form-control single-select">
    <option value="1" <?php echo e($membership->discount_on_package_type == '1' ? 'selected' : ''); ?>>%</option>
    <option value="2" <?php echo e($membership->discount_on_package_type == '2' ? 'selected' : ''); ?>>INR</option>
</select> 
<p style="color:red;"><?php $__errorArgs = ['discount_on_service_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

</div>

<label for="basic-input" class="col-sm-2 col-form-label">Reward points boost <span style="color:red;">*</span></label>
<div class="col-sm-4">
    <div class="input-group mb-3">
        <select name="reward_points_boost" class="form-control single-select">
            <option value="1X" <?php echo e($membership->reward_points_boost == '1X' ? 'selected' : ''); ?>>1X</option>
            <option value="2X" <?php echo e($membership->reward_points_boost == '2X' ? 'selected' : ''); ?>>2X</option> 
            <option value="3X" <?php echo e($membership->reward_points_boost == '3X' ? 'selected' : ''); ?>>3X</option>
            <option value="4X" <?php echo e($membership->reward_points_boost == '4X' ? 'selected' : ''); ?>>4X</option> 
        </select> 
    </div>
    <p style="color:red;"><?php $__errorArgs = ['reward_points_boost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>


<label for="basic-input" class="col-sm-2 col-form-label">Min. reward points earned   <span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control " value="<?php echo e($membership->min_rewad); ?>" name="min_rewad" placeholder="Min. reward points earned  " value="">&nbsp;
</div>
<p style="color:red;"><?php $__errorArgs = ['min_rewad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>


<label for="basic-input" class="col-sm-2 col-form-label">Reward points boost <span style="color:red;">*</span></label>
<div class="col-sm-4">
    <div class="input-group mb-3">
        <select name="points_condition" class="form-control single-select">
            <option value="AND" <?php echo e($membership->points_condition == 'AND' ? 'selected' : ''); ?>>AND</option>
            <option value="OR" <?php echo e($membership->points_condition == 'OR' ? 'selected' : ''); ?>>OR</option> 
        </select> 
    </div>
    <p style="color:red;"><?php $__errorArgs = ['points_condition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>


<label for="basic-input" class="col-sm-2 col-form-label">Min. billed amount  <span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control " value="<?php echo e($membership->min_billed_amount); ?>"  name="min_billed_amount" placeholder="Emergency contact person" value="">&nbsp;
</div>
<p style="color:red;"><?php $__errorArgs = ['min_billed_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
</div>



<p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
</div>
</form>
</div>
</div>
</div>
</div>

</div>
</div>
</div>
<script> 

    
function checkpass() {		
	if ($('#password').val() != $('#confirm_password').val()){
		//alert('Password Length 6 Chars minimum');
		$("#message").html('Password Not Matching').css('color', 'red');
		$('#confirm_password').val("");
	} else if($('#password').val() === $('#confirm_password').val()){
		$("#message").html('');
	}
}


    
function checklength() {		
	if($("#password").val().length <= 5 && $("#password").val().length > 0){
		//alert('Password Length 6 Chars minimum');
		$("#pass-status").html('Password Length 6 character minimum');
		$('#password').val("");
	} else if($("#password").val().length > 5 || $("#password").val().length <= 0){
		$("#pass-status").html('');
	}
}

	function contact_no_length(currDiv, phone_number){
	    var digit = phone_number.length;
	    if(digit > 0 && digit < 10){
	        currDiv.val('');
	        $('#digit_error').text('Please enter 10 digit number.');
	    } else {
	        $('#digit_error').text('');
	    }
	}
	
	
	function othercontact(currDiv, phone_number){
	    var digit = phone_number.length;
	    if(digit != 10){
	        currDiv.parent().find('input').val('');
	        currDiv.parent().find('#conterror').text('Please enter 10 digit number.');
	    } else {
	        currDiv.parent().find('#conterror').text('');
	    } 
	}
	
  
    


</script> 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtsdigital/p4.gts.digital/Gts_salon/resources/views/admin/membership/edit.blade.php ENDPATH**/ ?>