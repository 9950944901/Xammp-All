
<?php $__env->startSection('page_title','Billing Reports'); ?>
<?php $__env->startSection('contant'); ?>


<style>

.active{
font-size: 14px;
background-image: linear-gradient(to right, rgb(218, 34, 255) 0%, rgb(151, 51, 238) 51%, rgb(218, 34, 255) 100%);

}


.inactive{
font-size: 14px;
background-image: linear-gradient(to right, rgb(255, 81, 47) 0%, rgb(240, 152, 25) 51%, rgb(255, 81, 47) 100%);
}


</style>

<div class="page-wrapper form_wraper_icon">
<div class="page-content">


<div class="col-sm-12">
<div class="container-fluid">

<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header billing_re_gray">Billing Reports<a style="float: right; font-size:13px;" class="btn btn-primary" href="#"><i class="fa fa-file-excel-o mr-2" aria-hidden="true"></i>Export</a></div>
<div class="input_form_admin">
    <form method="POSt" action="billsearch" class="form-horizontal" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
     <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row">
            <div class="col-sm-3">
    			<div class="form-group">
                    <label for="select_date">Select date</label>
                    <input type="date" class="form-control" name="date" value="">
                  </div>
    		 </div>
    		  <div class="col-sm-3">
    			<div class="form-group">
                    <label for="select_date">Service provider</label>
                    <select class="form-control" name="service_provider_id">
					 <option value="">select</option>
                     <?php $__currentLoopData = $serviceprovider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <option value="<?php echo e($provider->name); ?>"><?php echo e($provider->name); ?></option>
				     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				     </select>
                  </div>
    		 </div>
    		  <div class="col-sm-3">
    			<div class="form-group">
                    <label for="select_date">Service</label>
                     <select class="form-control" name="service_id">
					 <option value="">select</option>
                     <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <option value="<?php echo e($value->id); ?>"><?php echo e($value->ser_name); ?></option>
				     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </select>
                  </div>
    		 </div>
    		 
    		  <div class="col-sm-3">
    			<div class="form-group">
    			    <label for="select_date">&nbsp;</label>
                   <div class="row">
                       <div class="col-md-6">
                           <button type="submit" class="btn btn-success col-md-12"><i class="fa fa-filter mr-2" aria-hidden="true"></i> Filter</button>
                           </div>
                       <div class="col-md-6"> 
                       <a href="#" class="btn btn-danger col-md-12"><i class="fa fa-times mr-2" aria-hidden="true"></i> Close</a>
                       </div>
                   </div>
                    
                   
                  </div>
    		 </div>
       </div> 
       </form>
</div>

<div class="card-body">
<div class="table-responsive">


<table id="example2" class="table table-bordered" style="width:100%">
<thead>
<tr>
<th>Sr. no</th>
<th>Bill Date</th>
<th>Client Name</th>
<th>Mobile</th>
<th>Total</th>
<th>Tax</th>
<th>Appointment advance</th>
<th>Advance Type</th>
<th>Payable Amount</th>
</tr>
</thead>
<tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <tr role="row" class="odd">
            <td><?php echo e($value->id); ?></td>
            <td><?php echo e(date("d F Y", strtotime($value->date_of_billing))??''); ?></td>
            <td><?php echo e($value->client_name); ?></td>
            <td><?php echo e($value->number); ?></td>
            <td><?php echo e($value->total_amount); ?></td>
            <td><?php echo e($value->tax); ?> %</td>
            <td><?php echo e($value->advance_amount); ?></td>
           
            <td><?php echo e($value->advance_type); ?></td>
           
            <td><?php echo e($value->total_pending_amount); ?></td>
            <td>
                <a class="btn btn-primary" href="editbill<?php echo e($value->id); ?>"><i class="fa fa-pencil"></i></a>
                <a class="btn btn-success" href="view-bill<?php echo e($value->id); ?>"><i class="fa fa-eye" aria-hidden="true"></i></a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</tbody>

</table>

<div class="d-flex justify-content-flex-end Pagination_1" >

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>


<script>let elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));

elems.forEach(function(html) {
let switchery = new Switchery(html,  { size: 'small' });
});</script>


<script>


$(document).ready(function(){
$('.js-switch').change(function () {
let status = $(this).prop('checked') === true ? 1 : 0;
let userId = $(this).data('id');
$.ajax({
type: "GET",
dataType: "json",
url: 'vendor.update.Status',
data: {'Status': status, 'id': userId},
success: function (data) {
alert(data.message);
}
});
});
});

</script>

<script>

success: function (data) {
toastr.options.closeButton = true;
toastr.options.closeMethod = 'fadeOut';
toastr.options.closeDuration = 100;
toastr.success(data.message);
}
</script>




<style>

.w-5 {
display: none;
}

.h-5{
display: none;
}

</style>


<?php $__env->stopSection(); ?>
<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/reports/billing_report_view.blade.php ENDPATH**/ ?>