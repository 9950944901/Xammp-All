
<?php $__env->startSection('contant'); ?>


<div class="page-wrapper">
			<div class="page-content">
				

    <div class="container-fluid">

	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> System Setting</div>
			     <div class="card-body">
				    <form method="POSt" action="admin/websetting" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Company Name</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('companynames')); ?>" name="companynames" placeholder="some text" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['companynames'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						</div>
					
						
						<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Email</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
							<input type="text" class="form-control" value="<?php echo e(old('email')); ?>" name="email" placeholder="Enter email" >
						  </div>
                          <p style="color:red;"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						</div>
						
						<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Mobile Number</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<input type="text" class="form-control" name="mobile" placeholder="Enter Mobile Number" value="<?php echo e(old('mobile')); ?>">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						</div>

                        <div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Tagline</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="textarea" class="form-control" name="tagline" placeholder="some text"></textarea>
							  </div>
						  </div>
						</div>
						
						<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Address</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="text" class="form-control" name="address" value="<?php echo e(old('address')); ?>" placeholder="Enter Address"></textarea>
							  </div>
						  </div>
						</div>
						
						<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Logo</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<input type="file" class="form-control"  name="logo">
							  </div>
						  </div>
						</div>
						
						<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Favicon</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">

								<input type="file" class="form-control"  name="favicon">
							  </div>
						  </div>
						</div>
						
						<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Footer Logo</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
				
								<input type="file" class="form-control"  name="footerlogo">
							  </div>
						  </div>
						</div>
					
						
                        <div class="form-group row">
                        <label for="basic-input" class="col-sm-3 col-form-label">AboutUs Images</label>
                        <div class="col-sm-9">
                        <div class="input-group mb-3">
                        <input type="file" class="form-control"  name="Aboutimg">
                        </div>
                        </div>
                        </div>
	
						<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">AboutUs title</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="text" class="form-control" name="abouttitle" placeholder="some text"><?php echo e(old('abouttitle')); ?></textarea>
							  </div>
						  </div>
						</div>

		<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Aboutus Description</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea name="editor" value="<?php echo e(old('editor')); ?>"></textarea>
							  </div>
						  </div>
						</div>
						
						
						
							<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Facebook</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="text" class="form-control" value="<?php echo e(old('facebook')); ?>" name="facebook" placeholder="some url"></textarea>
							  </div>
						  </div>
						</div>
						
							<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Instagram</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="text" class="form-control" value="<?php echo e(old('instagram')); ?>" name="instagram" placeholder="some url"></textarea>
							  </div>
						  </div>
						</div>
						
							<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Twitter</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="text" class="form-control" value="<?php echo e(old('twitter')); ?>" name="twitter" placeholder="some url"/></textarea>
							  </div>
						  </div>
						</div>
							<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Pinterest</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="text" class="form-control" value="<?php echo e(old('Pinterest')); ?>" name="Pinterest" placeholder="some url"></textarea>
							  </div>
						  </div>
						</div>
                        <div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Linkdin</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="text" class="form-control" value="<?php echo e(old('linkdin')); ?>" name="linkdin" placeholder="some url"></textarea>
							  </div>
						  </div>
						</div>
						
						<div class="form-group row">
						  <label for="basic-input" class="col-sm-3 col-form-label">Youtube</label>
						  <div class="col-sm-9">
							<div class="input-group mb-3">
								<textarea type="text" class="form-control" value="<?php echo e(old('youtube')); ?>" name="youtube" placeholder="some url"></textarea>
								<div class="input-group-append">
							  </div>
						  </div>
						</div>
						</div>
<p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>

					</form>
		   
	    </div>
        </div>
								</div><!--end row-->
							</div>
					


   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
<?php $__env->stopSection(); ?>



<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newlaravel\resources\views/admin/websetting.blade.php ENDPATH**/ ?>