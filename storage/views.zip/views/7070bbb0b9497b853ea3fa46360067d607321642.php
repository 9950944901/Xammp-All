<?php $__env->startSection('page_title','Enquiry Reports'); ?>
<?php $__env->startSection('contant'); ?>
<style>
.btn-warning {
    width: 49%;
    margin: 23px 0px;
    background-color: #ffb400;
    border-color: #ffb400;
    color: #ffffff;
    padding: 7px 4px;
    font-size: 13px;
}
.btn-warning:hover {
    color: #ffffff;
    background-color: #e6a200;
    border: 1px solid #e6a200;
}
.Enquiry{
        margin-top: 30px;
}
.form_Select{
    display: flex;
    align-items: center;
}
.form-group{
       margin: 0 19px 0px 0px;
}
.filter_text {
    display: flex;
}





.pull-right {
    margin-top: 30px;
    float: right;
}

.form-control111 {
    display: block;
    width: 100%;
    padding: 0.25rem 0.75rem;
    font-size: .900rem;
    font-weight: 400;
    line-height: 1.5;
    color: #212529;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    -webkit-appearance: auto;
    -moz-appearance: none;
    appearance: auto;
    border-radius: 0.25rem;
    transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
}
.enquiry_tbl_length {
      width: 10%;
}
.labe_show{
        width: 12%;
}
.filter_text{
    
}

@media (max-width: 992px) {
    .form_Select {
            display: block;
    align-items: center;
}
}
</style>
<div class="container-fluid">
     <form method="POSt" action="enquirysearch" class="form-horizontal" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
        
              <div class="row">
                <div class="col-md-10">
            <h4 class="Enquiry">Enquiry Reports</h4>
            </div>
             <div class="col-md-2">
            <a class="btn buttons-excel buttons-html5 btn-warning pull-right download-btn mr-left-5" tabindex="0" aria-controls="enquiry_tbl" title="Export to Excel"><span><i class="fa fa-file-excel-o" aria-hidden="true"></i> Export</span></a>
            </div>

            <div class="col-md-12">
		        
		        <div class="filter_text">
					<div class="col-lg-4 col-md-3 col-sm-3 col-xs-4">
						<div class="form-group">
							<label class=" control-label">Select date</label>
							<input type="date" class="form-control111" range-attr="daterange" id="daterange" name="date" value=""  placeholder="">
						</div>
					</div>
					<div class="col-lg-2 col-md-3 col-sm-3 col-xs-4">
						<div class="form-group">
							<label class="control-label">Enquiry type</label>
							<select class="form-control111" name="enquirytype">
								<option value="">-- Select a type --</option>
								<option value="Hot" >Hot</option>
								<option value="cold" >Cold</option>
								<option value="Warm" >Warm</option>				
							</select>
						</div>
					</div>
					<div class="col-lg-2 col-md-3 col-sm-3 col-xs-4">
						<div class="form-group">
							<label class=" control-label">Source of lead</label>
								<select class="form-control111" name="leadsource" >
									<option value="" selected>-- Select A Type --</option>
									<option value="Google" >Google</option>
									<option value="Website" >Website</option>
									<option value="Google" >Google</option>
									<!--<option value="Twitter" >Twitter</option>-->
									<!--<option value="Instagram" >Instagram</option>-->
									<!--<option value="Other Social Media" >Other Social Media</option>-->
									<!--<option value="Website" >Website</option>-->
									<!--<option value="Walk-In" >Walk-In</option>-->
									<!--<option value="Flex" >Flex</option>-->
									<!--<option value="Flyer" >Flyer</option>-->
									<!--<option value="Newspaper" >Newspaper</option>-->
									<!--<option value="SMS">SMS</option>-->
									<!--<option value="Street Hoardings" >Street Hoardings</option>-->
									<!--<option value="Event" >Event</option>-->
									<!--<option value="TV/Radio" >TV/Radio</option>							-->
								</select>
						</div>
					</div>
					<div class="col-lg-2 col-md-3 col-sm-3 col-xs-4">
						<div class="form-group">
							<label class=" control-label">Lead status</label>
							<select class="form-control111" name="leadstatus" >
								<option value="" selected>-- Select a type --</option>
								<option value="2" >Pending</option>
								<option value="1" >Converted</option>
								<option value="0" >Close</option>							
							</select>
						</div>
					</div>
					<div class="col-lg-2 col-md-3 col-sm-3 col-xs-4">
						<div class="form-group">
							<label class=" control-label">Lead representative</label>
							<select class="form-control111" name="leaduser" >
								<option value="" selected>-- Select User --</option>
								<option value="Admin" >Admin</option>
								<option value="Dummy" >dummy</option>
								<option value="Demo" >demo</option>
								<!--<option value="36" >aman</option>-->
								<!--<option value="25" >anu</option>-->
								<!--<option value="32" >asd</option>-->
								<!--<option value="27" >dummy</option>-->
								<!--<option value="24" >kabita</option>-->
								<!--<option value="20" >neha</option>-->
								<!--<option value="28" >Nitika</option>-->
								<!--<option value="31" >nitika 1</option>-->
								<!--<option value="33" >Poonam2</option>-->
								<!--<option value="22" >RAHUL</option>-->
								<!--<option value="21" >RAHUL07</option>-->
								<!--<option value="35" >rahul2789</option>-->
								<!--<option value="34" >raj</option>-->
								<!--<option value="29" >Riya</option>-->
								<!--<option value="23" >sonukumar1999kn@gmail.com</option>-->
								<!--<option value="19" >xyz</option>-->
								<!--<option value="26" >xyzd</option>-->
							</select>
						</div>
					</div>
				</div>
            </div>
            <div class="col-lg-12">
				<div class="panel-body">
					<div class="form-group pull-right">
						<button type="submit" name="submit" class="btn btn-secondary"><i class="fa fa-filter " aria-hidden="true"></i>Filter</button>
						<button type="submit" name="reset" class="btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i>Reset</button>
					</div>
				</div>
			</div>
					
</form>

<div class="card-body">
<div class="table-responsive">


<table id="example2" class="table table-bordered" style="width:100%">
<thead>
<tr>
<th>Name</th>
<th>Email</th>
<th>Phone</th>
<th>Date to follow</th>
<th>Lead type</th>
<th>Enquiry for</th>

</tr>
</thead>
<tbody>
    <?php $__currentLoopData = $enquirylist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr role="row" class="odd">
            <td><?php echo e($enquiry->client_name); ?></td>
            <td><?php echo e($enquiry->email); ?></td>
            <td><?php echo e($enquiry->contact_number); ?></td>
            <td><?php echo e($enquiry->follow_date); ?></td>
            <td><?php echo e($enquiry->enquiry_type); ?></td>
            <td><?php echo e($enquiry->enquiry_for); ?></td>
            
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</tbody>

</table>

<div class="d-flex justify-content-flex-end Pagination_1" >

</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/EnquiryReports/enquiry_reports.blade.php ENDPATH**/ ?>