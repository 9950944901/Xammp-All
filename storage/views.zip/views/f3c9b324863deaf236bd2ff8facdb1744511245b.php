
<?php $__env->startSection('page_title','attendence_reports'); ?>
<?php $__env->startSection('contant'); ?>
     <div class="container-fluid">
<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			    <div class="panel-heading">
						<h4 class="Attendance">Attendance</h4>
					</div>
			    
			    <div class="row">
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
										<div class="form-group">
											<label for="from">Attendance type</label>
											<select class="form_controllgl" id="attendance_type" onclick="alert_show();">
											    <option value="1">Service provider</option>
											    <option value="2">Staff</option>
											</select>
										</div>
									</div>
		
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" id="suid_div">
										<div class="form-group">
											<label for="from">Select Service providers</label>
											<select class="form_controllgl" id="suid">
											    											                <option value="1">Test</option>
								                											                <option value="2">Poonam</option>
								                											                <option value="3">Riya</option>
								                											                <option value="4">Rahul</option>
								                											                <option value="5">RK</option>
								                											                <option value="6">Neha</option>
								                											                <option value="7">RASHMI</option>
								                											                <option value="8">Riya</option>
								                											                <option value="9">Shakir</option>
								                											                <option value="10">AJAY</option>
								                											                <option value="11">BHAWNA</option>
								                											                <option value="12">Room No.4</option>
								                											                <option value="13">Kabita Regmi</option>
								                											                <option value="14">Anu</option>
								                											                <option value="15">Navneeta</option>
								                											                <option value="16">ABC122</option>
								                											                <option value="17">Dummy</option>
								                											                <option value="18">Nitika sharma</option>
								                											                <option value="19">Anjali</option>
								                											                <option value="20">Aman</option>
								                											                <option value="21">Diya</option>
								                											                <option value="22">NAVNEETA</option>
								                											                <option value="23">Navneeta</option>
								                											                <option value="24">Riya</option>
								                											                <option value="25">Abc</option>
								                											                <option value="26">Rahul</option>
								                											                <option value="27">Poonam</option>
								                											                <option value="28">AMBRISH</option>
								                											                <option value="29">AMAN</option>
								                											                <option value="30">AMAN</option>
								                											                <option value="31">Anjali2</option>
								                											                <option value="32">Ridhima</option>
								                											                <option value="33">Rashmi</option>
								                											                <option value="34">Asd</option>
								                											                <option value="35">Test</option>
								                											                <option value="36">Ansh</option>
								                											                <option value="37">Rahul</option>
								                											                <option value="38">Raji</option>
								                											                <option value="39">Rahul</option>
								                											                <option value="40">RIYA PK</option>
								                											                <option value="41">Aman</option>
								                											</select>
										</div>
									</div>
									
									<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
										<div class="form-group">
											<label>Month</label>
											<select id="month" class="form_controllgl">
											    <option value="01">January</option>
											    <option value="02">February</option>
											    <option value="03">March</option>
											    <option value="04">April</option>
											    <option value="05">May</option>
											    <option value="06">June</option>
											    <option value="07" selected="">July</option>
											    <option value="08">August</option>
											    <option value="09">September</option>
											    <option value="10">October</option>
											    <option value="11">November</option>
											    <option value="12">December</option>
											</select>
										</div>
									</div>
									
									
									<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
										<div class="form-group">
											<label>Year</label>
											<select id="year" class="form_controllgl">
											    											            <option value="2020">2020</option>
											        											            <option value="2021">2021</option>
											        											            <option value="2022" selected="">2022</option>
											        											</select>
										</div>
									</div>
			<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12"><br>
										<button type="submit" class="btn btn_primary" id="date_filter"><i class="fa fa-filter" style="margin-left:0px;" aria-hidden="true"></i>Filter</button>
									</div>
			</div>
			
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12"><br>
			<button class="btn btn_warning" id="print"><i class="fa fa-print" style="margin-left:0px;" aria-hidden="true"></i>Print</button>
			</div>
			
			<table id="table-dash" class="table table-striped table-bordered " style="margin-top:20px;">
    			<thead>
    			    <tr>
    			        <th style="text-align:center;" colspan="32"><h3>Monthly Attendance Summery For Month July/2022</h3></th>
    			    </tr>
    				<tr>
    				    <th>Enroll Id: </th>
    				    <th colspan="5">1001</th>
    				    <th colspan="9">Employee Name: </th>
    				    <th colspan="5">Test</th>
    				    <th colspan="9">Ref Id: </th>
    				    <th colspan="3">1001</th>
    				</tr>
    			</thead>
  
    			<tbody>
    			    <tr>
    			        <td>Day</td>
    			        <td>1</td>
    			        <td>2</td>
    			        <td>3</td>
    			        <td>4</td>
    			        <td>5</td>
    			        <td>6</td>
    			        <td>7</td>
    			        <td>8</td>
    			        <td>9</td>
    			        <td>10</td>
    			        <td>11</td>
    			        <td>12</td>
    			        <td>13</td>
    			        <td>14</td>
    			        <td>15</td>
    			        <td>16</td>
    			        <td>17</td>
    			        <td>18</td>
    			        <td>19</td>
    			        <td>20</td>
    			        <td>21</td>
    			        <td>22</td>
    			        <td>23</td>
    			        <td>24</td>
    			        <td>25</td>
    			        <td>26</td>
    			        <td>27</td>
    			        <td>28</td>
    			        <td>29</td>
    			        <td>30</td>
    			        <td>31</td>    			   
    			        </tr>
    			        
    			    <tr>
    			        <td>In</td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>    			    
    			        </tr>
    			        
    			    <tr>
    			        <td>Out</td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>    			    
    			        </tr>
    			        
    			    <tr>
    			        <td>Total Hrs</td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>    			    
    			        </tr>
    			        
    			    <tr>
    			        <td>Status</td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>
    			        <td></td>    			    
    			        </tr>
    			</tbody>
    		</table>
    <style>
    @media  print
    {
        header, nav, .panel-heading, #filter_input, footer, .modal, #print {
            display: none;
        }
    
        #table-dash, #table-dash th, #table-dash td {
            border: 1px solid;
            border-collapse: collapse;
        }
        #table-dash td, #table-dash th{
            padding :3px 4px;
        }
        #table-dash{
            width: 100%;
        }
        
    }
    
.btn_primary {
    background-color: #4d4d4d;
    border-color: #4d4d4d;
    color: #ffffff;
}
.btn_primary:hover {
    background-color: #4d4d4d;
    border-color: #4d4d4d;
    color: #ffffff;
}
    
    .form_controllgl{
    display: block;
    width: 100%;
    padding: 0.25rem 0.75rem;
    font-size: .900rem;
    font-weight: 400;
    line-height: 1.5;
    color: #212529;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    -moz-appearance: none;
    border-radius: 0.25rem;
    transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
}

.btn_warning {
    background-color: #ffb400;
    border-color: #ffb400;
    color: #ffffff;
}
.Attendance{
        margin-top: 30px;
}  
    
</style>
<script>
    $(function() {
        $("#print").click(function (){
            if (window.print) {
                window.print();
            }
        });
    });
</script>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldPushContent('footer_script'); ?>


<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/attendence_reports/attendence_reports.blade.php ENDPATH**/ ?>