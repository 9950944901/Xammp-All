
<?php $__env->startSection('page_title','ADD SERVICE PROVIDER'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
<div class="page-content">

<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header text-uppercase"> Add Branch
</div>
<div class="card-body">
<form method="POSt" action="branches_post" class="form-horizontal"  enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="form-group row">
<label for="basic-input" class="col-sm-2 col-form-label">Enter Branch Name <span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e(old('branchname')); ?>" name="branchname" placeholder="Enter branch name" value="">
</div>
<p style="color:red;"><?php $__errorArgs = ['branchname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Salon name 
<!--<span style="color:red;">*</span>-->
</label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e(old('salonname')); ?>" name="salonname" placeholder="Salon name" value="">
</div>
<p style="color:red;"><?php $__errorArgs = ['service_commission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Logo 
<!--<span style="color:red;">*</span>-->
</label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="file" class="form-control" value="<?php echo e(old('logo')); ?>" name="logo"  value="">
</div>
<p style="color:red;"><?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Email
<!--<span style="color:red;">*</span>-->
</label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="email" class="form-control" value="<?php echo e(old('email')); ?>" name="email" placeholder="Email" >
</div>
<p style="color:red;"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Phone <span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="number" class="form-control" value="<?php echo e(old('phone')); ?>" maxlength="10" onBlur="contact_no_length($(this), this.value);" name="phone" placeholder="Contact number" value="">
</div>
<span style="color:red" id="digit_error"></span>
<p style="color:red;"><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Website 
<!--<span style="color:red;">*</span>-->
</label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e(old('website')); ?>"  name="website" placeholder="Website" value="">
</div>
<p style="color:red;"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Working hours <span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control timepicker" value="<?php echo e(old('working_hourse_start')); ?>" name="working_hourse_start" placeholder="Enter Start Time" value="">&nbsp;
<input type="text" class="form-control timepicker" value="<?php echo e(old('working_hourse_end')); ?>" name="working_hourse_end" placeholder="Enter End Time" value="">
</div>
<p style="color:red;"><?php $__errorArgs = ['working_hourse_end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">GST<span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="number" class="form-control " value="<?php echo e(old('gst')); ?>" name="gst" placeholder="Gst " value="">&nbsp;
</div>
<p style="color:red;"><?php $__errorArgs = ['gst'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Status <span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">
<select name="status" class="form-control single-select">
<option value="">--Select Option--</option>
<option value="Active">Active</option>
<option value="Inactive">Inactive</option>


</select> 
</div>
<p style="color:red;"><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>



</div>



<p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
</div>
</form>
</div>
</div>
</div>
</div>

</div>
</div>
</div>
<script> 

    
function checkpass() {		
	if ($('#password').val() != $('#confirm_password').val()){
		//alert('Password Length 6 Chars minimum');
		$("#message").html('Password Not Matching').css('color', 'red');
		$('#confirm_password').val("");
	} else if($('#password').val() === $('#confirm_password').val()){
		$("#message").html('');
	}
}


    
function checklength() {		
	if($("#password").val().length <= 5 && $("#password").val().length > 0){
		//alert('Password Length 6 Chars minimum');
		$("#pass-status").html('Password Length 6 character minimum');
		$('#password').val("");
	} else if($("#password").val().length > 5 || $("#password").val().length <= 0){
		$("#pass-status").html('');
	}
}

	function contact_no_length(currDiv, phone_number){
	    var digit = phone_number.length;
	    if(digit > 0 && digit < 10){
	        currDiv.val('');
	        $('#digit_error').text('Please enter 10 digit number.');
	    } else {
	        $('#digit_error').text('');
	    }
	}
	
	
	function othercontact(currDiv, phone_number){
	    var digit = phone_number.length;
	    if(digit != 10){
	        currDiv.parent().find('input').val('');
	        currDiv.parent().find('#conterror').text('Please enter 10 digit number.');
	    } else {
	        currDiv.parent().find('#conterror').text('');
	    } 
	}
	
  
    


</script> 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/allbranches/branches_add.blade.php ENDPATH**/ ?>