
<?php $__env->startSection('page_title','UPDATE EXPENSE'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Update Expense
</div>
			     <div class="card-body">
				    <form method="POST" action="admin/update_expense" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
 <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<input type="hidden" name="id" value="<?php echo e($upadateexpense->id); ?>">
					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Date</label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control date" value="<?php echo e($upadateexpense->date); ?>" name="date" placeholder="Date" value="">
							  </div>
							  <p style="color:red;"><?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Type of expense</label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e($upadateexpense->type_of_expense); ?>" name="type_of_expense" placeholder="Type of expense" value="">
							  </div>
							   <p style="color:red;"><?php $__errorArgs = ['type_of_expense'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Amount paid</label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e($upadateexpense->amount_paid); ?>" name="amount_paid" placeholder="Enter Amount paid" value="">
							  </div>
							  <p style="color:red;"><?php $__errorArgs = ['amount_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Mode of payment <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
                        							<div class="input-group mb-3">
                        <select name="mode_of_payment" class="form-control single-select">
                        <option value="">Select payment mode</option>
                        <option value="1" <?php echo e(($upadateexpense->mode_of_payment) == '1' ? 'selected' : ''); ?>>Credit/Debit card</option> 
						<option value="2" <?php echo e(($upadateexpense->mode_of_payment) == '2' ? 'selected' : ''); ?>>Cash</option>
						<option value="3" <?php echo e(($upadateexpense->mode_of_payment) == '3' ? 'selected' : ''); ?>>Cheque</option> 
						<option value="4" <?php echo e(($upadateexpense->mode_of_payment) == '4' ? 'selected' : ''); ?>>Online payment</option> 
						<option value="5" <?php echo e(($upadateexpense->mode_of_payment) == '5' ? 'selected' : ''); ?>>Paytm</option> 
						<option value="6" <?php echo e(($upadateexpense->mode_of_payment) == '6' ? 'selected' : ''); ?>>Reward points</option> 
						<option value="7" <?php echo e(($upadateexpense->mode_of_payment) == '7' ? 'selected' : ''); ?>>PhonePe</option> 
						<option value="8" <?php echo e(($upadateexpense->mode_of_payment) == '8' ? 'selected' : ''); ?>>Gpay</option>
                        </select> 
                        </div>
                        <p style="color:red;"><?php $__errorArgs = ['mode_of_payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>
						  
						  
						  </div>
						 
  
						    <div class="form-group row">
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Recipient name</label>
					  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e($upadateexpense->recipient_name); ?>" name="recipient_name" placeholder="Enter Recipient name" value="">
							  </div>
							   <p style="color:red;"><?php $__errorArgs = ['recipient_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						    <label for="basic-input" class="col-sm-2 col-form-label">Description</label>
					  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
									<!--<input class="result form-control" type="text" name="follow_date" id="" placeholder="Date">-->
									<textarea class="form-control" name="description" id="" placeholder="Description"><?php echo e($upadateexpense->description); ?></textarea>
							  </div>
							  <p style="color:red;"><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  </div>
						  
						  
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/update_expense.blade.php ENDPATH**/ ?>