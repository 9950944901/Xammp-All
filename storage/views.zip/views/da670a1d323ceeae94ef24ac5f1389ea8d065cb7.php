
<?php $__env->startSection('page_title','Add Generate bill'); ?>
<?php $__env->startSection('contant'); ?>
<style>
    .form_control{
    width: 80px;
    height: 39px;
    border-radius: 6px;
    border: 1px solid #ced4da;
    outline:none;
    }
    /*  .form_control:focus{*/
    /*width: 43px;*/
    /*height: 39px;*/
    /*border-radius: 6px;*/
    /*border: 1px solid #ced4da;*/
    /*outline:none;*/
    /*}*/
    .inr_first{
    width: 70px;
    height: 39px;
    border-radius: 6px;
    border: 1px solid #ced4da; 
    outline:none;
    }
    /*   .inr_first:focus{*/
    /*width: 43px;*/
    /*height: 39px;*/
    /*border-radius: 6px;*/
    /*border: 1px solid #ced4da; */
    /*outline:none;*/
    /*}*/
    .form_control_time{
      border: 1px solid #ced4da;
    height: 36px;
    cursor: pointer;
    }
    .form_control_time:focus{
          outline:none;
    }
    
.quantiry_change{
    width:80px;
    height:39px;
}

td#select_row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0px;
    margin-top: 3px;
    border: none !important;
}

.btn-remove-customer i.fa.fa-minus {
    padding: 8px 9px;
    background: #f50a0a;
    margin-left: 7px;
    color: #fff !important;
}
</style>

<div class="page-wrapper">
	<div class="page-content">
		<div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase">Generate bill</div>
			     <div class="card-body">
				    <form method="POSt" action="createbill" class="form-horizontal" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                         <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Date of billing <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="date" class="form-control" value="<?php echo e(old('date_of_billing')); ?>" name="date_of_billing" placeholder="Date" value="" required>
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['date_of_billing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Client name<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('client_name')); ?>" name="client_name" placeholder="Client name" value="" required>
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Contact number <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e(old('number')); ?>" name="number" placeholder="Contact number" value="" required>
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Time of billing  <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="time" class="form-control" value="<?php echo e(old('time_of_billing')); ?>" name="time_of_billing" placeholder="Time of billing " value="" required>
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['time_of_billing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Service For  <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
                        <div class="input-group mb-3">
                        <select name="service_for" class="form-control single-select">
                        <option value="">--Select--</option>
                        <option value="men">Men</option> 
						<option value="women">Women</option>
                        </select> 
                        </div>
                        <p style="color:red;"><?php $__errorArgs = ['service_for'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>
						</div>
						  
						 <div class="col-lg-12">
						     <div class="table-responsive">
								<table id="myTable" class="table table-bordered">
									<thead>
										<tr>
											<th style="width:20%" colspan="2">Service/Product/Package/</th>
											<th style="width:5%">Qty</th>
											<th style="width:15%">Discount</th>
											<th style="width:15%">Service provider</th>
											<th style="width:15%">Start &amp; end time</th>
											<th style="width:15%">Price</th>
										</tr>
									</thead>
									<tbody>
										
										<tr id="TextBoxContainer" class="TextBoxContainer">
										     <input type="hidden" value="0" class="single_total">
											<td class="sno text-center" style="vertical-align:middle;"><span class="fa fa-ellipsis-v"></span></td>
											<td >
												<table class="inner-table-space">
													<tbody><tr>
														<td width="50%" style="vertical-align: top;">
															<input type="text" class="form-control ser_cat ui-autocomplete-input service_category" name="category[]" placeholder="Category" value="" autocomplete="off">
														
														</td>
														<td width="50%" style="vertical-align: top;">
														     <select class="form-control v_unit vu servicechange" name="service[]">
														         <option value="">select</option>
														         <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															        <option value="<?php echo e($value->id); ?>"><?php echo e($value->ser_name); ?></option>
															     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												            </select>
														</td>
														<input type="hidden" class="actual_price" name="actual_price[]" value="">
													</tr>
												</tbody></table>
    															</td>
										
											<td>
											    <input type="number" class="qt form-control sal quantity uprcommon" id="quantity" name="quantity[]" value="0" min='0' required></td>
											<td>
												<table class="inner-table-space">
													<tbody><tr>
														<td>
														    <input type="number" class="form_control discount uprcommon" value="0" id="discount" name="discount[]" min="0" >
														  
														</td>
														<td>
															<select class="disc_row_type inr_first discounttype uprcommon" name="discount_type[]" id="discount_type">
															    <option value="1" selected="">INR</option>
																<option value="0">%</option>
															</select>
														</td>
													</tr>
												</tbody></table>
											</td>
											
											<td class="spr_row"> 
    													<table><tbody><tr>
    														<td width="100%" id="select_row" class="customer_records">
    															<select name="service_provider[]" data-validation="required" class="form-control staff " required="required">
    																<option value="">Service provider</option>
    																<?php $__currentLoopData = $serviceproviders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceprovider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    																    <option value="<?php echo e($serviceprovider->name); ?>"><?php echo e($serviceprovider->name); ?></option>
    																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    															</select>
    													
    														</td>
    														
    														
    														</tr>
    														<td class="customer_records_dynamic"></td>

    													</tbody>
    													</table>
    					
    													
    										</td>
											
											<td>
												<table>
													<tbody>
													    <tr>
														<td width="50%">
														  <input type="time" id="start_time" class="form_control_time" name="start_time[]">
														    <span>to</span>
														      <input type="time" id="end_time" class="form_control_time" name="end_time[]">
														   
														</td>
													</tr>
													
													
												</tbody></table>														
											</td>
												<td>
												<input type="number" class="pr form-control price positivenumber decimalnumber servicepriceafterdiscount"  step="0.01" name="price[]" id="price" placeholder="9800.00" value="0" min="0"> 
											
											</td></tr>
										
										<tr id="addBefore">
											<td colspan="7"><button type="button" id="btnAdd" class="btn btn-success pull-right"><i class="fa fa-plus" aria-hidden="true"></i>Add service / product / package</button></td>
										</tr>
									
									
									</tbody>
								</table>
							</div>
		
    								<div class="table-responsive responsive_tbl">
    									<table class="table table-bordered">
    									
    										<tbody>					
    										
    										<tr>
    											<td class="total" colspan="6">Subtotal</td>
    											<td>
    											    <div id="sum" class="subtotal" style="display: inline;">INR 0.00</div>
    											<!--<input type="hidden" class="subtotal" id="sum2" value="0" name="subtotal"></td>-->
    										</tr>
    										<tr>
    											<td class="total" colspan="6">Coupon</td>
    											<td><input type="text" id="cc" value="" name="coupon" class="key form-control ui-autocomplete-input" autocomplete="off">
    											
    											</td>
    										</tr>
    									
    											<td class="total" colspan="5">Taxes</td>
    											<td colspan="2"><select name="tax" class="gst_tax taxcommon taxvalue" id="tax" data-validation="required" class="form-control">
    												<option value="">Select Taxes</option>
    												   	<?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														    <option value="<?php echo e($tax->tax); ?>"><?php echo e($tax->tax); ?> %</option>
													    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    											</select></td>
    										</tr>
    										<tr>
    											<td class="total" id="tot" colspan="6">Total</td>
    											<td><input type="text" id="total" class="form-control total" name="total" placeholder="Total Amount" value="0" readonly=""></td>
    										</tr>
    										<tr>
    											<td class="total" colspan="5">Referral Code (Optional)</td>
    											<td colspan="2"><input type="text" id="referral_code" class="form-control" name="referral_code" placeholder="XXXXXXXX" value=""></td>
    										</tr>
    										<tr>
    											<td class="total" colspan="6">Give reward point</td>
    											<td>
    												<label><input type="radio" name="givepoint" value="1" checked=""> Yes</label>&nbsp;&nbsp;&nbsp;
    												<label><input type="radio" name="givepoint" value="0"> No</label>
    											</td>
    										</tr>
    										<tr>
    											<td class="total" colspan="6">Advance received</td>
    											<td>
    												<input type="text" name="adv" class="key form-control" id="adv" placeholder="0" value="" readonly="">
    											</td>
    										</tr>
    										<tr>
    											<td class="total" colspan="6">Amount payable</td>
    											<td id="pend" class="amountpayable" value="">0</td>
    										</tr>
    										<tr class="payment_method_TextBoxContainer" id="payment_method_TextBoxContainer">
    											<td class="total" colspan="5">Amount paid <br>
    											<!--<span class="text-danger" id="red">*Reward points:- 10 points = 1.00 INR.</span>-->
    											</td>
    											<td colspan="2" class="spr_row_payment">
    												    <table class="inner-table-space pay_methods" style="width:100%;" id="pay_methods">
    													<tbody><tr>
    														<td width="280"><input type="text" name="advance_txn_id" class="key form-control transid" id="transctionid" value="" placeholder="TXN ID"></td>
    														<td><input type="number" name="advance_amount" step="0.01" class="key form_control paid paidcommon paidamount" id="paid" value="0" min="0"></td>
    														<td><select name="advance_type" data-validation="required" class="form_control">
    															<!--<option value="">--Select--</option>-->
    															<?php $data = App\Models\method::where('status',1)->get(); ?>
    															
    															<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																    <option value="<?php echo e($list->payment_method); ?>"><?php echo e($list->payment_method); ?></option> 
															    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    														</select></td>
    														<td id="plus_button_payment" width="5%">
    															<span class="input-group-btn">
    															
    															</span>
    														</td>
    													</tr>
    												</tbody></table>
    											 
    										</td>
    										</tr>
    										<tr>
    											<input type="hidden" class="remaining_service_worth" value="0">
    											<input type="hidden" class="used_service_worth" name="used_service_worth" value="">
    											<td class="total" colspan="6">Amount due/credit</td>
    											<td id="due" class="gtotal">0</td>
    											<input type="hidden" id="invoice_wallet_amount gtotal" name="gtotal" value="0">
    										</tr>
    										<tr>
    											<td colspan="7"><textarea name="description" class="form-control no-resize" rows="5" placeholder="Write notes about billing here..." id="textArea"></textarea></td>
    										</tr>
    									
    									</tbody>
    								</table>		
    							</div>
    						</div>
						 
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>

<script>
    
    
  $('.extra-fields-customer').click(function() {
  $('.customer_records').clone().appendTo('.customer_records_dynamic');
  $('.customer_records_dynamic .customer_records').addClass('single remove');
  $('.single .extra-fields-customer').remove();
  $('.single').append('<a href="#" class="remove-field btn-remove-customer"><i class="fa fa-minus" aria-hidden="true"></i></a>');
  $('.customer_records_dynamic > .single').attr("class", "remove form-control");

  $('.customer_records_dynamic input').each(function() {
    var count = 0;
    var fieldname = $(this).attr("name");
    $(this).attr('name', fieldname + count);
    count++;
  });

});

$(document).on('click', '.remove-field', function(e) {
  $(this).parent('.remove').remove();
  e.preventDefault();
});
</script>


<script>
$("#btnAdd").bind("click", function() {
		var clonetr = $("#TextBoxContainer").clone().addClass('TextBoxContainer');
		clonetr.removeAttr('id');
		clonetr.find("table.add_row").remove();
		clonetr.find('.sno').html('<span class="fa fa-trash-o" style="color:red;" onclick="$(this).parent().parent().remove();"></span>');
		clonetr.find('input').val('');
		clonetr.find('.staff option[value=""]').prop('selected',true);
		$("#addBefore").before(clonetr);
		autocomplete_serr();
		$('.TextBoxContainer').last().children().find('.qt').removeAttr('readonly');
		$('.TextBoxContainer').last().children().find('.package_service_quantity').remove();
		$('.TextBoxContainer').last().children().find('.package_service_inv').remove();
		change_event();
	});
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/billing/addbill.blade.php ENDPATH**/ ?>