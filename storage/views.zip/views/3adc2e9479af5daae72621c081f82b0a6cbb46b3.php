<?php echo e($slot); ?>

<?php /**PATH /home/qwudvcjf8yxq/public_html/gst_salon/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>