
<?php $__env->startSection('page_title','ADD ATTENDANCE'); ?>
<?php $__env->startSection('contant'); ?>
<style>
    .ckeck_schudule_form button {
    color: #fff !important;
}

.panel-heading {
    position: relative;
    padding: 12px 15px;
    border: 0;
    background-color: #f2f2f2;
    border-radius: 4px;
    margin-top: 10px;
    margin-bottom: 9px;
}
.main-container {
    background: #fff !important;
    padding-left: 8px;
    padding-right: 8px;
    margin-top: 18px;
    padding-bottom: 100px;
}

.form_fullservice button {
    margin: 0 3px !important;
    font-size: 14px !important;
}

.end_time{
        background-color: #ffffff;
}

.minus{
color: white;
    background-color: red;
    float: right;
    position: relative;
    left: 51px;
    bottom: 38px;
    font-size: 19px;
    padding: 12px 8px;
}


</style>

<div class="container-fluid">
<div class="dashboard-wrapper">
	
	<!-- Main container starts -->
	<div class="main-container">
		<form action="" method="post" id="main-form">
		<!-- Row starts -->
		<div class="row gutter">
			
			<div class="col-lg-10 col-md-12 col-sm-12 col-xs-12">
				
					<div class="panel">
						<div class="panel-heading">
							<h4>Create appointment</h4>
						</div>
						<div class="panel-body">
						    <div id="member_ship_message"></div>
							<div class="row">
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 mt-2">
								<div class="form-group">
									<label for="client">Client name <span class="text-danger">*</span></label>
									<input type="text" class="client form-control client_name ui-autocomplete-input" id="client" name="client" placeholder="Autocomplete (Phone)" value="" required="" autocomplete="off">
									
									
								</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 mt-2">
								<div class="form-group">
									<label for="cont">Contact number <span class="text-danger">*</span></label>
									<input type="text" class="form-control client ui-autocomplete-input" value="" onblur="check();contact_no_length($(this), this.value);" id="cont" name="cont" placeholder="Client contact" onkeyup="this.value = this.value.replace(/[^0-9\.]/g,'');" maxlength="10" required="" autocomplete="off">
									<span style="color:red" id="client-status"></span>
									<span style="color:red" id="digit_error"></span>
								</div>
							</div>	
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 mt-2">
								<div class="form-group">
																		<label for="doa">Appointment is on <span class="text-danger">*</span></label>
									<input type="text" class="form-control dat min_present_date" id="date" onblur="$('.staff').val('')" onchange="dateAvailability(this.value)" value="2022-07-15" name="doa" required="" readonly="">
									<span class="text-danger" id="dateerror"></span>
								</div>
							</div>
							
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 mt-2">
								<div class="form-group">
																		<label for="time">Time of appointment <span class="text-danger">*</span></label>
									<input type="text" onchange="checkappTime('time',this.value,'apptime')" class="form-control slot dat time" name="time" value="02:18 PM" id="time" required="" readonly="">
								
									<span id="apptime" class="text-danger"></span>
								</div>
							</div>
							<div class="clearfix"></div>
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 mt-2">
								<div class="form-group">
									<label for="role">Source of appointment</label>
									<select class="form-control" name="role">
																							<option value="2">On-call</option>
																									<option value="1">Walkin</option>
																									<option value="3">Website</option>
																					</select>
									</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 mt-2">
								<div class="form-group">
									<label for="points">Service For</label>
										<select required="" name="service_for" id="service_for" class="form-control">
										    <option value="0">--Select--</option>
										    <option value="1">Men</option>
										    <option value="2">Women</option>
										</select>
								</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 mt-2">
								<div class="form-group ckeck_schudule_form">
									<label for="">&nbsp &nbsp</label>
									<button type="button" onclick="todaySchedule($('#date').val())" class="btn btn-warning form-control"><i class="fa fa-calendar" aria-hidden="true"></i>Check schedule</button>
								</div>
							</div>
							<div class="clearfix"></div>
							<div class="col-lg-12">
								<div class="table-responsive">
									<table id="catTable" class="table table-bordered">
										
										<tbody>
<div class="table-responsive table_add_stock_margin">
								<table id="myTable" class="table table-bordered">
									<thead>
										<tr>
											<th style="width:34%" colspan="2">Select service</th>
											<th style="width:3%">Discount</th>
											<th style="width:15%">Service provider</th>
											<th style="width:15%">Start & end time</th>
											<th style="width:15%">Price</th>
										</tr>
									</thead>
									<tbody>
										
										<tr id="TextBoxContainer" class="TextBoxContainer">
											<td class="sno text-center" style="vertical-align:middle;"><span class="fa fa-ellipsis-v" aria-hidden="true"></span></td>
											<td>
    																<table class="inner-table-space">
																		<tbody><tr>
																			<td width="40%" style="vertical-align: top;">
																				<input type="text" class="form-control ser_cat ui-autocomplete-input" name="category_id" placeholder="Category" value="" autocomplete="off">
																			
																			</td>
																			<td width="40%" style="vertical-align: top;">
																			       
			    																<input type="number" class="ser form-control slot ui-autocomplete-input" name="service_id" value="" placeholder="Service (Autocomplete)" required="required" autocomplete="off">
			    																
			    															</td>
			    														
			    														</tr>
			    													</tbody></table>
    															</td>
										<td width="10%">
																<table class="inner-table-space">
																	<tbody><tr>
																		<td width="50%">
																			<input type="number" name="disc_row[]" class="form-control disc_row positivenumber decimalnumber singleservicediscount" step="0.1" value="0" min="0">
																		</td>
																		<td width="50%">
																			<select class="form-control disc_row_type" name="disc_row_type[]" id="disc_row_type">
																				<option value="0">%</option>
																				<option value="1" selected="">INR</option>
																			</select>
																		</td>
																	</tr>
																</tbody></table>
															</td>
										
											<td>
												<table class="inner-table-space">
													<tbody><tr>
													<td class="spr_row"> 
    													<table><tbody><tr>
    														<td id="select_row" class="customer_records">
    															<select name="staffid0[]" data-validation="required" class="form-control staff " required="required">
    																<option value="">Service provider</option>          
    															
    															</select>
    														<!--	<table>-->
    														<!--	    <tr>-->
    														<!--	        <td id="plus_button" width="5%">-->
    														<!--	<span class="input-group-btn">-->
    														<!--		<button style="" id="btnAddbtn" class="btn btn-add btn-plus btn-success btn-add add_spr_row extra-fields-customer" type="button">-->
    														<!--			<i class="fa fa-plus" aria-hidden="true"></i>-->
    														<!--		</button>-->
    														<!--	</span>-->
    														<!--</td>-->
    														<!--	    </tr>-->
    														<!--	</table>-->
    														</td>
    														<td id="plus_button" width="5%">
    															<span class="input-group-btn">
    																<button style="" id="btnAddbtn" class="btn btn-add btn-plus btn-success btn-add add_spr_row extra-fields-customer" type="button">
    																	<i class="fa fa-plus" aria-hidden="true"></i>
    																</button>
    															</span>
    														</td>
    														
    														</tr>
    															  <tr><td class="customer_records_dynamic"></td>

    													</tr></tbody>
    													</table>
    											
    										</td>
													</tr>
												</tbody></table>
											</td>
											<td>
												<table>
												<td>
																<table class="inner-table-space">
																	<tbody><tr>
																		<td width="50%">
																			<input type="text" class="form-control start_time time" value="" placeholder="Start time" name="start_time[]" onchange="servicestarttime(this.value, $(this))" readonly="">
																		</td>
																		<td width="50%">
																			<input type="text" class="form-control end_time" name="end_time[]" value="" placeholder="End time" readonly="">
																		</td>
																	</tr>
																</tbody></table>
																
																
															</td></table>	
															
															
															
											</td>
												<td>
												<input type="number" class="pr form-control price positivenumber decimalnumber servicepriceafterdiscount sp_onchange" step="0.01" name="price" id="price" placeholder="9800.00" value="0" min="0"> 
											
											</td>
											</tr>
										
										<tr id="addBefore">
											<td colspan="8"><button type="button" id="btnAdd" class="btn btn-success pull-right"><i class="fa fa-plus" aria-hidden="true"></i>Add product</button></td>
										</tr>
										
									
									
									
									</tbody>
								</table>
							</div>

											<tr>
												<td class="total" colspan="4">Discount</td>
												<td width="40%">
												<input type="number" step="0.01" class="key1 form-control" name="dis" id="total_disc" value="0" placeholder="Discount Amount" min="0"></td>
												<td width="60%">
													<select class="form-control total_disc_row_type" name="total_disc_row_type" id="disc_row_type">
														<option value="0">%</option>
														<option value="1">INR</option>
													</select>
												</td>
											</tr>
											<!--<tr>
												<td class="total" colspan="6">Discount(in %)</td>
												<td>
												<input type="text" value="0" name="discount2" step="0.01" class="key form-control disc" id="disc2" placeholder="0"></td>
											</tr>-->
											<tr>
												<td class="total" colspan="4">Taxes</td>
												<td colspan="2"><select name="tax" id="tax" data-validation="required" class="form-control">
													<option value="0,0,3">Select Taxes</option>
																										<optgroup label="Inclusive Taxes">
																													<option value="2,18,0">Gst on Products(18)</option>
																													<option value="1,18,0">Gst on Service(18)</option>
																											</optgroup>
													<optgroup label="Exclusive Taxes">
																													<option value="2,18,1">Gst on Products(18)</option>
																													<option value="1,18,1">Gst on Service(18)</option>
																											</optgroup>
													              
												</select></td>
											</tr>
											<tr>
												<td class="total" id="tot" colspan="5">Total</td>
												<td><input type="text" id="total" class="form-control" name="total" placeholder="Total Amount" value="0" readonly=""></td>
											</tr>
											<tr id="TextBoxContainerPayment" class="TextBoxContainerPayment">
												<td class="total" colspan="4">Advance given <br>
												<span class="text-danger">*Reward points:- 10 points = 1.00 INR</span>
												</td>
												<td colspan="3" class="spr_row_payment">
													<table class="inner-table-space" id="pay_methods">
																													<tbody><tr>
																<td width="280"><input type="text" name="transid[]" class="key form-control transid" id="transctionid" value="" placeholder="TXN ID"></td>
																<td><input type="number" name="adv[]" step="0.01" class="key form-control adv" id="adv" value="0" min="0" readonly=""></td>
																<td><select name="method[]" data-validation="required" class="form-control act" onchange="paymode(this.value,$(this))">
																	<!--<option value="">--Select--</option>-->
																																			<option value="1">Cash</option> 
																																			<option value="3">Solasta Swipe</option> 
																																			<option value="4">Solasta UPI</option> 
																																			<option value="5">A H swipe</option> 
																																			<option value="6">A H UPI</option> 
																																			<option value="7">E-wallet</option> 
																																			<option value="9">Reward points</option> 
																																			<option value="10">Direct</option> 
																																			<option value="11">Bank Transfer </option> 
																																			<option value="12">Riva Upi</option> 
																																			<option value="13">Riva swipe</option> 
																	  
																</select></td>
																<td id="plus_button_payment" width="5%">
																	<span class="input-group-btn">
																		<button style="" class="btn btn-add btn-plus btn-success btn-add add_spr_row_payment" type="button">
																			<span class="glyphicon-plus"></span>
																		</button>
																	</span>
																</td>
															</tr>
														 
													</tbody></table>
												<!--<input type="text" class="form-control" style="margin-top : 5px;" name="detail" id="detail" placeholder="Enter Card 4 digits or Cheque No.">
												</td>-->
											</td></tr>
											<tr>
												<td class="total" colspan="5">Pending dues</td>
												<td id="pend">0.00</td>
											</tr>
											<tr>
												<td class="total" colspan="5">Appointment Status</td>
																									<td><select name="status" data-validation="required" class="form-control">
													<option value="Pending">Pending</option>
													<option value="Billed">Billed</option>
															 
												</select></td>
																						</tr>
											
											<tr>
												<td colspan="8"><textarea name="notes" class="form-control no-resize" rows="5" placeholder="Write Notes About Appointment here..." id="textArea"></textarea></td>
											
											</tr>
										</tbody>
									</table>
								</div>
					
							
							
							
							
							<div class="clearfix"></div>
							<div class="col-sm-12 form_fullservice">
							    <input type="hidden" id="mem_service" value="">
    						    <input type="hidden" id="mem_product" value="">
    						    <input type="hidden" id="mem_package" value="">
    						    <input type="hidden" id="has_membership" value="0">
    						    <input type="hidden" id="mem_condition" value="0">
    						    <input type="hidden" id="mem_reward_point" value="0">
    						    <input type="hidden" id="mem_bill_amount" value="0">
    						    <input type="hidden" name="membership_appilied" id="membership_appilied" value="0">
    						    <input type="hidden" name="membership_id" id="membership_id" value="0">
    						    <input type="hidden" name="membership_reward_boost" id="membership_reward_boost" value="1">
																<button type="button" name="" class="btn mr-left-5 btn-danger pull-right" onclick="location.reload();">Reset</button>
								<button type="submit" name="submit" class="btn btn-success pull-right mr-2 ml-2"><i class="fa fa-calendar-check-o" aria-hidden="true"></i>Create appointments</button>
								
							</div>
							</div>
						</div>
					</div>
				
			</div>
			<div class="col-lg-2 col-xs-12 grey-box">
				<div class="row">
					<div class="col-lg-12">
						<div class="panel">
						<div class="panel-heading">
							<h4><i class="fa fa-repeat mr-left-0 text-warning fa-spin" aria-hidden="true"></i>Client 360° view</h4>
						</div>
						<div class="client-view">
							<div class="client-view-content table-responsive">
								<div id="customer_type">
									
								</div>
								
								<table width="100%" class="table table-striped">
									<tbody><tr>
										<td>Branch:</td>
										<td id="branch_name">----<br></td>
									</tr>
									<tr>
										<td>Last visit on:</td>
										<td id="last_visit">----<br></td>
									</tr>
									<tr>
										<td>Total visits:</td>
										<td id="total_visit">0</td>
									</tr>
									<tr>
										<td>Total spendings:</td>
										<td id="total_spending">0</td>
									</tr>
									<tr>
										<td>Membership:</td>
										<td id="membership">----</td>
									</tr>
									<tr>
										<td>Active packages:</td>
										<td id="active_package">----<br></td>
									</tr>
									
									<tr>
										<td>Last feedback:</td>
										<td id="last_feedback"><a href="#"><u>----</u></a></td>
									</tr>
									<tr>
										<td>My wallet	:</td>
										<td id="wallet">0</td>
										<input type="hidden" id="wallet_money" value="0">
									</tr>
									<tr>
										<td>Reward points:</td>
										<td id="earned_points">0</td>
										<input type="hidden" id="reward_point" value="0">
									</tr>
									
									
									<tr>
										<td>Gender:</td>
										<td id="gender">
											<select class="form-control" name="gender" id="gender">
												<option value="">--Select--</option>
												<option id="gn-1" value="1" selected="">Male</option>
												<option id="gn-2" value="2">Female</option>
											</select>
										</td>
									</tr>
									<tr>
										<td>Date of birth	:</td>
										<td id="dob"><input type="text" class="form-control dob_annv_date" name="dob" id="clientdob" value="" readonly=""></td>
									</tr>
									<tr>
										<td>Anniversary	:</td>
										<td><input type="text" class="form-control dob_annv_date" name="aniv" id="anniversary" value="" readonly=""></td>
									</tr>
									
									<tr>
										<td>Source of client:</td>
										<td>       
											<select class="form-control" name="leadsource" id="leadsource">
												<option value="">--Select--</option>
												<option value="Client refrence">Client refrence</option>
												<option value="Cold Calling">Cold Calling</option>
												<option value="Facebook">Facebook</option>
												<option value="Twitter">Twitter</option>
												<option value="Instagram">Instagram</option>
												<option value="Other Social Media">Other Social Media</option>
												<option value="Website">Website</option>
												<option value="Walk-In">Walk-In</option>
												<option value="Flex">Flex</option>
												<option value="Flyer">Flyer</option>
												<option value="Newspaper">Newspaper</option>
												<option value="SMS">SMS</option>
												<option value="Street Hoardings">Street Hoardings</option>
												<option value="Event">Event</option>
												<option value="TV/Radio">TV/Radio</option>		
											</select>
										</td>
									</tr>												
								</tbody></table>
							</div>
						</div>
					</div>
					</div>
				</div>
			</div>
		
		</div>
		<!-- Row ends -->
		</form>
		
		<div class="clearfix"></div>
		
	</div>
	
</div>
</div>


 <script>
$("#btnAdd").bind("click", function() {
		var clonetr = $("#TextBoxContainer").clone().addClass('TextBoxContainer');
		clonetr.removeAttr('id');
		clonetr.find("table.add_row").remove();
		clonetr.find('.sno').html('<span class="fa fa-trash-o" style="color:red;" onclick="$(this).parent().parent().remove();"></span>');
		clonetr.find('input').val('');
		clonetr.find('.staff option[value=""]').prop('selected',true);
		$("#addBefore").before(clonetr);
		autocomplete_serr();
		$('.TextBoxContainer').last().children().find('.qt').removeAttr('readonly');
		$('.TextBoxContainer').last().children().find('.package_service_quantity').remove();
		$('.TextBoxContainer').last().children().find('.package_service_inv').remove();
		change_event();
	});
</script> 


<script>
    
    
    $('.extra-fields-customer').click(function() {
  $('.customer_records').clone().appendTo('.customer_records_dynamic');
  $('.customer_records_dynamic .customer_records').addClass('single remove');
  $('.single .extra-fields-customer').remove();
  $('.single').append('<a href="#" class="remove-field btn-remove-customer"><i class="fa fa-minus minus" aria-hidden="true"></i></a>');
  $('.customer_records_dynamic > .single').attr("class", "remove form-control");

  $('.customer_records_dynamic input').each(function() {
    var count = 0;
    var fieldname = $(this).attr("name");
    $(this).attr('name', fieldname + count);
    count++;
  });

});

$(document).on('click', '.remove-field', function(e) {
  $(this).parent('.remove').remove();
  e.preventDefault();
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/addSoftware_appointment.blade.php ENDPATH**/ ?>