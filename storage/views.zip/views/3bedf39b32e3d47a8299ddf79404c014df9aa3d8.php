<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/qwudvcjf8yxq/public_html/gst_salon/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>