
<?php $__env->startSection('page_title','Add Generate bill'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase">Add Generate bill</div>
			     <div class="card-body">
				    <form method="POSt" action="add_expense" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
 <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Date of billing <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control date" value="<?php echo e(old('date')); ?>" name="date" placeholder="Date" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Client name<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('client_name')); ?>" name="client_name" placeholder="Client name" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Contact number <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e(old('contact_number')); ?>" name="contact_number" placeholder="Contact number" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Time of billing  <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e(old('time_of_billing')); ?>" name="time_of_billing" placeholder="Time of billing " value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['time_of_billing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Service For  <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
                        <div class="input-group mb-3">
                        <select name="service_for" class="form-control single-select">
                        <option value="">--Select--</option>
                        <option value="1">Men</option> 
						<option value="2">Women</option>
                        </select> 
                        </div>
                        <p style="color:red;"><?php $__errorArgs = ['service_for'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>
						  
						  
						  </div>
						 
  
						 
						  
						  
						 <div class="col-lg-12">
    								<div class="table-responsive responsive_tbl">
    									<table class="table table-bordered">
    										<thead>
    											<tr>
    												
    												<th colspan="2">Service / Products / Packages</th>
    												<th>Qty</th>
    												<th>Discount</th>
    												<th>Service provider</th>
    												<th>Start &amp; end time</th>
    												<th>Price</th>
    											</tr>
    										</thead>
    										<tbody>
    																		
    											<tr id="TextBoxContainer" class="TextBoxContainer">
    
    															<td style="vertical-align: middle"><span class="sno"><span class="icon-dots-three-vertical"></span></span></td>
    															<td width="95%">
    																<table class="inner-table-space">
																		<tbody><tr>
																			<td width="50%" style="vertical-align: top;">
																				<input type="text" class="form-control ser_cat ui-autocomplete-input" name="ser_cat[]" placeholder="Category" value="" autocomplete="off">
																				<input type="hidden" value="" class="ser_cat_id" name="ser_cat_id[]">
																			</td>
																			<td width="50%" style="vertical-align: top;">
			    																<input type="text" class="ser form-control slot ui-autocomplete-input" name="services[]" value="" placeholder="Service (Autocomplete)" required="required" autocomplete="off">
			    																<input type="hidden" name="service[]" value="" class="serr" required="">
			    																<input type="hidden" name="stock_id[]" value="0" class="stock_id" required="">
			    																<input type="hidden" name="durr[]" value="" class="durr">
			    																<input type="hidden" name="pa_ser[]" value="" class="pa_ser">
			    																<input type="hidden" name="item_row[]" value="">
			    															</td>
			    														</tr>
			    													</tbody></table>
    															</td>
    														
    												<td>
    												<input type="number" name="qt[]" min="0" class="positivenumber qt form-control sal slot" value="1"></td>
    												<td>
    													<table class="inner-table-space">
    														<tbody><tr>
    															<td>
    																<input type="number" value="0" name="disc_row[]" class="form-control disc_row positivenumber decimalnumber singleservicediscount" step="0.01" min="0">
    															</td>
    															<td>
    																<select class="form-control disc_row_type" name="disc_row_type[]" id="disc_row_type">
    																    <option value="1" selected="">INR</option>
    																	<option value="0">%</option>
    																</select>
    															</td>
    														</tr>
    													</tbody></table>
    												</td>
    												
    												
    												<td class="spr_row"> 
    													
    													
    													<table id="add_row"><tbody><tr>
    														<td width="95%" id="select_row">
    															<select name="staffid0[]" data-validation="required" class="form-control staff" required="required">
    																<option value="">Service provider</option>          
    															
    															</select>
    														</td>
    														<td id="plus_button" width="5%">
    															<span class="input-group-btn">
    																<button style="" class="btn btn-add btn-plus btn-success btn-add add_spr_row" type="button">
    																	<span class="glyphicon-plus"></span>
    																</button>
    															</span>
    														</td></tr>
    													</tbody>
    													</table>
    												</td>
    												<input type="hidden" name="duration[]" value="" class="duration">
    												<input type="hidden" name="ser_stime[]" value="" class="ser_stime">
    												<input type="hidden" name="ser_etime[]" value="" class="ser_etime">
    												<td>
    													<table>
    														<tbody><tr>
    															<td width="50%">
    																<input type="text" class="form-control start_time time" value="" placeholder="Start time" name="start_time[]" onchange="servicestarttime(this.value, $(this))" readonly="">
    																</td>						<td>&nbsp;to&nbsp;</td>																										       <td width="50%">
    																<input type="text" class="form-control end_time" name="end_time[]" value="" placeholder="End time" readonly="">
    															</td>
    														</tr>
    													</tbody></table>														
    												</td> 
    												<td>
    													<input type="number" class="pr form-control price positivenumber decimalnumber servicepriceafterdiscount" step="0.01" name="price[]" id="userName" placeholder="9800.00" value="" min="0"> 
    													<input type="hidden" class="prr" name="actual_price[]" value="">
    													<input type="hidden" class="rpoint" name="reward_point[]" value="">
    												</td>
    											</tr>
    										    										<tr id="addBefore">
    											<td colspan="7"><button type="button" id="btnAdd" class="btn btn-success pull-right"><i class="fa fa-plus" aria-hidden="true"></i>Add service / product / package</button></td>
    										</tr>
    										<tr>
    											<td class="total" colspan="6">Subtotal</td>
    											<td><div id="sum" style="display: inline;">INR 0.00</div>
    											<input type="hidden" id="sum2" value="0" name="subtotal"></td>
    										</tr>
    										<tr>
    											<td class="total" colspan="6">Coupon</td>
    											<td><input type="text" id="cc" value="" name="coupon" class="key form-control ui-autocomplete-input" autocomplete="off">
    												<input type="hidden" id="discount" name="discount" value="0">
    												<input type="hidden" id="discount_type" name="discount_type" value="0">
    												<input type="hidden" id="ccid" name="ccid" value="0">
    												<input type="hidden" id="cmin" name="cmin" value="0">
    												<input type="hidden" id="cmax" name="cmax" value="0">
    												<input type="hidden" id="valid" name="valid" value="0">
    												<input type="hidden" id="c_per_user_used" name="c_per_user_used" value="0">
    												<input type="hidden" id="c_per_user" name="c_per_user" value="0">
    											</td>
    										</tr>
    										<!--<tr>
    											<td class="total" colspan="5">Reward points used</td>
    											<td><input type="text" id="sum" name="subtotal" class="key form-control" readonly></td>
    										</tr>-->
    										<tr>
    											<td class="total" colspan="5">Discount</td>
    											<td>
    											<input type="number" step="0.01" min="0" class="key1 form-control" name="dis" id="total_disc" value="0" placeholder="Discount Amount"></td>
    											<td>
    												<select class="form-control total_disc_row_type" name="total_disc_row_type" id="disc_row_type">
    													<option value="1">INR</option>
    													<option value="0">%</option>
    												</select>
    											</td>
    										</tr>
    										<tr>
    											<td class="total" colspan="5">Taxes</td>
    											<td colspan="2"><select name="tax" id="tax" data-validation="required" class="form-control">
    												<option value="0,0,3">Select Taxes</option>
    												<optgroup label="Inclusive Taxes">
    													    														<option value="2,18,0">Gst on Products(18)</option>
    													    														<option value="1,18,0">Gst on Service(18)</option>
    													    												</optgroup>
    												<optgroup label="Exclusive Taxes">
    													    														<option value="2,18,1">Gst on Products(18)</option>
    													    														<option value="1,18,1">Gst on Service(18)</option>
    													    												</optgroup>              
    											</select></td>
    										</tr>
    										<tr>
    											<td class="total" id="tot" colspan="6">Total</td>
    											<td><input type="text" id="total" class="form-control" name="total" placeholder="Total Amount" value="0" readonly=""></td>
    										</tr>
    										<tr>
    											<td class="total" colspan="5">Referral Code (Optional)</td>
    											<td colspan="2"><input type="text" id="referral_code" class="form-control" name="referral_code" placeholder="XXXXXXXX" value=""></td>
    										</tr>
    										<tr>
    											<td class="total" colspan="6">Give reward point</td>
    											<td>
    												<label><input type="radio" name="givepoint" value="1" checked=""> Yes</label>&nbsp;&nbsp;&nbsp;
    												<label><input type="radio" name="givepoint" value="0"> No</label>
    											</td>
    										</tr>
    										<tr>
    											<td class="total" colspan="6">Advance received</td>
    											<td>
    												<input type="text" name="adv" class="key form-control" id="adv" placeholder="0" value="" readonly="">
    											</td>
    										</tr>
    										<tr>
    											<td class="total" colspan="6">Amount payable</td>
    											<td id="pend">0</td>
    										</tr>
    										<tr class="payment_method_TextBoxContainer" id="payment_method_TextBoxContainer">
    											<td class="total" colspan="5">Amount paid <br><span class="text-danger" id="red">*Reward points:- 10 points = 1.00 INR.</span></td>
    											<td colspan="2" class="spr_row_payment">
    												    												   <table class="inner-table-space pay_methods" style="width:100%;" id="pay_methods">
    													<tbody><tr>
    														<td width="280"><input type="text" name="transid[]" class="key form-control transid" id="transctionid" value="" placeholder="TXN ID"></td>
    														<td><input type="number" name="paid[]" step="0.01" class="key form-control paid" id="paid" value="" min="0"></td>
    														<td><select name="method[]" data-validation="required" class="form-control act" onchange="paymode(this.value,$(this))">
    															<!--<option value="">--Select--</option>-->
    															    																<option value="1">Cash</option> 
    															    																<option value="3">Credit/Debit card</option> 
    															    																<option value="4">Cheque</option> 
    															    																<option value="5">Online payment</option> 
    															    																<option value="6">Paytm</option> 
    															    																<option value="7">E-wallet</option> 
    															    																<option value="9">Reward points</option> 
    															    																<option value="10">PhonePe</option> 
    															    																<option value="11">Gpay</option> 
    															  
    														</select></td>
    														<td id="plus_button_payment" width="5%">
    															<span class="input-group-btn">
    																<button style="" class="btn btn-add btn-plus btn-success btn-add add_spr_row_payment" type="button">
    																	<span class="glyphicon-plus"></span>
    																</button>
    															</span>
    														</td>
    													</tr>
    												</tbody></table>
    											 
    										</td>
    										</tr>
    										<tr>
    											<input type="hidden" class="remaining_service_worth" value="0">
    											<input type="hidden" class="used_service_worth" name="used_service_worth" value="">
    											<td class="total" colspan="6">Amount due/credit</td>
    											<td id="due">0</td>
    											<input type="hidden" id="invoice_wallet_amount" name="invoice_wallet_amount" value="0">
    										</tr>
    										<tr>
    											<td colspan="7"><textarea name="notes" class="form-control no-resize" rows="5" placeholder="Write notes about billing here..." id="textArea"></textarea></td>
    										</tr>
    										<!--<tr>
    											<td class="total" colspan="5">Return</td>
    											<td><input type="number" class="form-control" name="chnge" id="chng" value="0"></td>
    										</tr>-->
    										
    									</tbody>
    								</table>		
    							</div>
    						</div>
						   
						  
						  
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtsdigital/p4.gts.digital/Gts_salon/resources/views/admin/billing/addbill.blade.php ENDPATH**/ ?>