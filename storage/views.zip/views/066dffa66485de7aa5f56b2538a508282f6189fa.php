
<?php $__env->startSection('page_title','ADD EMPLOYEES SALARY'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Add Employees salary
</div>
			     <div class="card-body">
				    <form method="POSt" action="employee_salary_post" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
 <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Date <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="date" class="form-control" value="<?php echo e(old('date')); ?>" name="date" placeholder="Date" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						    <label for="basic-input" class="col-sm-2 col-form-label">Employee type <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
                            							<div class="input-group mb-3">
                            <select name="employee_type" class="form-control single-select">
                            <option value="">--Select payment mode--</option>
                            <option value="Service provider">Service provider</option> 
    						<option value="Staff">Staff</option>
                            </select> 
                            </div>
                            <p style="color:red;"><?php $__errorArgs = ['employee_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                            </div>
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Employee name <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
								<input type="text" class="form-control" value="<?php echo e(old('employee_name')); ?>" name="employee_name" placeholder="Type of expense" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['employee_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Salary type <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
                        							<div class="input-group mb-3">
                        <select name="salary_type" class="form-control single-select">
                        <option value="">Salary</option>
                        <option value="Advance">Advance</option> 
						<option value="Advance">Advance</option>
						<option value="Bonus">Bonus</option> 
                        </select> 
                        </div>
                        <p style="color:red;"><?php $__errorArgs = ['salary_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>
						  
						  
						  </div>
						 
  
						    <div class="form-group row">
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Amount</label>
					  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e(old('amount')); ?>" name="amount" placeholder="Enter Amount" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						    <label for="basic-input" class="col-sm-2 col-form-label">Comments <span style="color:red;">*</span></label>
					  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
									<!--<input class="result form-control" type="text" name="follow_date" id="" placeholder="Date">-->
									<textarea class="form-control" name="comments" id="" placeholder="Comments"></textarea>
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['comments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  </div>
						  
						   
						  
						  
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtsdigital/p4.gts.digital/Gts_salon/resources/views/admin/employeesalary/add.blade.php ENDPATH**/ ?>