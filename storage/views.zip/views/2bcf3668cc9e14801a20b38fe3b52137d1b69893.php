

<!doctype html>
<html lang="en">

<head>
<!-- Required meta tags -->
<meta charset="utf-8">

<!--favicon-->
<link rel="icon" href="<?php echo e(URL::asset('assets/images/logo-icon.png')); ?>" type="image/png" />
<!--plugins-->

<link href="<?php echo e(URL::asset('assets/plugins/vectormap/jquery-jvectormap-2.0.2.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(URL::asset('assets/plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('assets/plugins/metismenu/css/metisMenu.min.css')); ?>" rel="stylesheet" />
<!-- loader-->
<link href="<?php echo e(URL::asset('assets/css/pace.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('assets/css/style.css')); ?>" rel="stylesheet" />
<script src="<?php echo e(URL::asset('assets/js/pace.min.js')); ?>"></script>
<!-- Bootstrap CSS -->
<link href="<?php echo e(URL::asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&amp;display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/da3af72861.js" crossorigin="anonymous"></script>
<link href="<?php echo e(URL::asset('assets/css/app.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('assets/css/icons.css')); ?>" rel="stylesheet">
<!-- Theme Style CSS -->
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/dark-theme.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/semi-dark.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/header-colors.css')); ?>" />
<link href="<?php echo e(URL::asset('assets/fancybox/css/jquery.fancybox.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(URL::asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('assets/plugins/select2/css/select2-bootstrap4.css')); ?>" rel="stylesheet" />
<script src="<?php echo e(URL::asset('assets/ajax/jquery.min.js')); ?>"></script>
<link href="<?php echo e(URL::asset('assets/css/bootstrap-toggle.min.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(URL::asset('assets/plugins/datatable/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css">

<link href="<?php echo e(URL::asset('assets/Promo_panel/assets/plugins/switchery/css/switchery.min.css')); ?>" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="<?php echo e(URL::asset('assets/plugins/datetimepicker/css/classic.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(URL::asset('assets/plugins/datetimepicker/css/classic.time.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(URL::asset('assets/plugins/datetimepicker/css/classic.date.css')); ?>" rel="stylesheet" />
	<link rel="stylesheet" href="<?php echo e(URL::asset('assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.min.css')); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="<?php echo e(URL::asset('assets/Promo_panel/assets/plugins/switchery/js/switchery.min.js')); ?>"></script>

<title><?php echo $__env->yieldContent('page_title'); ?></title>


<style>

/*.Dashboard li{*/
/*      margin-left: 75px;*/
/*}*/

.head_navbar .navbar_easy_margin li.nav-item {
    padding: 0 26px !important;
}

/*.salon_logo_css {*/
/*    width: 217px;*/
/*    height: 58px;*/
    /* border-radius: 50%; */
/*    border: 0 solid #e5e5e5;*/
/*    padding: 0;*/
/*    border-radius:0px !important;*/
/*}*/
</style>
</head>



<body>
<!--wrapper-->
<div class="wrapper  form_input_custom">
  
  <!--<div class="easy_salon_main">-->
  <!--    <p>AH salon</p>-->
  <!--</div>-->
  <div class="second_header_main" >
      <a class="navbar-brand" style="float:left;" href="#"><img src="<?php echo e(URL::asset('assets/images/ahlogoa.jpg')); ?>" class="user-img salon_logo_css" alt="user avatar"> 
      AH Salon
      </a>
         <div class="" style="float:right;"> 
           <div class="user-box dropdown">
                <a class="d-flex align-items-center nav-link dropdown-toggle dropdown-toggle-nocaret has-arrow" href="javascript" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <img src="<?php echo e(URL::asset('assets/images/logo-icon.png')); ?>" class="user-img" alt="user avatar">
                    <div class="user-info ps-3">
                    <p class="user-name mb-0">GTS</p>
                    <p class="designattion mb-0">Web Designer</p>
                    </div>
                </a>
                <ul class="dropdown-menu profile_log_main dropdown-menu-end">
                <li><a class="dropdown-item" href="javascript"><i class="bx bx-user"></i><span>Profile</span></a>
                </li>
                <li><a class="dropdown-item" href="javascript"><i class="bx bx-cog"></i><span>Settings</span></a>
                </li>
                
                <li><a class="dropdown-item" href="logout" ><i class="bx bx-log-out-circle"></i><span>Logout</span></a>
                </li>
                
                </ul>
            </div>
        </div>
  </div>
  
  <div class="head_navbar">
 <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
   
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <!--<ul class="navbar-nav me-auto mb-2 mb-lg-0">-->
      <!--  <li class="nav-item">-->
      <!--    <a class="nav-link active" aria-current="page" href="index">Dashboard</a>-->
      <!--  </li>-->
      <!--  <li class="nav-item">-->
      <!--    <a class="nav-link" href="view_enquiry">Enquiry</a>-->
      <!--  </li>-->
      <!--  <li class="nav-item">-->
      <!--    <a class="nav-link" href="view_client">Clients</a>-->
      <!--  </li>-->
        
      <!--  <li class="nav-item">-->
      <!--    <a class="nav-link" href="add_feedback">Feedback</a>-->
      <!--  </li>-->
      <!--  <li class="nav-item dropdown">-->
      <!--    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">-->
      <!--      Products-->
      <!--    </a>-->
      <!--    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">-->
      <!--      <li><a class="dropdown-item" href="view_vender">Vendor</a></li>-->
      <!--      <li><a class="dropdown-item" href="view_product">Product Used</a></li>-->
      <!--      <li><a class="dropdown-item" href="add_stock">Add Stock</a></li>-->
      <!--    </ul>-->
      <!--  </li>-->
      <!--  <li class="nav-item">-->
      <!--    <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>-->
      <!--  </li>-->
      <!--</ul>-->
      
      <ul class="navbar-nav navbar_easy_margin me-auto mb-2 mb-lg-0 Dashboard">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index"><p class="text-center"><i class="fa fa-tachometer" aria-hidden="true"></i></p>Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="view_enquiry"><p class="text-center"><i class="fa fa-user-plus" aria-hidden="true"></i></p>Enquiry</a>
        </li>
        
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <p class="text-center"><i class="fa fa-sticky-note" aria-hidden="true"></i></p>
            Appointments
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
            <li><a class="dropdown-item" href="Software-appointment">Software appointment</a></li>
            <li><a class="dropdown-item" href="Web-appointment">Web appointment </a></li>
          </ul>
        </li>
        
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <p class="text-center"><i class="fa fa-sticky-note" aria-hidden="true"></i></p>
            Billing
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
            <li><a class="dropdown-item" href="billing-form">Add Bill</a></li>
            <li><a class="dropdown-item" href="wallet-form">Add Wallet</a></li>
          </ul>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="view_client"><p class="text-center"><i class="fa fa-reddit-alien" aria-hidden="true"></i></p>Clients</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="add_feedback"><p class="text-center"><i class="fa fa-commenting" aria-hidden="true"></i></p>Feedback</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <p class="text-center"><i class="fa fa-product-hunt" aria-hidden="true"></i></p>
            Products
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
          <li><a class="dropdown-item" href="current_stock">Current stock</a></li>
          <li><a class="dropdown-item" href="view_product_list">Product list</a></li>
            <li><a class="dropdown-item" href="add_stock">Add stock</a></li>
            <li><a class="dropdown-item" href="view_product">Product vendor(s)</a></li>
            <li><a class="dropdown-item" href="view_product">Use product in salon</a></li>
          </ul>
        </li>

        

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown2" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <p class="text-center"><i class="fa fa-area-chart" aria-hidden="true"></i></p>
            Reports
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown2">
            <li><a class="dropdown-item" href="daily_report_view">Dailay Reports</a></li>
            <li><a class="dropdown-item" href="day_summary">Dailay Summary</a></li>
            <li><a class="dropdown-item" href="billing_report_view">Billing Reports</a></li>
            <li><a class="dropdown-item" href="enquiry_reports">Enquiry Reports</a></li>
            <li><a class="dropdown-item" href="service-provider-reports">Service Provider Reports</a></li>
            <li><a class="dropdown-item" href="recived-panding-payment">Recived Panding payment</a></li>
            <li><a class="dropdown-item" href="history">History</a></li>
            <li><a class="dropdown-item" href="balance-reports">Balance Report</a></li>
            <li><a class="dropdown-item" href="advanced-reports">Advanced Reports</a></li>
            <li><a class="dropdown-item" href="attendence-reports">Attendence Reports</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown3" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <p class="text-center"><i class="fa fa-plus-square" aria-hidden="true"></i></p>
            Add & Manage
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown3">
            <li><a class="dropdown-item" href="view_expense">Expense</a></li>
            <li><a class="dropdown-item" href="view_service">Services</a></li>
                        <li><a class="dropdown-item" href="view_method">Method</a></li>
                        <li><a class="dropdown-item" href="taxlist">Taxes</a></li>

            <li><a class="dropdown-item" href="#">Packages</a></li>
            <li><a class="dropdown-item" href="view_coupon">Coupons</a></li>
            <li><a class="dropdown-item" href="employee_salary">Employees salary</a></li>
            <li><a class="dropdown-item" href="view_service_provider">Service provider</a></li>
            <li><a class="dropdown-item" href="auto_service_reminder">Automatic service reminder</a></li>
            <li><a class="dropdown-item" href="view_staff">Staff</a></li>
            <li><a class="dropdown-item" href="membership">MemberShip</a></li>
            <li><a class="dropdown-item" href="branches">All branches</a></li>
            <li><a class="dropdown-item" href="#">Trnasfer options</a></li>
            <li><a class="dropdown-item" href="#">software setting</a></li>
            <li><a class="dropdown-item" href="#">Self assessment data</a></li>
            <li><a class="dropdown-item" href="viewwebsetting">System setting</a></li>
            <li><a class="dropdown-item" href="view_attendance">Mark attendance</a></li> 
          </ul>
        </li>
      </ul>
     
    </div>
  </div>
</nav>
  </div>
 
<!--start header -->
<!--<header>-->
<!--<div class="topbar d-flex align-items-center">-->
<!--<nav class="navbar navbar-expand">-->
<!--<div class="mobile-toggle-menu"><i class='bx bx-menu'></i></div>-->
<!--<div class="top-menu ms-auto">-->
    
   
<!--<ul class="navbar-nav align-items-center">-->

<!--<li class="nav-item dropdown dropdown-large">-->

<!--<div class="dropdown-menu dropdown-menu-end">-->

<!--<div class="header-notifications-list">-->


<!--</div>-->

<!--</div>-->
<!--</li>-->
<!--<li class="nav-item dropdown dropdown-large">-->

<!--<div class="dropdown-menu dropdown-menu-end">-->

<!--<div class="header-message-list">-->


<!--</div>-->
<!--</div>-->
<!--</li>-->
<!--</ul>-->
<!--</div>-->

<!--<div class="user-box dropdown">-->
<!--<a class="d-flex align-items-center nav-link dropdown-toggle dropdown-toggle-nocaret has-arrow" href="javascript" role="button" data-bs-toggle="dropdown" aria-expanded="false">-->
<!--<img src="<?php echo e(URL::asset('assets/images/logo-icon.png')); ?>" class="user-img" alt="user avatar">-->
<!--<div class="user-info ps-3">-->
<!--<p class="user-name mb-0">GTS</p>-->
<!--<p class="designattion mb-0">Web Designer</p>-->
<!--</div>-->
<!--</a>-->
<!--<ul class="dropdown-menu dropdown-menu-end">-->
<!--<li><a class="dropdown-item" href="javascript"><i class="bx bx-user"></i><span>Profile</span></a>-->
<!--</li>-->
<!--<li><a class="dropdown-item" href="javascript"><i class="bx bx-cog"></i><span>Settings</span></a>-->
<!--</li>-->

<!--<li><a class="dropdown-item" href="logout" ><i class="bx bx-log-out-circle"></i><span>Logout</span></a>-->
<!--</li>-->

<!--</ul>-->
<!--</div>-->
<!--</nav>-->
<!--</div>-->
<!--</header>-->
<!--end header -->    
    
    
<!--sidebar wrapper -->
<!--<div class="sidebar-wrapper" data-simplebar="true">-->
<!--<div class="sidebar-header">-->
<!--<div>-->
<!--<img src="<?php echo e(URL::asset('assets/images/logo-icon.png')); ?>" class="logo-icon" alt="logo icon">-->
<!--</div>-->
<!--<div>-->
<!--<h4 class="logo-text">AH Salon</h4>-->
<!--</div>-->
<!--<div class="toggle-icon ms-auto"><i class='bx bx-arrow-to-left'></i>-->
<!--</div>-->
<!--</div>-->

<!--<ul class="metismenu" id="menu">-->
<!--<li>-->
<!--<a href="index" >-->
<!--<div class="parent-icon"><i class='bx bx-home-circle'></i>-->
<!--</div>-->
<!--<div class="menu-title">Dashboard</div>-->
<!--</a>-->
<!--</li>-->
<!--<li>-->
<!--<a href="view_enquiry" >-->
<!--<div class="parent-icon " ><i class='bx bx-user '></i>-->
<!--</div>-->
<!--<div class="menu-title">Enquiry</div>-->
<!--</a>-->
<!--</li>-->
<!--<li>-->
<!--<a href="view_client" >-->
<!--<div class="parent-icon " ><i class="fa fa-smile-o" aria-hidden="true"></i>-->

<!--</div>-->
<!--<div class="menu-title">Clients</div>-->
<!--</a>-->
<!--</li>-->
<!--<li>-->
<!--<a href="add_feedback" >-->
<!--<div class="parent-icon " ><i class="fa fa-certificate" aria-hidden="true"></i>-->

<!--</div>-->
<!--<div class="menu-title">Feedback</div>-->
<!--</a>-->
<!--</li>-->

<!--<li>-->
<!--<a href="javascript:;" class="has-arrow">-->
<!--<div class="parent-icon"><i class="fa fa-archive" aria-hidden="true"></i>-->
<!--</div>-->
<!--<div class="menu-title">Products</div>-->
<!--</a>-->
<!--<ul>-->
<!--<li> <a href="view_vender" ><i class="bx bx-right-arrow-alt"></i>Vendor</a>-->
<!--</li>-->
<!--<li> <a href="view_product" ><i class="bx bx-right-arrow-alt"></i>Product Used</a>-->
<!--</li>-->
<!--<li> <a href="add_stock" ><i class="bx bx-right-arrow-alt"></i>Add Stock</a>-->
<!--</li>-->

<!--</ul>-->
<!--</li>-->

<!--<li>-->
<!--<a href="javascript:;" class="has-arrow">-->
<!--<div class="parent-icon"><i class="fa fa-archive" aria-hidden="true"></i>-->
<!--</div>-->
<!--<div class="menu-title">Billing</div>-->
<!--</a>-->
<!--<ul>-->
<!--<li> <a href="billing-form" ><i class="bx bx-right-arrow-alt"></i>Add Bill-->
<!--</a>-->
<!--</li>-->
<!--<li> <a href="wallet-form" ><i class="bx bx-right-arrow-alt"></i>Add Wallet-->
<!--</a>-->
<!--</li>-->
<!--</ul>-->
<!--</li>-->

<!--<li>-->
<!--<a href="javascript:;" class="has-arrow">-->
<!--<div class="parent-icon"><i class="fa fa-archive" aria-hidden="true"></i>-->
<!--</div>-->
<!--<div class="menu-title">Reports</div>-->
<!--</a>-->
<!--<ul>-->
<!--<li> <a href="daily-reports" ><i class="bx bx-right-arrow-alt"></i>Dailay Reports-->
<!--</a>-->
<!--</li>-->
<!--<li> <a href="daily-summary" ><i class="bx bx-right-arrow-alt"></i>Dailay Summary-->
<!--</a>-->
<!--</li>-->
<!--<li> <a href="billing-reports" ><i class="bx bx-right-arrow-alt"></i>Billing Reports-->
<!--</a>-->
<!--</li>-->
<!--<li> <a href="enquiry-repots" ><i class="bx bx-right-arrow-alt"></i>Enquiry Reports-->
<!--</a>-->
<!--</li>-->
<!--<li> <a href="service-provider-reports" ><i class="bx bx-right-arrow-alt"></i>Service Provider Reports-->
<!--</a>-->
<!--</li>-->
<!--<li> <a href="recived-panding-payment" ><i class="bx bx-right-arrow-alt"></i>Recived Panding payment-->
<!--</a>-->
<!--</li>-->
<!--<li> <a href="history" ><i class="bx bx-right-arrow-alt"></i>History-->
<!--</a>-->
<!--</li><li> <a href="balance-reports" ><i class="bx bx-right-arrow-alt"></i>Balance Report-->
<!--</a>-->
<!--</li><li> <a href="advanced-reports" ><i class="bx bx-right-arrow-alt"></i>Advanced Reports-->
<!--</a>-->
<!--</li><li> <a href="attendence-reports" ><i class="bx bx-right-arrow-alt"></i>Attendence Reports-->
<!--</a>-->
<!--</li>-->
<!--</ul>-->
<!--</li>-->


<!--<li>-->
<!--<a href="javascript:;" class="has-arrow">-->
<!--<div class="parent-icon"><i class="fa fa-plus-circle" aria-hidden="true"></i>-->
<!--</div>-->
<!--<div class="menu-title">Add & Manage</div>-->
<!--</a>-->
<!--<ul>-->
<!--<li> <a href="view_expense" ><i class="bx bx-right-arrow-alt"></i>Expense-->
<!--</a>-->
<!--</li>-->
<!--<li> <a href="#" ><i class="bx bx-right-arrow-alt"></i>Services-->
<!--</a>-->
<!--</li>-->
<!--<li> <a href="#" ><i class="bx bx-right-arrow-alt"></i>Packages-->
<!--</a>-->
<!--</li>-->
<!--<li> <a href="view_coupon" ><i class="bx bx-right-arrow-alt"></i>Coupons</a>-->
<!--</li>-->
<!--<li> <a href="employee_salary" ><i class="bx bx-right-arrow-alt"></i>Employees salary-->
<!--</a>-->
<!--</li>-->
<!--<li> <a href="view_service_provider" ><i class="bx bx-right-arrow-alt"></i>Service provider-->
<!--</a>-->
<!--</li>-->
<!--<li> <a href="auto_service_reminder" ><i class="bx bx-right-arrow-alt"></i>Automatic service reminder-->
<!--</a>-->
<!--</li>-->
<!--<li> <a href="view_staff" ><i class="bx bx-right-arrow-alt"></i>Staff</a>-->
<!--</li>-->
<!--<li> <a href="membership" ><i class="bx bx-right-arrow-alt"></i>MemberShip</a>-->
<!--</li>-->
<!--<li> <a href="#" ><i class="bx bx-right-arrow-alt"></i>All branches</a>-->
<!--</li>-->
<!--<li> <a href="#" ><i class="bx bx-right-arrow-alt"></i>Trnasfer options</a>-->
<!--</li>-->
<!--<li> <a href="#" ><i class="bx bx-right-arrow-alt"></i>software setting</a>-->
<!--</li>-->
<!--<li> <a href="#" ><i class="bx bx-right-arrow-alt"></i>Self assessment data</a>-->
<!--</li>-->
<!--<li> <a href="viewwebsetting" ><i class="bx bx-right-arrow-alt"></i>System setting-->
<!--</a>-->
<!--</li>-->
<!--<li> <a href="view_attendance" ><i class="bx bx-right-arrow-alt"></i>Mark attendance-->
<!--</a>-->
<!--</li>-->


<!--</ul>-->
<!--</li>-->
<!--</ul>-->



<!--</div>-->
<!--end sidebar wrapper -->






<?php echo $__env->yieldContent('contant'); ?>




<!--start overlay-->
<div class="overlay toggle-icon"></div>
<!--end overlay-->
<!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
<!--End Back To Top Button-->
<footer class="page-footer">
<p class="mb-0">Copyright &copy; <?php echo date('Y') ?> All right reserved.</p>
</footer>
</div>
<!--end wrapper-->
<!--start switcher-->
<div class="switcher-wrapper">
<!--<div class="switcher-btn"> <i class='bx bx-cog bx-spin'></i>-->
<!--</div>-->
<div class="switcher-body">
<div class="d-flex align-items-center">
<h5 class="mb-0 text-uppercase">Theme Customizer</h5>
<button type="button" class="btn-close ms-auto close-switcher" aria-label="Close"></button>
</div>
<hr/>
<h6 class="mb-0">Theme Styles</h6>
<hr/>
<div class="d-flex align-items-center justify-content-between">
<div class="form-check">
<input class="form-check-input" type="radio" name="flexRadioDefault" id="lightmode" checked>
<label class="form-check-label" for="lightmode">Light</label>
</div>
<div class="form-check">
<input class="form-check-input" type="radio" name="flexRadioDefault" id="darkmode">
<label class="form-check-label" for="darkmode">Dark</label>
</div>
<div class="form-check">
<input class="form-check-input" type="radio" name="flexRadioDefault" id="semidark">
<label class="form-check-label" for="semidark">Semi Dark</label>
</div>
</div>
<hr/>
<div class="form-check">
<input class="form-check-input" type="radio" id="minimaltheme" name="flexRadioDefault">
<label class="form-check-label" for="minimaltheme">Minimal Theme</label>
</div>
<hr/>
<h6 class="mb-0">Header Colors</h6>
<hr/>
<div class="header-colors-indigators">
<div class="row row-cols-auto g-3">
<div class="col">
<div class="indigator headercolor1" id="headercolor1"></div>
</div>
<div class="col">
<div class="indigator headercolor2" id="headercolor2"></div>
</div>
<div class="col">
<div class="indigator headercolor3" id="headercolor3"></div>
</div>
<div class="col">
<div class="indigator headercolor4" id="headercolor4"></div>
</div>
<div class="col">
<div class="indigator headercolor5" id="headercolor5"></div>
</div>
<div class="col">
<div class="indigator headercolor6" id="headercolor6"></div>
</div>
<div class="col">
<div class="indigator headercolor7" id="headercolor7"></div>
</div>
<div class="col">
<div class="indigator headercolor8" id="headercolor8"></div>
</div>
</div>
</div>
<hr/>
<h6 class="mb-0">Sidebar Colors</h6>
<hr/>
<div class="header-colors-indigators">
<div class="row row-cols-auto g-3">
<div class="col">
<div class="indigator sidebarcolor1" id="sidebarcolor1"></div>
</div>
<div class="col">
<div class="indigator sidebarcolor2" id="sidebarcolor2"></div>
</div>
<div class="col">
<div class="indigator sidebarcolor3" id="sidebarcolor3"></div>
</div>
<div class="col">
<div class="indigator sidebarcolor4" id="sidebarcolor4"></div>
</div>
<div class="col">
<div class="indigator sidebarcolor5" id="sidebarcolor5"></div>
</div>
<div class="col">
<div class="indigator sidebarcolor6" id="sidebarcolor6"></div>
</div>
<div class="col">
<div class="indigator sidebarcolor7" id="sidebarcolor7"></div>
</div>
<div class="col">
<div class="indigator sidebarcolor8" id="sidebarcolor8"></div>
</div>
</div>
</div>
</div>
</div>




<!--end switcher-->
<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>


<!--//<script src="<?php echo e(URL::asset('assets/js/jquery.min.js')); ?>"></script>-->

<script src="<?php echo e(URL::asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<!--plugins-->

<script src="<?php echo e(URL::asset('assets/plugins/simplebar/js/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/metismenu/js/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/chartjs/js/Chart.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/chartjs/js/Chart.extension.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/js/index.js')); ?>"></script>
<!--app JS-->
<script src="<?php echo e(URL::asset('assets/js/app.js')); ?>"></script>


<script src="<?php echo e(URL::asset('assets/fancybox/js/jquery.fancybox.min.js')); ?>"></script>


<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/dataTables.bootstrap5.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/js/bootstrap-toggle.min.js')); ?>"></script>
<script type="text/javascript">
/* For CKeditor */

CKEDITOR.replace( 'editor');
</script>
<script src="https:////cdn.ckeditor.com/4.8.0/full-all/ckeditor.js"></script>
	<script src="<?php echo e(URL::asset('assets/plugins/datetimepicker/js/legacy.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('assets/plugins/datetimepicker/js/picker.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('assets/plugins/datetimepicker/js/picker.time.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('assets/plugins/datetimepicker/js/picker.date.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('assets/plugins/bootstrap-material-datetimepicker/js/moment.min.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.min.js')); ?>"></script>
	<script>
		$('.datepicker').pickadate({
			selectMonths: true,
	        selectYears: true
		}),
		$('.timepicker').pickatime()
	</script>
	<script>
		$(function () {
			$('.date-time').bootstrapMaterialDatePicker({
				format: 'YYYY-MM-DD HH:mm'
			});
			$('.date').bootstrapMaterialDatePicker({
				time: false
			});
			$('.time').bootstrapMaterialDatePicker({
				date: false,
				format: 'HH:mm'
			});
		});
	</script>



<script>
$(document).ready(function() {
$('#example').DataTable();
} );
</script>
<script>
$(document).ready(function() {
var table = $('#example2').DataTable( {
lengthChange: false,
buttons: [ 'copy', 'excel', 'pdf', 'print']
} );

table.buttons().container()
.appendTo( '#example2_wrapper .col-md-6:eq(0)' );
} );
</script>


<script>
function goBack() {
window.history.back();
}
</script>

<script>
$('.single-select').select2({
theme: 'bootstrap4',
width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
placeholder: $(this).data('placeholder'),
allowClear: Boolean($(this).data('allow-clear')),
});
$('.multiple-select').select2({
theme: 'bootstrap4',
width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
placeholder: $(this).data('placeholder'),
allowClear: Boolean($(this).data('allow-clear')),
});
</script>

<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>-->
<!--<script type="text/javascript">-->
 
<!--     $('.show_confirm').click(function(event) {-->
<!--          var name = $(this).data("name");-->
<!--          event.preventDefault();-->
<!--          swal({-->
<!--              title: `Are you sure you want to delete this record?`,-->
<!--              text: "If you delete this, it will be gone forever.",-->
<!--              icon: "warning",-->
<!--              buttons: true,-->
<!--              dangerMode: true,-->
<!--          })-->
<!--          .then((willDelete) => {-->
<!--            if (willDelete) {-->
<!--              form.submit();-->
<!--            }-->
<!--          });-->
<!--      });-->
  
<!--</script>-->





// <script type="text/javascript">
//   $(document).ready(function(){
//     $('.sp_onchange').on( "change", function(){
     
//       var quantity = parseInt($('#quantity').val());
//       var discount = parseInt($('#discount').val());
//       var discount_type = $('#discount_type').val();
//       var price = $('#price').val();
      
//       var subtotal = parseInt(quantity*price);
   
      
//       if(discount_type == '1'){
//           var total = subtotal-discount;
//       }else{
//           var per_discount = subtotal * (discount/100);
//           var total = subtotal-per_discount;
          
//       }
//       $('#sum').text("INR "+total);
//       $('#total').val(total);
//       $('#due').text(total);

//      });
//   });

  

// </script>


// <script type="text/javascript">
//   $(document).ready(function(){
//     $('.txn_change').on( "change", function(){
     
//       var txn_amount = parseInt($(this).val());
//       var total = parseInt($('#total').val());
//       var subtotal = parseInt(total-txn_amount);
    
//       $('#due').text(subtotal);
  
//      });
//   });

// </script>

// <script>
//     $(document).ready(function(){
//     $('.gst_tax').on( "change", function(){
     
//         var total = parseInt($('#total').val());
//         var subtotal = total * (18/100);
//         var g_total = subtotal+total; 
//         $('#total').val(g_total);
//         $('#due').text(g_total);
  
//      });
//   });
// </script>


<script>
    $(document).on('change', '.servicechange', function(){
    	    var service_id = $(this).val();
    	    let $this = $(this);
    	    
    	    $.ajax({
            type:'POST',
            dataType:'json',
            url:"<?php echo e(route('admin.serviceonchange')); ?>",
            data:{
                 service_id:service_id,
                _token:'<?php echo e(csrf_token()); ?>'
            },
            success:function(response){
                if(response.status){
                    $this.closest('.TextBoxContainer').find('.service_category').val(response.ser_cat);
                    $this.closest('.TextBoxContainer').find('.price').val(response.ser_price);
                    $this.closest('.TextBoxContainer').find('.quantity').val('1');
                    var price = response.ser_price;
                    var total = parseInt(1*price);
                    $this.closest('.TextBoxContainer').find('.single_total').val(total);
                    $this.closest('.TextBoxContainer').find('.actual_price').val(total);
                    var count = 0;
                    $(".single_total").each(function( index ) {
                        count = parseInt(count) + parseInt($(this).val());
                        $('.subtotal').text("INR "+count);
                        $('.amountpayable').val(count);
                        $('.amountpayable').text(count);
                        $('.total').val(count);
                    });
                    
                    
                  
                }
            }
        });
    	
    });
</script>

<script>
    $(document).on('change', '.uprcommon', function(){
    	var quantity = $(this).closest('.TextBoxContainer').find('.quantity').val();
    	var discount = $(this).closest('.TextBoxContainer').find('.discount').val();
    	var discounttype = $(this).closest('.TextBoxContainer').find('.discounttype').val();
        var price = $(this).closest('.TextBoxContainer').find('.actual_price').val();
        var tax = $('.taxvalue').val();
        if(price >0){
           
            var subtotal = parseInt(quantity*price);
            if(discounttype == 1){
                var total = subtotal-discount;
            }else{
                var discountdisper = discount/100;
                var per_discount = subtotal * discountdisper;
                var total = parseInt(subtotal)-parseInt(per_discount);
            }
            $(this).closest('.TextBoxContainer').find('.single_total').val(total);
            
            
            // if(tax > 0){
            //     var taxper = tax/100;
            //     var per_tax = total * taxper;
            //     var totalwithtax = parseInt(total) + parseInt(per_tax);
                
            // }else{
                
            // }
            $(this).closest('.TextBoxContainer').find('.price ').val(total);
            
            var count = 0;
            $(".single_total").each(function( index ) {
                count = parseInt(count) + parseInt($(this).val());
                $('.subtotal').text("INR "+count);
                $('.amountpayable').val(count);
                $('.amountpayable').text(count);
                $('.total').val(count);
            });
        }

    });
</script>


<script>
    $(document).on('change', '.taxcommon', function(){

        var total_charge = $('.total').val();
        //var commondiscount = $('.commondiscount').val();
        //var discounttype = $('.discounttype').val();
        var taxvalue = $('.taxvalue').val();
        //var shippingcharge = $('.shippingcharge').val();
        var paidamount = $('.paidamount').val();
       
        if(total_charge > 0){
            
            // if(discounttype == '1'){
                
            //     var total1 = parseInt(total_charge-commondiscount);
            //     if(taxvalue > 0){
            //         var disper = taxvalue/100;
            //         var totalper = total1 * disper;
            //         var total2 = totalper + total1;
            //     }else{
            //         var total2 = total1;
            //     }
                
            //     var total3 = total2+parseInt(shippingcharge);
            //     var gtotal = parseInt(total3)-parseInt(paidamount);
                
            // }else if(discounttype =='0'){
            //     var commondiscountdisper = commondiscount/100;
            //     var per_discount = total_charge * commondiscountdisper;
                
            //     var total1 = parseInt(total_charge)-parseInt(per_discount);
                
            //     if(taxvalue > 0){
            //         var disper = taxvalue/100;
            //         var totalper = total1 * disper;
                    
            //         var total2 = totalper + total1;
            //     }else{
            //         var total2 = total1;
            //     }
                
            //     var total3 = parseInt(total2)+parseInt(shippingcharge);
            //     var gtotal = parseInt(total3)-parseInt(paidamount);
            // }else{
               
                var total1 = total_charge;
                if(taxvalue > 0){
                   
                    var disper = taxvalue/100;
                    var totalper = total1 * disper;
                    var total2 = parseInt(totalper) + parseInt(total1);
                    
                }else{
                    var total2 = total1;
                }
                
                
                //var total3 = parseInt(total2)+parseInt(shippingcharge);
                var gtotal = parseInt(total2)-parseInt(paidamount);
               
            //}
            $('.gtotal').val(gtotal);
            $('.amountpayable').text(gtotal);
            $('.total').val(gtotal);
            $('.gtotal').text(gtotal);
        }
        

    });
</script>

<script>
    $(document).on('change', '.paidcommon', function(){

        var total_charge = $('.total').val();
        //var taxvalue = $('.taxvalue').val();
        var paidamount = $('.paidamount').val();
      
        if(total_charge > 0){
            
                // var total1 = total_charge;
                // if(taxvalue > 0){
                   
                //     var disper = taxvalue/100;
                //     var totalper = total1 * disper;
                //     var total2 = parseInt(totalper) + parseInt(total1);
                    
                // }else{
                //     var total2 = total1;
                // }
                var gtotal = parseInt(total_charge)-parseInt(paidamount);
               
            $('.gtotal').val(gtotal);
            $('.amountpayable').text(gtotal);
            //$('.total').val(gtotal);
            $('.gtotal').text(gtotal);
        }
    });
</script>

<script src="https://unpkg.com/feather-icons"></script>
<?php echo $__env->yieldPushContent('footer_script'); ?>



</body>



</html><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/include/master.blade.php ENDPATH**/ ?>