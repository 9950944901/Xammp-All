
<?php $__env->startSection('page_title','Enquiry'); ?>
<?php $__env->startSection('contant'); ?>

<style>

.button1{
position: relative;
bottom: 38px;

}

</style>

<div class="page-wrapper">
<div class="page-content">

<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header text-uppercase"> Update Enquiry
</div>
<div class="card-body">
<form method="POST" action="admin/update_enquiry" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<input type="hidden" name="id" value="<?php echo e($upadateenq['id']); ?>">
<div class="form-group row">
<label for="basic-input" class="col-sm-2 col-form-label">Contact number </label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="number" class="form-control" value="<?php echo e($upadateenq->contact_number); ?>" name="contact_number" placeholder="Contact number" value="">
</div>

</div>


<label for="basic-input" class="col-sm-2 col-form-label">Client name </label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($upadateenq->client_name); ?>" name="client_name" placeholder="Client name" value="">
</div>

</div>

<label for="basic-input" class="col-sm-2 col-form-label">Email </label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="email" class="form-control" value="<?php echo e($upadateenq->email); ?>" name="email" placeholder="Enter email" value="">
</div>

</div>

<label for="basic-input" class="col-sm-2 col-form-label">Address </label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($upadateenq->address); ?>" name="address" placeholder="Enter Address" value="">
</div>

</div>

</div>


<div class="form-group row">
<label for="basic-input" class="col-sm-2 col-form-label">Enquiry for </label>
<div class="col-sm-4">
<div class="input-group mb-3">
<select name="enquiry_for" class="form-control single-select" required>
<option value="">--Select Option--</option>
<option value="Hair cut" <?php if($upadateenq['enquiry_for']=='Hair cut'){ ?>selected<?php } ?>>Hair cut</option>
<option value="Hair smothing" <?php if($upadateenq['enquiry_for']=='Hair smothing'){ ?>selected<?php } ?>>Hair smothing</option>
<option value="Advance Hair Cut" <?php if($upadateenq['enquiry_for']=='Advance Hair Cut'){ ?>selected<?php } ?>>Advance Hair Cut</option>
</select> 
</div>

</div>


<label for="basic-input" class="col-sm-2 col-form-label">Enquiry Type </label>
<div class="col-sm-4">
<div class="input-group mb-3">
<select name="enquiry_type" class="form-control single-select" required>
<option value="">Select Option</option>
<option value="cold" <?php if($upadateenq['enquiry_type']=='cold'){ ?>selected<?php } ?>>cold</option>
<option value="Hot" <?php if($upadateenq['enquiry_type']=='Hot'){ ?>selected<?php } ?>>Hot</option>
<option value="Warm" <?php if($upadateenq['enquiry_type']=='Warm'){ ?>selected<?php } ?>>Warm</option>
</select> 
</div>

</div>


</div>
<div class="form-group row">

<label for="basic-input" class="col-sm-2 col-form-label">Response</label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($upadateenq->response); ?>" name="response" placeholder="Enter Response" value="">
</div>

</div>


<label for="basic-input" class="col-sm-2 col-form-label">Date to follow </label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input class="result form-control date" value="<?php echo e($upadateenq->follow_date); ?>" type="text" name="follow_date" id="" placeholder="Date">
</div>

</div>


<label for="basic-input" class="col-sm-2 col-form-label">Source of enquiry </label>
<div class="col-sm-4">
<div class="input-group mb-3">
<select name="source_of_enquiry" class="form-control single-select" required>  
<option value="">Select Option</option>
<option value="Twitter" <?php if($upadateenq['source_of_enquiry']=='Twitter'){ ?>selected<?php } ?>>Twitter</option>
<option value="Website" <?php if($upadateenq['source_of_enquiry']=='Website'){ ?>selected<?php } ?>>Website</option>
<option value="Google" <?php if($upadateenq['source_of_enquiry']=='Google'){ ?>selected<?php } ?>>Google</option>


</select> 
</div>

</div>

<label for="basic-input" class="col-sm-2 col-form-label">Lead representative</label>
<div class="col-sm-4">
<div class="input-group mb-3">
<select name="lead_representative" class="form-control single-select" required>
<option value="">Select Option</option>
<option value="Admin" <?php if($upadateenq['lead_representative']=='Admin'){ ?>selected<?php } ?>>Admin</option>
<option value="Dummy" <?php if($upadateenq['lead_representative']=='Dummy'){ ?>selected<?php } ?>>Dummy</option>
<option value="Demo" <?php if($upadateenq['lead_representative']=='Demo'){ ?>selected<?php } ?>>Demo</option>

</select> 
</div>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Lead status </label>
<div class="col-sm-4">
<div class="input-group mb-3">
<select name="lead_status" class="form-control single-select"> required
<option value="">Select Option</option>
<option value="2" <?php if($upadateenq['lead_status']=='2'){ ?>selected<?php } ?>>Pending</option>
<option value="1" <?php if($upadateenq['lead_status']=='1'){ ?>selected<?php } ?>>Converted</option>
<option value="0" <?php if($upadateenq['lead_status']=='0'){ ?>selected<?php } ?>>Close</option>

</select> 
</div>

</div>



</div>



<p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
</div>
</form>
</div>
</div>
</div>
</div>

</div>
</div>
</div>



<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->
<?php $__env->stopSection(); ?>



<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/qwudvcjf8yxq/public_html/gst_salon/resources/views/admin/update_enquiry.blade.php ENDPATH**/ ?>