
<?php $__env->startSection('page_title','UPDATE SERVICE PROVIDER'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
<div class="page-content">

<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header text-uppercase"> UPDATE SERVICE PROVIDER
</div>
<div class="card-body">
<form method="POST" action="admin/update_service_provider" class="form-horizontal"  enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<input type="hidden" name="id" value="<?php echo e($upadateprovidern['id']); ?>">
<div class="form-group row">
<label for="basic-input" class="col-sm-2 col-form-label">Enter Name</label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e($upadateprovidern->name); ?>" name="name" placeholder="Enter name" value="">
</div>
<p style="color:red;"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Service commission % </label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="number" class="form-control" value="<?php echo e($upadateprovidern->service_commission); ?>" name="service_commission" placeholder="Service commission % " value="">
</div>
<p style="color:red;"><?php $__errorArgs = ['service_commission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Product commission % </label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="number" class="form-control" value="<?php echo e($upadateprovidern->product_commission); ?>" name="product_commission" placeholder="Product commission % " value="">
</div>
<p style="color:red;"><?php $__errorArgs = ['product_commission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Date of birth </label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control date" value="<?php echo e($upadateprovidern->dob); ?>" name="dob" placeholder="Date of birth" >
</div>
<p style="color:red;"><?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Contact number</label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="number" class="form-control" value="<?php echo e($upadateprovidern->contcat_num); ?>" maxlength="10" onBlur="contact_no_length($(this), this.value);" name="contcat_num" placeholder="Contact number" value="">
</div>
<span style="color:red" id="digit_error"></span>
<p style="color:red;"><?php $__errorArgs = ['contcat_num'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Email Address</label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="email" class="form-control" value="<?php echo e($upadateprovidern->email); ?>" onblur="duplicateEmail(this)" name="email" placeholder="Enter email" value="">
</div>
<p style="color:red;"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Working hours</label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control timepicker" value="<?php echo e($upadateprovidern->working_hourse_start); ?>" name="working_hourse_start" placeholder="Enter Start Time" value="">&nbsp;
<input type="text" class="form-control timepicker" value="<?php echo e($upadateprovidern->working_hourse_end); ?>" name="working_hourse_end" placeholder="Enter End Time" value="">
</div>
<p style="color:red;"><?php $__errorArgs = ['working_hourse_end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Monthly salary  <span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="number" class="form-control " value="<?php echo e($upadateprovidern->month_salary); ?>" name="month_salary" placeholder="Monthly salary " value="">&nbsp;
</div>
<p style="color:red;"><?php $__errorArgs = ['month_salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>


<label for="basic-input" class="col-sm-2 col-form-label">Emergency contact number <span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="number" class="form-control " value="<?php echo e($upadateprovidern->emg_cont_num); ?>" maxlength="10" onblur="othercontact($(this), this.value);" name="emg_cont_num" placeholder="Emergency contact number" value="">&nbsp;
</div>
<p style="color:red;"><?php $__errorArgs = ['emg_cont_num'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
<span style="color:red" class="conterror"></span>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Emergency contact person <span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control " value="<?php echo e($upadateprovidern->emg_cont_per); ?>" maxlength="10" onblur="othercontact($(this), this.value);" name="emg_cont_per" placeholder="Emergency contact person" >&nbsp;
</div>
<p style="color:red;"><?php $__errorArgs = ['emg_cont_per'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
<span style="color:red" class="conterror"></span>
</div>


<label for="basic-input" class="col-sm-2 col-form-label">Address <span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control " value="<?php echo e($upadateprovidern->address); ?>" name="address" placeholder="Enter Address" value="">&nbsp;
</div>
<p style="color:red;"><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>



<label for="basic-input" class="col-sm-2 col-form-label">Gender </label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="radio" checked="" name="gender" value="1" <?php echo e(($upadateprovidern->gender)=='1' ? 'checked' : ''); ?>>&nbsp; <b style="margin-top: -3px;">Male</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="gender" value="0" <?php echo e(($upadateprovidern->gender)=='0' ? 'checked' : ''); ?>>&nbsp; <b style="margin-top: -3px;">Female</b> &nbsp;

</div>
<p style="color:red;"><?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>


<label for="basic-input" class="col-sm-2 col-form-label">Date of joining</label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control date" value="<?php echo e($upadateprovidern->date_of_joing); ?>" name="date_of_joing" placeholder="Enter Date of joining" value="">&nbsp;
</div>
<p style="color:red;"><?php $__errorArgs = ['date_of_joing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>


<label for="basic-input" class="col-sm-2 col-form-label">Service provider type</label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control " value="<?php echo e($upadateprovidern->service_pro_type); ?>" name="service_pro_type" placeholder="Service provider type" value="">&nbsp;
</div>
<p style="color:red;"><?php $__errorArgs = ['service_pro_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>




<label for="basic-input" class="col-sm-2 col-form-label">Upload Photo <span style="color:red;">*</span></label>
<div class="col-sm-4">
<div class="input-group mb-3">
<input type="file" class="form-control" value="<?php echo e($upadateprovidern->image); ?>" name="image"  value="">
<a href="<?php echo e(URL('uploads/Service Providers/Service_providers_IDProof/'.$upadateprovidern->image)); ?>" data-fancybox="image">
    <img src="<?php echo e(URL('uploads/Service Providers/Service_providers_image/'.$upadateprovidern->image)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 70px; height: 35px;">
    </a>
</div>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Upload ID Proof</label>
<div class="col-sm-4">
<div class="input-group mb-3">
<input type="file" class="form-control" value="<?php echo e(old('id_proof')); ?>" name="id_proof"  value="">
<input type="hidden" name="imagehidden" value="<?php echo e($upadateprovidern->id_proof); ?>">
<a href="<?php echo e(URL('uploads/Service Providers/Service_providers_IDProof/'.$upadateprovidern->id_proof)); ?>" data-fancybox="id_proof">
    <img src="<?php echo e(URL('uploads/Service Providers/Service_providers_IDProof/'.$upadateprovidern->id_proof)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 70px; height: 35px;">
</a>
</div>
</div>





</div>



<p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
</div>
</form>
<div class="card-header text-uppercase">
</div>
 <b style="    font-size: 25px;text-align: center;margin-top: 15px; color:red;">UPDATE SERVICE PROVIDER PASSWORD</b>
<div class="card-header text-uppercase"></div>

<form method="POSt" action="update_providerss" class="form-horizontal"  enctype="multipart/form-data">
    <div class="form-group row " style="margin-left:auto; margin-top: 40px;">
    
    <label for="basic-input" class="col-sm-1 col-form-label">Username</label>
    <div class="col-sm-2">
<div class="input-group mb-3 col-sm-3">
<?php echo csrf_field(); ?>

<input type="hidden" class="form-control"  name="id" placeholder="Enter name" value="<?php echo e($upadateprovidern->id); ?>">
<input type="text" disabled class="form-control " value="<?php echo e($upadateprovidern->username); ?>" name="username" placeholder="Enter Username" readonly value="">&nbsp;
</div>
</div>



<label for="basic-input" class="col-sm-1 col-form-label">Password</label>
<div class="col-sm-2">
<div class="input-group mb-3 col-sm-2">
<input type="hidden" class="form-control" name="hiddenpassword" id="password"  placeholder="Enter Password" value="<?php echo e($upadateprovidern->password); ?>">
<input type="password" class="form-control password" onBlur="checklength()" name="password" id="Ppassword"  placeholder="Enter Password" value="">&nbsp;

<span style="color:red;" class='pass-status'></span>
<p style="color:red;"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
</div>

<label for="basic-input" class="col-sm-2 col-form-label">Confirm password</label>
<div class="col-sm-2">
<div class="input-group mb-3 col-sm-3">
<input type="Password" class="form-control"  onBlur="checkpass()" name="confirm_password" id="confirm_password"   placeholder="Confirm password" value="">
<p style="color:red;"><?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
<span id='message'></span>
 </div>
    
   </div>
   <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
</div>
</div>
</form>
</div>
</div>
</div>
</div>

</div>
</div>
</div>
<script> 

    
 function checkpass() {		
	if ($('#Ppassword').val() != $('#confirm_password').val()){
		//alert('Password Length 6 Chars minimum');
		$("#message").html('Password Not Matching').css('color', 'red');
		$('#confirm_password').val("");
	} else if($('#Ppassword').val() === $('#confirm_password').val()){
		$("#message").html('');
	}
}


    
function checklength() {		
	if($(".password").val().length <= 5 && $(".password").val().length > 0){
		//alert('Password Length 6 Chars minimum');
		$(".pass-status").html('Password Length 6 character minimum');
		$('.password').val("");
	} else if($(".password").val().length > 5 || $(".password").val().length <= 0){
		$(".pass-status").html('');
	}
}

	function contact_no_length(currDiv, phone_number){
	    var digit = phone_number.length;
	    if(digit > 0 && digit < 10){
	        currDiv.val('');
	        $('#digit_error').text('Please enter 10 digit number.');
	    } else {
	        $('#digit_error').text('');
	    }
	}
	
	
	function othercontact(currDiv, phone_number){
	    var digit = phone_number.length;
	    if(digit != 10){
	        currDiv.parent().find('input').val('');
	        currDiv.parent().find('#conterror').text('Please enter 10 digit number.');
	    } else {
	        currDiv.parent().find('#conterror').text('');
	    } 
	}
	
    
    


</script> 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/update_service_provider.blade.php ENDPATH**/ ?>