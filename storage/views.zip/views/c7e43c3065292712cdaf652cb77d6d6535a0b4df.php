
<?php $__env->startSection('page_title','Product'); ?>
<?php $__env->startSection('contant'); ?>
<div class="page-wrapper">
<div class="page-content">
<div class="row">

<div class="col-xl-12 mx-auto">

<h6 class="mb-0 text-uppercase">Product Setting</h6>

<hr/>



<div class="card">

<div class="card-body">

<div class="p-4 border rounded">

<form class="row g-3 " action="add-product" method="post"  enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="col-md-6">
<label  class="form-label">Category</label>
<select name="catagory" id="catagory" value="<?php echo e(old('catagory')); ?>" class="form-control single-select">
<option>--Select Categroy type--</option>
<?php $__currentLoopData = $categoryslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->categroy); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select> 
<p style="color:red;"><?php $__errorArgs = ['catagory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<div class="col-md-6">
<label  class="form-label">Sub Category</label>
<select name="subcategory" id="subcategory" value="<?php echo e(old('subcategory')); ?>" class="form-control single-select">
<option value="">--Select Subcategroy type--</option>
</select> 
<p style="color:red;"><?php $__errorArgs = ['subcategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div> 


<div class="col-md-6">
<label  class="form-label">Child-Category</label>
<select name="childcategory" id="childcategory" value="<?php echo e(old('childcategory')); ?>" class="form-control single-select">
<option value="">--Select Child-Category type--</option>
</select> 
<p style="color:red;"><?php $__errorArgs = ['childcategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div> 




<div class="col-md-6">
<label  class="form-label">Product Name</label>
<input type="text" name="pro_name" value="<?php echo e(old('pro_name')); ?>" class="form-control" >
<p style="color:red;"><?php $__errorArgs = ['pro_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
<div class="col-md-6">
<label  class="form-label">Product Image</label>
<input type="file" name="pro_img" value="<?php echo e(old('pro_img')); ?>" class="form-control" >
<p style="color:red;"><?php $__errorArgs = ['pro_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<div class="col-md-6">
<label  class="form-label">Product Multi Images</label>
<input type="file" name="pro_multi_img[]" value="<?php echo e(old('pro_multi_img')); ?>" multiple="multiple" class="form-control" >
<p style="color:red;"><?php $__errorArgs = ['pro_multi_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

<div class="col-md-6">
<label  class="form-label">Product Price</label>
<input type="number" name="pro_price" value="<?php echo e(old('pro_price')); ?>" class="form-control" >
<p style="color:red;"><?php $__errorArgs = ['pro_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
<div class="col-md-6">
<label  class="form-label">Product MRP Price</label>
<input type="number" name="pro_mrp" value="<?php echo e(old('pro_mrp')); ?>" class="form-control" >
<p style="color:red;"><?php $__errorArgs = ['pro_mrp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
<div class="col-md-6">
<label  class="form-label">Product Url</label>
<input type="text" name="pro_url" value="<?php echo e(old('pro_url')); ?>" class="form-control" >
<p style="color:red;"><?php $__errorArgs = ['pro_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
<div class="col-md-6">
<label  class="form-label">Discount</label>
<input type="number" name="pro_discount" value="<?php echo e(old('pro_discount')); ?>" class="form-control" >
<p style="color:red;"><?php $__errorArgs = ['pro_discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
<div class="col-md-6">
<label  class="form-label">About product</label>
<textarea type="text" name="pro_about" value="" class="form-control" ><?php echo e(old('pro_about')); ?></textarea>
<p style="color:red;"><?php $__errorArgs = ['pro_about'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
<div class="col-md-6">
<label  class="form-label">Status</label>
<select name="status" class="form-control single-select">
<option value="">Select Status</option>
<option value="1">Active</option>
<option value="0">Inactive</option>
</select> 
<p style="color:red;"><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
<div class="col-md-12">
<label  class="form-label">Product Short Description</label>

<textarea type="text"  class="form-control" value="" placeholder="Enter Your Product Short Description" name="editor" rows="5" ><?php echo e(old('pro_description')); ?></textarea>
<p style="color:red;"><?php $__errorArgs = ['editor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>





<div class="col-12 text-center">

<p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>

</div>

</form>

</div>

</div>

</div>

</div>

</div>

</div>

</div>
<?php $__env->startPush('footer_script'); ?>

		<script>
	jQuery(document).ready(function(){

			jQuery('#catagory').change(function(){
				let cid=jQuery(this).val();
				jQuery('#childcategory').html('<option value="">--Select Child-Category type--</option>')
				jQuery.ajax({
					url:'getSubcat',
					type:'post',
					data:'cid='+cid+'&_token=<?php echo e(csrf_token()); ?>',
					success:function(result){

						jQuery('#subcategory').html(result)
					}
				});
			});
			
					jQuery('#subcategory').change(function(){
				let sid=jQuery(this).val();
				jQuery.ajax({
					url:'getchildcat',
					type:'post',
					data:'sid='+sid+'&_token=<?php echo e(csrf_token()); ?>',
					success:function(result){

						jQuery('#childcategory').html(result)
					}
				});
			});
			
    });


			
		</script>

<?php $__env->stopPush(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hypergroups/public_html/newlaravel/resources/views/admin/add-product.blade.php ENDPATH**/ ?>