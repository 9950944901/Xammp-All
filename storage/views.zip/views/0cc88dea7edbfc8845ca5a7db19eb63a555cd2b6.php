
<?php $__env->startSection('page_title','Categroy'); ?>
<?php $__env->startSection('contant'); ?>

<style>

.button1{
    position: relative;
    bottom: 38px;
        padding: 6px 27px;
    }
    
    </style>

<div class="page-wrapper">
			<div class="page-content">
				

    <div class="container-fluid">

	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase">Update Product</div>
			 
			   <div class="text-end"><button type="back" onclick="goBack()" class="btn btn-primary button1"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i></button></div>
			     <div class="card-body">
			        
				    <form method="POST" action="admin/update-product" class="form-horizontal" enctype="multipart/form-data">
				        
				        
				        
<?php echo csrf_field(); ?>
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<input type="hidden" name="id" value="<?php echo e($proselect['id']); ?>">


					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Product Name</label>
						  <div class="col-sm-10">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e($proselect['pro_name']); ?>" name="pro_name" placeholder="some text" value="">
							  </div>
							 <P style="color:red;"> <?php $__errorArgs = ['pro_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></P>
                             
						  </div>
						</div>
					

						
						<div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Product Image</label>
						  <div class="col-sm-4">
                          <div class="col-sm-12">
<P> <span><input type="file" name="pro_img" class="form-control" autocomplete="nope" ></span></P>
<input type="hidden" name="logohidden" value="<?php echo e($proselect['pro_img']); ?>">
<img src="<?php echo e(('../uploads/product_images/product_single_img/'.$proselect->pro_img)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 90px; height: 55px;">
</div>
						  </div>
				
						  <label for="basic-input" class="col-sm-2 col-form-label">Product Images</label>
						  <div class="col-sm-4">
                          <div class="col-sm-12">
                              <P> <span><input type="file" name="pro_multi_img[]" multiple="multiple" class="form-control" autocomplete="nope" ></span></P>
<?php $__currentLoopData = json_decode($proselect->pro_multi_img, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media_gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <a href="<?php echo e(url('/uploads/product_images/product_multi_img/'.$media_gallery)); ?>" data-toggle="lightbox" data-title="Package Media Gallery" data-gallery="gallery">
                     <img src="<?php echo e(url('/uploads/product_images/product_multi_img/'.$media_gallery)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 90px; height: 55px;">
                     </a>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						  </div>
						</div>
						</div>
						
						<br>

			    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Product Price</label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
							<input type="number" name="pro_price" value="<?php echo e($proselect['pro_price']); ?>" class="form-control" >
							  </div>
							  </div>
							  
							  	  <label for="basic-input" class="col-sm-2 col-form-label">Product Mrp</label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" name="pro_mrp" value="<?php echo e($proselect['pro_mrp']); ?>" class="form-control" >
							  </div>
                             
						  </div>
						</div>
						
						
							    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Product Url</label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
						<input type="text" name="pro_url" value="<?php echo e($proselect['pro_url']); ?>" class="form-control" >
							  </div>
							  </div>
							  
							  	  <label for="basic-input" class="col-sm-2 col-form-label">Discount</label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
							<input type="number" name="pro_discount" value="<?php echo e($proselect['pro_discount']); ?>" class="form-control" >
							  </div>
                             
						  </div>
						</div>
						

<div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">About product</label>
						  <div class="col-sm-10">
							<div class="input-group mb-3">
								<textarea name="pro_about" ><?php echo e($proselect['pro_about']); ?></textarea>
							  </div>
						  </div>
						</div>
		
						

		<div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Description</label>
						  <div class="col-sm-10">
							<div class="input-group mb-3">
								<textarea name="editor" ><?php echo e($proselect['pro_description']); ?></textarea>
							  </div>
						  </div>
						</div>

		
<p class="text-center"><button type="submit" value="submit"  class="btn btn-success" name="submit">Update</button></p>

					</form>
					</div>
		   
	    </div>
        </div>
								</div><!--end row-->
							</div>
					


   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
<?php $__env->stopSection(); ?>




<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hypergroups/public_html/newlaravel/resources/views/admin/update_product.blade.php ENDPATH**/ ?>