<?php $__env->startSection('page_title','ADD STOCK'); ?>
<?php $__env->startSection('contant'); ?>

<style>
.panel-heading h4 {
    position: relative;
    padding: 12px 15px;
    border: 0;
    font-size: 17px;
    background-color: #f2f2f2;
    border-radius: 4px;
}

.quantiry_change {
    width: 60px;
}

.table_add_stock_margin {
    margin-top: 25px;
}
</style>


<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Add stock
</div>
			     <div class="card-body">
				    <form method="POSt" action="savestock" class="form-horizontal" enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>
                         <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					    <div class="panel">
						<div class="panel-heading">
							<h4>Purchase from vendor / add stock</h4>
						</div>
						<div class="panel-body">
							<div class="row">
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 w-20">
								<div class="form-group">
									<label for="vendor">Product vendor name <span class="text-danger">*</span></label>
									<input type="text" class="form-control typeahead" id="vendor" name="vendor" value="" placeholder="Autocomplete (Phone)" required>
									<input type="hidden" name="vendor_id" id="vendorid" value="" class="clt">
								</div>
							</div>
							
							<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12 w-20">
								<div class="form-group">
									<label for="contact_no">Contact no <span class="text-danger">*</span></label>
									<input type="text" class="form-control" id="contact_no" name="contact_no" value="" placeholder="Contact no" required>
								</div>
							</div>
							
							<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12 w-20">
								<div class="form-group">
									<label for="gst_no">GST number</label>
									<input type="text" class="form-control" id="gst_no" name="gst_no" value="" placeholder="GST">
								</div>
							</div>
							
							
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 w-20">
								<div class="form-group inv_no">
									<label for="inv">Invoice give by vendor <span class="text-danger">*</span></label>
									<input type="text" class="form-control" name="invoice_by_vendor" placeholder="Invoice no" value="" onblur="checkinvoice_no(this.value, '')" required>
									<span class="text-danger"></span>
								</div>
							</div>
							
							<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12 w-20">
								<div class="form-group">
									<label for="dop">Date of purchase <span class="text-danger">*</span></label>
									<input type="text" class="form-control dob_annv_date" value="2022-05-10" name="date_of_purchase"  value="" required>
									
								</div>
							</div>
							
							
							
							<div class="clearfix"></div>
							
							
							
							<div class="table-responsive table_add_stock_margin">
								<table id="myTable" class="table table-bordered">
									<thead>
										<tr>
											<th style="width:34%" colspan="2">Product</th>
											<th style="width:3%">MRP</th>
											<th style="width:15%">Price</th>
											<th style="width:15%">Sale price</th>
											<th style="width:15%">Quantity</th>
											<th style="width:8%">Exp. date</th>
											<th style="width:8%">Total</th>
										</tr>
									</thead>
									<tbody>
										
										<tr id="TextBoxContainer" class="TextBoxContainer">
										    <input type="hidden" value="0" class="single_total">
											<td class="sno text-center" style="vertical-align:middle;"><span class="fa fa-ellipsis-v"></span></td>
											    <td >
													<table class="inner-table-space">
														<tbody>
														    <tr>
    															<td width="20%" style="vertical-align: top;">
    															    <select class="form-control v_unit vu productchange" name="product[]">
    															         <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    																        <option value="<?php echo e($value->id); ?>"><?php echo e($value->pro_name); ?></option>
    																    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    													            </select>
    															</td>
    															
    															<td width="40%" style="vertical-align: top;">  
    																<input type="number" class="ser form-control slot ui-autocomplete-input volume" name="volume[]" value="" placeholder="Volume" required="required" autocomplete="off">
    															</td>
    															<td width="20%">
    															    <select class="form-control v_unit vu unit" name="unit[]">
    																    <option value="l">L</option>
    																	<option value="ml">ML</option>
    																	<option value="mg">MG</option>
    																	<option value="gram">Gram</option>
    																	<option value="pcs">Pcs</option>
    																	<option value="pkt">Pkt</option>																	
    													            </select>
    															</td>
    														</tr>
													    </tbody>
													 </table>
												</td>
										
											<td><input type="number" class="qt form-control sal quantiry_change mrp" id="mrp" name="mrp[]" value="0" min='0' required></td>
											<td>
												<table class="inner-table-space">
													<tbody><tr>
														<td>
														    <input type="number" class="form_control form-control sp_onchange price" value="0" id="price" name="price[]" min="0"  required>
														  
														</td>
													</tr>
												</tbody></table>
											</td>
											<td>
												<table>
													<tbody>
													    <tr>
														<td width="50%">
														   <input type="number" class="form_control form-control sp_onchange sale_price" value="0" id="discount" name="sale_price[]" min="0"  required>
														  
														</td>
													</tr>
												</tbody></table>														
											</td>
											<td>
												<input type="number" class="pr form-control positivenumber decimalnumber servicepriceafterdiscount sp_onchange quantity" name="quantity" id="price" placeholder="" value="0" min="0"> 
											
											</td>
										    <td>
												<input type="date" class="form-control " name="date[]"> 
											
											</td>
											 <td>
												<input type="text" class="form-control total" value="" name="total[]"> 
											</td>
											
											
										</tr>
										
										<tr id="addBefore">
											<td colspan="8"><button type="button" id="btnAdd" class="btn btn-success pull-right"><i class="fa fa-plus" aria-hidden="true"></i>Add product</button></td>
										</tr>
									</tbody>
								</table>
							</div>
							
							<div class="col-lg-12">
								<div class="table-responsive">
									<table id="myTable" class="table table-bordered">
									
										<tbody>
																							
											
											<tr>
												<td class="totals" colspan="7">Subtotal</td>
												<td><div id="sum" class="subtotal" style="display: inline;">INR 0</div>
												</td>
											</tr>
											
											<tr>
												<td class="" colspan="6">Discount</td>
												<td>
												    <input type="number" step="0.01" class="key1 form-control common commondiscount" name="discount" id="total_disc"  value="0" placeholder="Discount Amount">
												</td>
												<td>
													<select class="form-control total_disc_row_type common discounttype" name="discount_type" id="disc_row_type">
														
														<option value="1">INR</option>
														<option value="0">%</option>
													</select>
												</td>
											</tr>
											
											<tr>
												<td class="total" colspan="6">Taxes</td>
												<td colspan="2"><select name="tax" id="tax" data-validation="required" class="form-control common taxvalue">
													<option value="0">Select Taxes</option>
													<?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($tax->tax); ?>"><?php echo e($tax->tax); ?> %</option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													
													            
												</select></td>
											</tr>
											<!--<tr>
												<td colspan="4">Misc </td>
												<td colspan="2"><input id="misc" step="0.01" type="number" name="misc" value="0" class="form-control key1" value="0"></td>
											</tr>-->
											<tr>
												<td colspan="6">Shipping charges</td>
												<td colspan="3"><input type="number" step="0.01" id="ship" name="shipping" value="0" class="form-control key1 common shippingcharge" value="0"></td>
											</tr>
											
											<tr>
												<td colspan="6">Total charges</td>
												<td colspan="3"><input type="text" id="total" class="form-control total_charge" name="total_amount" placeholder="Total Amount" value="0" readonly=""></td>
											</tr>
											<tr>
												<td colspan="6">Amount paid</td>
												<td colspan="3"><input type="number" step="0.01" class="form-control k common paidamount" id="amount_paid" value="0" name="paid_amount" value="0" ></td>
											</tr>
											<tr>
												<td colspan="6">Payment mode </td>
												<td colspan="3">
    									            <select class="form-control" name="payment_mode">
    												    <option value="" >Select</option>
    												    <?php $__currentLoopData = $paymentmod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    													    <option value="<?php echo e($value->payment_method); ?>" ><?php echo e($value->payment_method); ?></option>
    												    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    											    </select>
												</td>
											</tr>
											<tr>
												<td colspan="6">
												    Amount due/credit
												</td>
												<td colspan="3">
												    <input type="text"  class="form-control gtotal" id="credit" name="due_amount" value="" >
												    <input type="hidden" id="installment_price" value="0"/>
												</td>
											</tr>
											<tr>
												<td colspan="8"><textarea name="description" class="form-control" rows="5" placeholder="Write notes about purchase here..." id="textArea"></textarea></td>
										</tr>
									</tbody>
								</table>

							</div>
						</div>
						<div class="clearfix"></div>
						<div class="col-sm-12">
							<button type="submit" name="submit" id="btnAdd" class="btn btn-success pull-right"><i class="fa fa-plus" aria-hidden="true"></i>Add stock</button>
						</div>
					</div>
				</div>
				</form>
			</div>
		</div>
		</div>
	</div>
			   
	</div>
</div>
</div>

<script>
      $("#btnAdd").bind("click", function() {
        	var empty_fields = [];
			$('.pro').each(function(){
				if($(this).val() == ''){
					empty_fields.push('empty_field');
					$(this).addClass('invalid');
				} else {
					$(this).removeClass('invalid');
				}
			});
			
	});



</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>
<script type="text/javascript">
var path = "<?php echo e(URL('autocomplete')); ?>";

$('input.typeahead').typeahead({

    source: function(query, process){

        return $.get(path, {query:query}, function(data){

            return process(data);

        });

    }

});
</script> 




<script>
    $("#btnAdd").bind("click", function() {
		var clonetr = $("#TextBoxContainer").clone().addClass('TextBoxContainer');
		clonetr.removeAttr('id');
		clonetr.find("table.add_row").remove();
		clonetr.find('.sno').html('<span class="fa fa-trash-o" style="color:red;" onclick="$(this).parent().parent().remove();"></span>');
		clonetr.find('input').val('');
		clonetr.find('.staff option[value=""]').prop('selected',true);
		$("#addBefore").before(clonetr); 
		//autocomplete_serr();
		$('.TextBoxContainer').last().children().find('.qt').removeAttr('readonly');
		$('.TextBoxContainer').last().children().find('.package_service_quantity').remove();
		$('.TextBoxContainer').last().children().find('.package_service_inv').remove();
		//change_event();
	});

</script>   


<script>
    $(document).on('change', '.productchange', function(){
    	    var product_id = $(this).val();
    	    let $this = $(this);
    	    
    	    $.ajax({
            type:'POST',
            dataType:'json',
            url:"<?php echo e(route('admin.productonchange')); ?>",
            data:{
                 product_id:product_id,
                _token:'<?php echo e(csrf_token()); ?>'
            },
            success:function(response){
                if(response.status){
                    $this.closest('.TextBoxContainer').find('.volume').val(response.volume);
                    $this.closest('.TextBoxContainer').find('.unit').val(response.unit);
                    $this.closest('.TextBoxContainer').find('.mrp').val(response.mrp);
                    $this.closest('.TextBoxContainer').find('.sale_price').val(response.mrp);
                    $this.closest('.TextBoxContainer').find('.price').val(response.mrp);
                    
                }
            }
        });
    	
    });
</script>   

<script>
    $(document).on('change', '.quantity', function(){
    	var quantity = $(this).val();
        var price = $(this).closest('.TextBoxContainer').find('.price').val();
        if(price >0){
           
            var total = parseInt(quantity*price);
            $(this).closest('.TextBoxContainer').find('.single_total').val(total);
            
            $(this).closest('.TextBoxContainer').find('.total').val(total);
             
            var count = 0;
            $(".single_total").each(function( index ) {
                count = parseInt(count) + parseInt($(this).val());
                $('.subtotal').text("INR "+count);
                $('.total_charge').val(count);
                $('.gtotal').val(count);
            });
        }

    });
</script>

<script>
    $(document).on('change', '.common', function(){

        var total_charge = $('.total_charge').val();
        var commondiscount = $('.commondiscount').val();
        var discounttype = $('.discounttype').val();
        var taxvalue = $('.taxvalue').val();
        var shippingcharge = $('.shippingcharge').val();
        var paidamount = $('.paidamount').val();
        
        if(total_charge > 0){
            
            if(discounttype == '1'){
                
                var total1 = parseInt(total_charge-commondiscount);
                if(taxvalue > 0){
                    var disper = taxvalue/100;
                    var totalper = total1 * disper;
                    var total2 = totalper + total1;
                }else{
                    var total2 = total1;
                }
                
                var total3 = total2+parseInt(shippingcharge);
                var gtotal = parseInt(total3)-parseInt(paidamount);
                
            }else if(discounttype =='0'){
                var commondiscountdisper = commondiscount/100;
                var per_discount = total_charge * commondiscountdisper;
                
                var total1 = parseInt(total_charge)-parseInt(per_discount);
                
                if(taxvalue > 0){
                    var disper = taxvalue/100;
                    var totalper = total1 * disper;
                    
                    var total2 = totalper + total1;
                }else{
                    var total2 = total1;
                }
                
                var total3 = parseInt(total2)+parseInt(shippingcharge);
                var gtotal = parseInt(total3)-parseInt(paidamount);
            }else{
               
                var total1 = total_charge;
                if(taxvalue > 0){
                    var disper = taxvalue/100;
                    var totalper = total1 * disper;
                    var total2 = totalper + total1;
                }else{
                    var total2 = total1;
                }
                
                
                var total3 = parseInt(total2)+parseInt(shippingcharge);
                var gtotal = parseInt(total3)-parseInt(paidamount);
            }
            $('.gtotal').val(gtotal);
        }
        

    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/add_stock.blade.php ENDPATH**/ ?>