
<?php $__env->startSection('page_title','EDIT AUTOMATIC SERVICE REMINDER'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Edit Autometic Service Reminder
            </div>
			     <div class="card-body">
				    <form method="POSt" action="auto_service_reminder_update" class="form-horizontal" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                         <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <input type="hidden" name="id" value="<?php echo e($service_reminder->id); ?>">
					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Service </label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" name="service" placeholder="Service" value="<?php echo e($service_reminder->service); ?>">
							  </div>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Interval days</label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control"  name="interval_days" placeholder="Interval days " value="<?php echo e($service_reminder->interval_days); ?>">
							  </div>
						  </div
						  </div>
						 
  
						    <div class="form-group row">
						  
						  
						    <label for="basic-input" class="col-sm-2 col-form-label">Message</label>
					  	  <div class="col-sm-4">
							<div class="input-group mb-3">
									<textarea class="form-control" name="message" id="" placeholder="Message"><?php echo e($service_reminder->message); ?></textarea>
							  </div>
						  </div>
						  
						  </div>
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtsdigital/p4.gts.digital/Gts_salon/resources/views/admin/servicereminder/edit.blade.php ENDPATH**/ ?>