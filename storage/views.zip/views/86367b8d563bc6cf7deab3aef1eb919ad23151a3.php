
<?php $__env->startSection('page_title','View Vendor'); ?>
<?php $__env->startSection('contant'); ?>


<style>

.active{
font-size: 14px;
background-image: linear-gradient(to right, rgb(218, 34, 255) 0%, rgb(151, 51, 238) 51%, rgb(218, 34, 255) 100%);

}


.inactive{
font-size: 14px;
background-image: linear-gradient(to right, rgb(255, 81, 47) 0%, rgb(240, 152, 25) 51%, rgb(255, 81, 47) 100%);
}


</style>

<div class="page-wrapper">
<div class="page-content">


<div class="col-sm-12">
<div class="container-fluid">
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header"><i class="fa fa-table"></i>View Vendor<a style="float: right;" class="btn btn-primary" href="product_vendor"><i class="fa fa-plus-circle" style="margin-right: 0;" aria-hidden="true"></i></a></div>
<div class="card-body">
<div class="table-responsive">


<table id="example2" class="table table-bordered" style="width:100%">
<thead>
<tr>
<th>Sr.No.</th>
<th>Vendor name</th>
<th>Contact</th>
<th>Email</th>
<th>Address</th>
<th>GST Number</th>
<th>Company details</th>
<th>Status</th>
<th>Action</th>

</tr>
</thead>
<tbody>

<?php $i=0;?>
<?php $__currentLoopData = $viewven; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $settingee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




<tr role="row" class="odd">
<td><?php $i++;?><?php echo e($i); ?></td>
<td><?php echo e($settingee->vendor_name); ?></td>
<td><?php echo e($settingee->contact); ?></td>
<td><?php echo e($settingee->email); ?></td>
<td><?php echo e($settingee->address); ?></td>
<td><?php echo e($settingee->gst_number); ?></td>
<td><?php echo e($settingee->company_details); ?></td>

<td><input type="checkbox" data-id="<?php echo e($settingee->id); ?>" name="Status" class="js-switch" <?php echo e($settingee->Status == 1 ? 'checked' : '0'); ?>></td>
<td>
      <?php $id= $settingee->id ;?>
    <a class="btn btn-primary" href="ven_update<?php echo e($id); ?>"><i class="fa fa-pencil"></i></a>
<a class="btn btn-danger" onclick="return confirm('Are you sure?')" href="ven_delete<?php echo e($id); ?>"><i class="fa fa-trash-o"></i></a>
</td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

</table>

<div class="d-flex justify-content-flex-end Pagination_1" >
<?php echo $viewven->links("pagination::bootstrap-4"); ?>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>


<script>let elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));

elems.forEach(function(html) {
let switchery = new Switchery(html,  { size: 'small' });
});</script>


<script>


$(document).ready(function(){
$('.js-switch').change(function () {
let status = $(this).prop('checked') === true ? 1 : 0;
let userId = $(this).data('id');
$.ajax({
type: "GET",
dataType: "json",
url: 'vendor.update.Status',
data: {'Status': status, 'id': userId},
success: function (data) {
alert(data.message);
}
});
});
});

</script>

<script>

success: function (data) {
toastr.options.closeButton = true;
toastr.options.closeMethod = 'fadeOut';
toastr.options.closeDuration = 100;
toastr.success(data.message);
}
</script>




<style>

.w-5 {
display: none;
}

.h-5{
display: none;
}

</style>


<?php $__env->stopSection(); ?>
<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtsdigital/public_html/Gts_salon/resources/views/admin/view_vender.blade.php ENDPATH**/ ?>