<?php $__env->startSection('page_title','ADD CLIENT'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Add CLIENT
</div>
			     <div class="card-body">
				    <form method="POSt" action="add_Client" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
 <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Client id <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('Client_id')); ?>" name="Client_id" placeholder="Client id" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['Client_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Client name <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('client_name')); ?>" name="client_name" placeholder="Client name" >
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Contact number <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e(old('Contact_number')); ?>" name="Contact_number" placeholder="Contact number" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['Contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Email <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="email" class="form-control" value="<?php echo e(old('email')); ?>" name="email" placeholder="Enter email" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Service <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('Service')); ?>" name="Service" placeholder="Enter Service" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['Service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						
						 

						  <label for="basic-input" class="col-sm-2 col-form-label">Source <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                                <select name="Source" class="form-control single-select">
                                    <option value="">--Select Option--</option>
                                    <option >Twitter</option>
                                    <option >Website</option>
                                    <option >Google</option>
                                    <option >Facebook</option>
                                </select> 
                            </div>
                                <p style="color:red;"><?php $__errorArgs = ['Source'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                            </div>


						  <label for="basic-input" class="col-sm-2 col-form-label">Assigned to <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
<select name="Assigned_to" class="form-control single-select">
<option value="">--Select Option--</option>
<option >Rakesh</option>
<option >Anil</option>
<option >Aman</option>
</select> 
</div>
<p style="color:red;"><?php $__errorArgs = ['Assigned_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>



						  	   <label for="basic-input" class="col-sm-2 col-form-label">Gender <span style="color:red;">*</span></label>
						  						  <div class="col-sm-4">
							<div class="input-group mb-3">
<select name="Gender" class="form-control single-select">
<option value="">--Select Option--</option>
<option value="1">Male</option>
<option value="0">Female</option>


</select> 
</div>
<p style="color:red;"><?php $__errorArgs = ['Gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>


						  	   <label for="basic-input" class="col-sm-2 col-form-label">Status <span style="color:red;">*</span></label>
						  						  <div class="col-sm-4">
							<div class="input-group mb-3">
<select name="Status" class="form-control single-select">
<option value="">--Select Option--</option>
<option value="1">Active</option>
<option value="0">Inactive</option>


</select> 
</div>
<p style="color:red;"><?php $__errorArgs = ['Status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
						  
						  
						  
						  </div>
						  
						  
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/add_Client.blade.php ENDPATH**/ ?>