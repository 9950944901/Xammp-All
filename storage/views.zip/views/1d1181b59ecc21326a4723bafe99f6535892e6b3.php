
<?php $__env->startSection('page_title','Received Pending Payments'); ?>
<?php $__env->startSection('contant'); ?>


<style>

.active{
font-size: 14px;
background-image: linear-gradient(to right, rgb(218, 34, 255) 0%, rgb(151, 51, 238) 51%, rgb(218, 34, 255) 100%);

}


.inactive{
font-size: 14px;
background-image: linear-gradient(to right, rgb(255, 81, 47) 0%, rgb(240, 152, 25) 51%, rgb(255, 81, 47) 100%);
}


</style>

<div class="page-wrapper form_wraper_icon">
<div class="page-content">


<div class="col-sm-12">
<div class="container-fluid">

<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header billing_re_gray">Received Pending Payments<a style="float: right; font-size:13px;" class="btn btn-primary" href="#"><i class="fa fa-file-excel-o mr-2" aria-hidden="true"></i>Export</a></div>

<div class="card-body">
<div class="table-responsive">


<table id="example2" class="table table-bordered" style="width:100%">
<thead>
<tr>
<th>Sr. no</th>
<th>Date</th>
<th>Invoice id</th>
<th>Client name</th>
<th>Contact number</th>
<th>Amount</th>
<th>Payment method</th>
<th>Action</th>
</tr>
</thead>
<tbody>
   
        <tr role="row" class="odd">
            <td>fdsgg</td>
            <td>gsdfgg</td>
            <td>gdsfggd</td>
            <td>gdfgsdfg</td>
            <td>gsdfgsdg</td>
            <td>dfgsdgs</td>
            <td>fdgsdg</td>
            <td><a href="#" class="btn btn-danger"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</a></td>
           
        </tr>

</tbody>

</table>

<div class="d-flex justify-content-flex-end Pagination_1" >

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>


<script>let elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));

elems.forEach(function(html) {
let switchery = new Switchery(html,  { size: 'small' });
});</script>


<script>


$(document).ready(function(){
$('.js-switch').change(function () {
let status = $(this).prop('checked') === true ? 1 : 0;
let userId = $(this).data('id');
$.ajax({
type: "GET",
dataType: "json",
url: 'vendor.update.Status',
data: {'Status': status, 'id': userId},
success: function (data) {
alert(data.message);
}
});
});
});

</script>

<script>

success: function (data) {
toastr.options.closeButton = true;
toastr.options.closeMethod = 'fadeOut';
toastr.options.closeDuration = 100;
toastr.success(data.message);
}
</script>




<style>

.w-5 {
display: none;
}

.h-5{
display: none;
}

</style>


<?php $__env->stopSection(); ?>
<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/recivied_pending_payment/recived_panding_payment.blade.php ENDPATH**/ ?>