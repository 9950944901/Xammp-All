<?php echo e($slot); ?>

<?php /**PATH /home/hypergroups/public_html/newlaravel/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>