<?php $__env->startSection('page_title','Child Categroy'); ?>
<?php $__env->startSection('contant'); ?>


<div class="page-wrapper">
<div class="page-content">

<div class="container-fluid">

<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header text-uppercase">Child Categroy</div>
<div class="card-body">
<form method="POST" action="add-childcategory" class="form-horizontal" enctype="multipart/form-data">
   
<?php echo csrf_field(); ?>
<div class="form-group row">

<label for="basic-input" class="col-sm-2 col-form-label">Select Categroy</label>
<div class="col-sm-4">
<div class="input-group mb-3">

<select class="form-select form-control mb-2 single-select " id="catagory" name="catagory" aria-label="Default select example" >
<option value="">--Select Categroy type--</option>
<?php $__currentLoopData = $categoryslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $settingees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option  value = "<?php echo e($settingees->id); ?>"><?php echo e($settingees->categroy); ?> </option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<p style="color:red;"><?php $__errorArgs = ['catagory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</select>
</div>
</div>





<label for="basic-input" class="col-sm-2 col-form-label">Sub Categroy</label>
<div class="col-sm-4">
<div class="input-group mb-3">
<select id="subcategory" class="form-control" name="subcategory"  >

<option value="">--Select Subcategroy type--</option>
</select>
</div>
<p style="color:red;"><?php $__errorArgs = ['subcategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>


</div>


<label for="basic-input" class="col-sm-2 col-form-label">Add Child Categroy</label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="text" class="form-control" value="<?php echo e(old('childcategroy')); ?>" name="childcategroy" placeholder="Child Categroy Name" >
</div>
<p style="color:red;"><?php $__errorArgs = ['childcategroy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>


<label for="basic-input" class="col-sm-2 col-form-label">Image</label>
<div class="col-sm-4">
<div class="input-group mb-3">

<input type="file" class="form-control" value="<?php echo e(old('image')); ?>" name="image" >
</div>
<p style="color:red;"><?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

						  <label for="basic-input" class="col-sm-2 col-form-label">Status</label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
<select name="status" class="form-control single-select">
<option value="">Select Status</option>
<option value="1">Active</option>
<option value="0">Inactive</option>
</select> 
</div>
<p style="color:red;"><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
<div class="form-group row">
<label for="basic-input" class="col-sm-2 col-form-label">Description</label>
<div class="col-sm-10">
<div class="input-group mb-3">

<textarea type="text" class="form-control"  name="editor" placeholder="Description" ><?php echo e(old('editor')); ?></textarea>
</div>
<p style="color:red;"><?php $__errorArgs = ['editor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
</div>



<p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
</div>
</form>

</div>
</div>
</div>
</div>
</div>
</div>
</div>

<?php $__env->startPush('footer_script'); ?>
<script type = "text/javascript">
	jQuery(document).ready(function(){
			jQuery('#catagory').change(function(){
				let cid=jQuery(this).val();
				jQuery.ajax({
					url:'getSubcat',
					type:'post',
					data:'cid='+cid+'&_token=<?php echo e(csrf_token()); ?>',
					success:function(result){

						jQuery('#subcategory').html(result)
					}
				});
			});
    });

</script>


<?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hypergroups/public_html/newlaravel/resources/views/admin/add-childcategory.blade.php ENDPATH**/ ?>