
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
<div class="page-content">

<div class="container-fluid">


<div class="row">

<div class="col-lg-12">
<div class="card">
<div class="row">

<div class="col-md-6"> <h5 class="card-header text-uppercase"> Product Details </h5></div>

<?php $__currentLoopData = $singal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card-body">

<div class="table-responsive">
<table class="table table-bordered">
<thead>
<tr>
<th>Categroy Name</th>
<td><?php echo e($list->categroy); ?></td>
</tr>
<tr>
<th>Subcategroy Name</th>
<td><?php echo e($list->sub_categroy); ?></td>
</tr>
<tr>
<th>Childcategroy Name</th>
<td><?php echo e($list->child_categroy); ?></td>
</tr>
<tr>
<th>Product Name</th>
<td><?php echo e($list->pro_name); ?></td>
</tr>

<tr>
<th>Product Image</th>
<td><a href="<?php echo e(('../uploads/product_images/product_single_img/'.$list->pro_img)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(('../uploads/product_images/product_single_img/'.$list->pro_img)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;">
</a></td>
</tr>

<tr>
<th>Product Images</th>
<td><?php $__currentLoopData = json_decode($list->pro_multi_img, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media_gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(url('/uploads/product_images/product_multi_img/'.$media_gallery)); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="<?php echo e(url('/uploads/product_images/product_multi_img/'.$media_gallery)); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 140px; height: 70px;">
</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
</tr>
<tr>

<th>Product MRP</th>
<td>₹<?php echo e($list->pro_mrp); ?></td>

</tr>
<tr>  
<th>Product Price</th>
<td>₹<?php echo e($list->pro_price); ?></td>

</tr>

<tr>  
<th>Product Url</th>
<td><?php echo e($list->pro_url); ?></td>

</tr>
<tr>  
<th>Product Discount</th>
<td><?php echo e($list->pro_discount); ?></td>

</tr>

<tr>  
<th>Product About</th>
<td><?php echo e($list->pro_about); ?></td>

</tr>



<tr>  
<th>Product Description</th>
<td><?php echo e($list->pro_description); ?></td>

</tr>

<tr>  
<th>Product Status</th>
<td>
<?php if($list['status']=='1'){?>

<small class="active">Active</small>
<?php } else{?>

<small class="inactive">Inactive</small>
<?php } ?>

</td>
</tr>
</thead>
</table>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</div>     
</div>
</div>  
</div>
</div>



<?php $__env->stopSection(); ?>




<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hypergroups/public_html/newlaravel/resources/views/admin/view-singal-product.blade.php ENDPATH**/ ?>