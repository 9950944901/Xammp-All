

<h1>locale_get_display_name</h1>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newlaravel\resources\views/login.blade.php ENDPATH**/ ?>