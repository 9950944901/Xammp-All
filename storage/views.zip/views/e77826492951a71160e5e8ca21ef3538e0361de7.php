
<?php $__env->startSection('page_title','ADD EXPENSE'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Add Expense
</div>
			     <div class="card-body">
				    <form method="POSt" action="add_expense" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
 <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Date <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control date" value="<?php echo e(old('date')); ?>" name="date" placeholder="Date" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Type of expense <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('type_of_expense')); ?>" name="type_of_expense" placeholder="Type of expense" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['type_of_expense'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Amount paid <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e(old('amount_paid')); ?>" name="amount_paid" placeholder="Enter Amount paid" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['amount_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Mode of payment <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
                        							<div class="input-group mb-3">
                        <select name="mode_of_payment" class="form-control single-select">
                        <option value="">--Select payment mode--</option>
                        <option value="1">Credit/Debit card</option> 
						<option value="2">Cash</option>
						<option value="3">Cheque</option> 
						<option value="4">Online payment</option> 
						<option value="5">Paytm</option> 
						<option value="6">Reward points</option> 
						<option value="7">PhonePe</option> 
						<option value="8">Gpay</option>
                        </select> 
                        </div>
                        <p style="color:red;"><?php $__errorArgs = ['mode_of_payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>
						  
						  
						  </div>
						 
  
						    <div class="form-group row">
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Recipient name</label>
					  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('recipient_name')); ?>" name="recipient_name" placeholder="Enter Recipient name" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['recipient_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						    <label for="basic-input" class="col-sm-2 col-form-label">Description <span style="color:red;">*</span></label>
					  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
									<!--<input class="result form-control" type="text" name="follow_date" id="" placeholder="Date">-->
									<textarea class="form-control" name="description" id="" placeholder="Description"></textarea>
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Status <span style="color:red;">*</span></label>
                            <div class="col-sm-4">
                            <div class="input-group mb-3">
                            <select name="Status" class="form-control single-select">
                            <option value="">--Select Option--</option>
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                            
                            
                            </select> 
                            </div>
                            <p style="color:red;"><?php $__errorArgs = ['Status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                            </div>
						  
						  
						  
						  </div>
						  
						   
						  
						  
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtsdigital/public_html/Gts_salon/resources/views/admin/add_expense.blade.php ENDPATH**/ ?>