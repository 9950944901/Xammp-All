<?php $__env->startSection('page_title','ADD ENQUIRY'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Add Enquiry
</div>
			     <div class="card-body">
				    <form method="POSt" action="add_enquiry" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
 <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Contact number <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e(old('contact_number')); ?>" name="contact_number" placeholder="Contact number" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Client name <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('client_name')); ?>" name="client_name" placeholder="Client name" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Email <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="email" class="form-control" value="<?php echo e(old('email')); ?>" name="email" placeholder="Enter email" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Address <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('address')); ?>" name="address" placeholder="Enter Address" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  </div>
						 
   <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Enquiry for <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
<select name="enquiry_for" class="form-control single-select">
<option value="">Select Option</option>
<option >Hair cut</option>
<option >Hair smothing</option>
<option >Advance Hair Cut</option>
</select> 
</div>
<p style="color:red;"><?php $__errorArgs = ['enquiry_for'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>


						  <label for="basic-input" class="col-sm-2 col-form-label">Enquiry Type <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
<select name="enquiry_type" class="form-control single-select">
<option value="">Select Option</option>
<option >cold</option>
<option >Hot</option>
<option >Warm</option>
</select> 
</div>
<p style="color:red;"><?php $__errorArgs = ['enquiry_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>


</div>
						    <div class="form-group row">
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Response</label>
					  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('response')); ?>" name="response" placeholder="Enter Response" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						    <label for="basic-input" class="col-sm-2 col-form-label">Date to follow <span style="color:red;">*</span></label>
					  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
									<input class="result form-control date" type="text" name="follow_date" id="" placeholder="Date">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['follow_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  	   <label for="basic-input" class="col-sm-2 col-form-label">Source of enquiry <span style="color:red;">*</span></label>
						  						  <div class="col-sm-4">
							<div class="input-group mb-3">
<select name="source_of_enquiry" class="form-control single-select">
<option value="">Select Option</option>
<option >Twitter</option>
<option >Website</option>
<option >Google</option>
<option >Facebook</option>

</select> 
</div>
<p style="color:red;"><?php $__errorArgs = ['source_of_enquiry'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

						  	   <label for="basic-input" class="col-sm-2 col-form-label">Lead representative</label>
						  						  <div class="col-sm-4">
							<div class="input-group mb-3">
<select name="lead_representative" class="form-control single-select">
<option value="">Select Option</option>
<option >Admin</option>
<option >Dummy</option>
<option >Demo</option>

</select> 
</div>
<p style="color:red;"><?php $__errorArgs = ['lead_representative'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>

						  	   <label for="basic-input" class="col-sm-2 col-form-label">Lead status <span style="color:red;">*</span></label>
						  						  <div class="col-sm-4">
							<div class="input-group mb-3">
<select name="lead_status" class="form-control single-select">
<option value="">Select Option</option>
<option value="2">Pending</option>
<option value="1">Converted</option>
<option value="0">Close</option>

</select> 
</div>
<p style="color:red;"><?php $__errorArgs = ['lead_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
						  
						  
						  
						  </div>
						  
						  
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtsdigital/public_html/Gts_salon/resources/views/admin/add_enquiry.blade.php ENDPATH**/ ?>