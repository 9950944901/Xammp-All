
<?php $__env->startSection('page_title','ADD PRODUCT'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Add PRODUCT
</div>
			     <div class="card-body">
				    <form method="POSt" action="product_list" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
 <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Product name<span style="color:red;">*</span></label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('pro_name')); ?>" name="pro_name" placeholder="Product name" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['pro_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">MRP<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e(old('mrp')); ?>" name="mrp" placeholder="MRP" >
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['mrp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Volume<span style="color:red;">*</span></label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                         								<input type="number" class="form-control" value="<?php echo e(old('volume')); ?>" name="volume" placeholder="Volume" >

                            </div>
                            <p style="color:red;"><?php $__errorArgs = ['volume'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                            </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Unit<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
<select class="form-control" name="unit">
    <option value="">--Select Volume--</option>
<option value="1">L</option>
<option value="2">ML</option>
<option value="3">MG</option>
<option value="4">Gram</option>
<option value="5">Pcs</option>
<option value="6">Pkt</option>

</select>							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Barcode</label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('barcode')); ?>" name="barcode" placeholder="Barcode " value="">
							  </div>
                              
						  </div>
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Reward points on purchase</label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e(old('reward_point')); ?>" name="reward_point" placeholder="Reward points on purchase" value="">
							  </div>
                            
						  </div>
						  
						  
						  </div>
						  
						  
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>

    
    <script>
   var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0');
    var yyyy = today.getFullYear();

    today = yyyy + '-' + mm + '-' + dd;
    $('#date_picker').attr('min',today);
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/add_product_list.blade.php ENDPATH**/ ?>