
<?php $__env->startSection('page_title','History'); ?>
<?php $__env->startSection('contant'); ?>
<style>
.btn_danger {
    padding: 4px 4px;
    margin-top: 0px;
    color: #fff;
    background-color: #fd3550;
    border-color: #fd3550;
}

    .btn_group{
        margin-top: 20px;
    }
    
    

</style>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-12">
<ul class="nav nav-tabs btn_group" id="myTab" role="tablist">
  <li class="nav-item" role="presentation">
    <button class="nav-link active" id="appointment-tab" data-bs-toggle="tab" data-bs-target="#appointment" type="button" role="tab" aria-controls="appointment" aria-selected="true">Appointment</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="billing-tab" data-bs-toggle="tab" data-bs-target="#billing" type="button" role="tab" aria-controls="billing" aria-selected="false">Billing</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="wallet-tab" data-bs-toggle="tab" data-bs-target="#wallet" type="button" role="tab" aria-controls="wallet" aria-selected="false">Wallet</button>
  </li>
</ul>
<div class="tab-content" id="myTabContent">
  <div class="tab-pane fade show active" id="appointment" role="tabpanel" aria-labelledby="appointment-tab">
      
      
    <div class="page-wrapper form_wraper_icon">
<div class="page-content">
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header billing_re_gray">Appointment history<a style="float: right; font-size:13px;" class="btn btn-primary" href="#"><i class="fa fa-file-excel-o mr-2" aria-hidden="true"></i>Export</a></div>

<div class="card-body">
<div class="table-responsive">


<table id="example2" class="table table-bordered" style="width:100%">
<thead>
<tr>
<th>Date of appointment</th>
<th>Date of booking</th>
<th>Client name</th>
<th>Number</th>
<th>Amount</th>
<th>Paid</th>
<th>Pending</th>
<th>Notes</th>
<th>Payment mode</th>
<th>Services</th>
<th>Providers</th>
<th>Action</th>
</tr>
</thead>
<tbody>
   
        <tr role="row" class="odd">
            <td>02-06-2022</td>
            <td>02-06-2022</td>
            <td>Senthilkumar</td>
            <td>9847269128</td>
            <td>	-9.00</td>
            <td>0.00</td>
            <td>0.00</td>
            <td></td>
            <td></td>
             <td>Keratin Hair Mask</td>
              <td>ABC122</td>
              <td><a href="appointment.php?id=113" class=""><button type="button" class="btn btn-xs btn-warning"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit</button></a>
            
            <a href="#" class="btn btn-xs btn_danger"><i class="fa fa-trash-o trash" aria-hidden="true"></i> Delete</a></td>
           
        </tr>
<tr role="row" class="odd">
            <td>02-06-2022</td>
            <td>02-06-2022</td>
            <td>Senthilkumar</td>
            <td>9847269128</td>
            <td>	-9.00</td>
            <td>0.00</td>
            <td>0.00</td>
            <td></td>
            <td></td>
             <td>Keratin Hair Mask</td>
              <td>ABC122</td>
              <td><a href="appointment.php?id=113" class=""><button type="button" class="btn btn-xs btn-warning"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit</button></a>
        
            <a href="#" class="btn btn-xs btn_danger"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</a></td>
           
        </tr>



</tbody>

</table>

<div class="d-flex justify-content-flex-end Pagination_1" >

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
  </div>
  <div class="tab-pane fade" id="billing" role="tabpanel" aria-labelledby="billing-tab"><div class="page-wrapper form_wraper_icon">
<div class="page-content">
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header billing_re_gray">Billing<a style="float: right; font-size:13px;" class="btn btn-primary" href="#"><i class="fa fa-file-excel-o mr-2" aria-hidden="true"></i>Export</a></div>

<div class="card-body">
<div class="table-responsive">


<div id="example2_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer"><div class="row"><div class="col-sm-12 col-md-6"><div class="dt-buttons btn-group">      <button class="btn btn-outline-secondary buttons-copy buttons-html5" tabindex="0" aria-controls="example2" type="button"><span>Copy</span></button> <button class="btn btn-outline-secondary buttons-excel buttons-html5" tabindex="0" aria-controls="example2" type="button"><span>Excel</span></button> <button class="btn btn-outline-secondary buttons-pdf buttons-html5" tabindex="0" aria-controls="example2" type="button"><span>PDF</span></button> <button class="btn btn-outline-secondary buttons-print" tabindex="0" aria-controls="example2" type="button"><span>Print</span></button> </div></div><div class="col-sm-12 col-md-6"><div id="example2_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control form-control-sm" placeholder="" aria-controls="example2"></label></div></div></div><div class="row"><div class="col-sm-12"><table id="example2" class="table table-bordered dataTable no-footer" style="width:100%" role="grid" aria-describedby="example2_info">
<thead>
<tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Date of appointment: activate to sort column descending" style="width: 128.609px;">Date of appointment</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Date of booking: activate to sort column ascending" style="width: 99.6406px;">Date of booking</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Client name: activate to sort column ascending" style="width: 74.9531px;">Client name</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Number: activate to sort column ascending" style="width: 56px;">Number</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Amount: activate to sort column ascending" style="width: 48.8438px;">Amount</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Paid: activate to sort column ascending" style="width: 27.9375px;">Paid</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Pending: activate to sort column ascending" style="width: 51.2031px;">Pending</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Notes: activate to sort column ascending" style="width: 37.1406px;">Notes</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Payment mode: activate to sort column ascending" style="width: 93.625px;">Payment mode</th><th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Services: activate to sort column ascending" style="width: 89.2188px;">Services</th>
</tr>
</thead>
<tbody>
   
        




<tr role="row" class="odd">
            <td class="sorting_1">02-06-2022</td>
            <td>02-06-2022</td>
            <td>Senthilkumar</td>
            <td>9847269128</td>
            <td>	-9.00</td>
            <td>0.00</td>
            <td>0.00</td>
            <td></td>
            <td></td>
             <td>Keratin Hair Mask</td>
             
        </tr><tr role="row" class="even">
            <td class="sorting_1">02-06-2022</td>
            <td>02-06-2022</td>
            <td>Senthilkumar</td>
            <td>9847269128</td>
            <td>	-9.00</td>
            <td>0.00</td>
            <td>0.00</td>
            <td></td>
            <td></td>
             <td>Keratin Hair Mask</td>
        </tr></tbody>

</table></div></div><div class="row"><div class="col-sm-12 col-md-5"><div class="dataTables_info" id="example2_info" role="status" aria-live="polite">Showing 1 to 2 of 2 entries</div></div><div class="col-sm-12 col-md-7"><div class="dataTables_paginate paging_simple_numbers" id="example2_paginate"><ul class="pagination"><li class="paginate_button page-item previous disabled" id="example2_previous"><a href="#" aria-controls="example2" data-dt-idx="0" tabindex="0" class="page-link">Prev</a></li><li class="paginate_button page-item active"><a href="#" aria-controls="example2" data-dt-idx="1" tabindex="0" class="page-link">1</a></li><li class="paginate_button page-item next disabled" id="example2_next"><a href="#" aria-controls="example2" data-dt-idx="2" tabindex="0" class="page-link">Next</a></li></ul></div></div></div></div>

<div class="d-flex justify-content-flex-end Pagination_1">

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div></div>
  <div class="tab-pane fade" id="wallet" role="tabpanel" aria-labelledby="wallet-tab"><div class="page-wrapper form_wraper_icon">
<div class="page-content">
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header billing_re_gray">Client's wallet<a style="float: right; font-size:13px;" class="btn btn-primary" href="#"><i class="fa fa-file-excel-o mr-2" aria-hidden="true"></i>Export</a></div>

<div class="card-body">
<div class="table-responsive">


<div id="example2_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer"><div class="row"><div class="col-sm-12 col-md-6"><div class="dt-buttons btn-group">      <button class="btn btn-outline-secondary buttons-copy buttons-html5" tabindex="0" aria-controls="example2" type="button"><span>Copy</span></button> <button class="btn btn-outline-secondary buttons-excel buttons-html5" tabindex="0" aria-controls="example2" type="button"><span>Excel</span></button> <button class="btn btn-outline-secondary buttons-pdf buttons-html5" tabindex="0" aria-controls="example2" type="button"><span>PDF</span></button> <button class="btn btn-outline-secondary buttons-print" tabindex="0" aria-controls="example2" type="button"><span>Print</span></button> </div></div><div class="col-sm-12 col-md-6"><div id="example2_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control form-control-sm" placeholder="" aria-controls="example2"></label></div></div></div><div class="row"><div class="col-sm-12"><table id="example2" class="table table-bordered dataTable no-footer" style="width: 100%;" role="grid" aria-describedby="example2_info">
<thead>
<tr role="row">
    <th class="sorting_asc" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Date of appointment: activate to sort column descending" style="width: 129px;">Date</th>
    <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Date of booking: activate to sort column ascending" style="width: 100px;">Client name</th>
    <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Client name: activate to sort column ascending" style="width: 75px;">Contact number</th>
    <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Number: activate to sort column ascending" style="width: 56px;">Wallet amount</th>
<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Action: activate to sort column ascending" style="width: 75px;">Action</th></tr>
</thead>
<tbody>
   
        




<tr role="row" class="odd">
            <td class="sorting_1">02-06-2022</td>
            <td>kash</td>
            <td>8787282452</td>
            <td>15,100.00</td>
              <td><a href="appointment.php?id=113" class=""><button type="button" class="btn btn-xs btn-warning">View history</button></a>
            <a href="#" class="btn btn_danger"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</a></td>
           
        </tr><tr role="row" class="even">
            <td class="sorting_1">02-06-2022</td>
            <td>kash</td>
            <td>8787282452</td>
            <td>15,100.00</td>
              <td><a href="appointment.php?id=113" class=""><button type="button" class="btn btn-xs btn-warning">View history</button></a>
            <a href="#" class="btn btn_danger"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</a></td>
           
        </tr></tbody>

</table>
</div>
</div>
<div class="row">
    <div class="col-sm-12 col-md-5">
        <div class="dataTables_info" id="example2_info" role="status" aria-live="polite">Showing 1 to 2 of 2 entries</div>
        </div>
        <div class="col-sm-12 col-md-7"><div class="dataTables_paginate paging_simple_numbers" id="example2_paginate"><ul class="pagination"><li class="paginate_button page-item previous disabled" id="example2_previous"><a href="#" aria-controls="example2" data-dt-idx="0" tabindex="0" class="page-link">Prev</a></li><li class="paginate_button page-item active"><a href="#" aria-controls="example2" data-dt-idx="1" tabindex="0" class="page-link">1</a></li><li class="paginate_button page-item next disabled" id="example2_next"><a href="#" aria-controls="example2" data-dt-idx="2" tabindex="0" class="page-link">Next</a></li></ul></div></div></div></div>

<div class="d-flex justify-content-flex-end Pagination_1">

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div></div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/history/history.blade.php ENDPATH**/ ?>