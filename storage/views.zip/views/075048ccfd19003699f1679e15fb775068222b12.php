<?php $__env->startSection('page_title','Categroy'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Categroy</div>
			     <div class="card-body">
				    <form method="POSt" action="addcategroy" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Add Categroy</label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('categroy')); ?>" name="categroy" placeholder="categroy name" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['categroy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Image</label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="file" class="form-control" value="<?php echo e(old('image')); ?>" name="image" placeholder="categroy name" value="">
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  </div>
						 
   <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Status</label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
<select name="status" class="form-control single-select">
<option value="">Select Status</option>
<option value="1">Active</option>
<option value="0">Inactive</option>
</select> 
</div>
<p style="color:red;"><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
</div>
						    <div class="form-group row">
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Description</label>
						  	  <div class="col-sm-10">
							<div class="input-group mb-3">
                            
								<textarea type="text" class="form-control" value="<?php echo e(old('editor')); ?>" name="editor" placeholder="Description" value=""></textarea>
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['editor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  </div>
						  
<!--						  <div class="form-group row">-->
<!--<label for="basic-input" class="col-sm-5 col-form-label"> Status</label>-->
<!--<div class="col-sm-7">-->
<!--<div class="row">-->
<!--<div class="icheck-primary col-md-6">-->
<!--<input type="radio" id="primary" name="status" value="1"  checked=checked >-->
<!--<label for="primary">Active</label>-->
<!--</div>-->

<!--<div class="icheck-primary col-md-6">-->
<!--<input type="radio" id="primary1" name="status" value="0"   >-->
<!--<label for="primary1">Inactive</label>-->
<!--</div>-->
<!--</div>-->

<!--</div>-->
<!--</div>-->
						  
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hypergroups/public_html/newlaravel/resources/views/admin/add-category.blade.php ENDPATH**/ ?>