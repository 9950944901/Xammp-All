<?php $__env->startSection('page_title','ADD ENQUIRY'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Add Enquiry
</div>
			     <div class="card-body">
				    <form method="POSt" action="add_enquiry" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
 <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					    <div class="panel">
						<div class="panel-heading">
							<h4>Purchase from vendor / add stock</h4>
						</div>
						<div class="panel-body">
							<div class="row">
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 w-20">
								<div class="form-group">
									<label for="vendor">Product vendor name <span class="text-danger">*</span></label>
									<input type="text" class="form-control typeahead" id="vendor" name="vendor" value="" placeholder="Product vendor name" required>
									<input type="hidden" name="vendor_id" id="vendorid" value="" class="clt">
								</div>
							</div>
							
							<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12 w-20">
								<div class="form-group">
									<label for="contact_no">Contact no <span class="text-danger">*</span></label>
									<input type="text" class="form-control" id="contact_no" name="contact_no" value="" placeholder="Contact no" required>
								</div>
							</div>
							
							<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12 w-20">
								<div class="form-group">
									<label for="gst_no">GST number</label>
									<input type="text" class="form-control" id="gst_no" name="gst_no" value="" placeholder="GST">
								</div>
							</div>
							
							
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 w-20">
								<div class="form-group inv_no">
									<label for="inv">Invoice give by vendor <span class="text-danger">*</span></label>
									<input type="text" class="form-control" name="inv" placeholder="Invoice no" value="" onblur="checkinvoice_no(this.value, '')" required>
									<span class="text-danger"></span>
								</div>
							</div>
							
							<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12 w-20">
								<div class="form-group">
																		<label for="dop">Date of purchase <span class="text-danger">*</span></label>
																		<input type="text" class="form-control dob_annv_date" value="2022-05-10" name="dop"  value="" required>
									
								</div>
							</div>
							
							
							
							<div class="clearfix"></div>
							
							<div class="col-lg-12" style="margin-top:16px;">
								<div class="table-responsive">
									<table id="myTable" class="table table-bordered">
										<thead>
											<tr>
												<th style="width:3%"></th>
												<th style="width:40%">Product</th>
												<th style="width:10%">MRP</th> <!-- MRP price -->
												<th style="width:10%">Price</th> <!-- purchcase price -->
												<th style="width:10%">Sale price</th>
												<th style="width:5%">Quantity</th>
												<th style="width: 12%">Exp. date</th>
												<th style="width:10%">Total</th>
											</tr>
										</thead>
										<tbody>
																							
												<tr id="TextBoxContainer" class="TextBoxContainer">
													<td style="vertical-align: middle;"><span class="sno"><span class="fa fa-ellipsis-v"></span></span></td>
													<td>
														
														<table class="inner-table-space">
															
															<tr>
																<td width="40%">
																	
																	<input type="text" name="product[]" class="pro form-control" placeholder="Product " required>
																	<input type="hidden" name="product_id[]" class="product_id" >
																	<input type="hidden" name="barcode[]" class="barcode form-control" value="" placeholder="barcode" required>
																	<span class="serviceErrorMessage"></span>
																</td>
																<td width="20%">				
																<input type="number" name="volume[]" class="qt form-control vol" placeholder="Volume" required></td>
																<td width="10%">	
																	
																	<!--<input class="auto form-control" type="text" name="unit" id="u_unit" placeholder="Unit" value="" required>
																	<input type="hidden" name="unit_id" id="unit_id">	-->
																	<select class="form-control v_unit vu " name="volume_unit[]">
																		
																																					<option  value="1" >L</option>
																																						<option  value="2" >ML</option>
																																						<option  value="3" >MG</option>
																																						<option  value="4" >Gram</option>
																																						<option  value="5" >Pcs</option>
																																						<option  value="6" >Pkt</option>
																																					
																	</select>
																</td>
																
																<!-- <td width="10%"> <i class="icon-straighten" style="font-size:32px;"></i></td> -->
															</tr>
															
														</table>
														<span class="check-status" style="font-size: 7pt"></span>
													</td>
													<td><input type="number" step="0.01" name="mrp_price[]" class="form-control price key mrp" placeholder="0.00" required></td>
													<td><input type="number" step="0.01" name="purchase_price[]" class="form-control price key purchase_price"  placeholder="0.00" value="0.00" required></td>
													<td><input type="number" step="0.01" name="sale_price[]" value="0.00" class="form-control price key sale_price" onblur="cmpsalewithmrp($(this))" placeholder="0.00" required></td>
													<td><input type="number" class="form-control qty  key" name="quantity[]" placeholder="0.00" value="1" min="0" required></td>
													<td><input type="text" value="2023-04-10" name="exp_date[]" class="form-control urdate" value="" required readonly></td>
													<td><input type="text" class="form-control subtotal key" name="total_price[]" placeholder="0.00" value="0" readonly></td>
												</tr>
																						<tr id="addBefore">
												<td colspan="8"><button type="button" id="btnAdd" class="btn btn-success pull-right"><i class="fa fa-plus" aria-hidden="true"></i>Add product</button></td>
											</tr>
											
											<tr>
												<td class="total" colspan="7">Subtotal</td>
												<td><div id="sum" style="display: inline;">0</div>
												<input type="hidden" id="sum2" value="0" name="subtotal"></td>
											</tr>
											
											<tr>
												<td class="total" colspan="6">Discount</td>
												<td width="40%">
												<input type="number" step="0.01" class="key1 form-control" name="dis" id="total_disc"  value="0" placeholder="Discount Amount"></td>
												<td width="60%">
													<select class="form-control total_disc_row_type" name="total_disc_row_type" id="disc_row_type">
														<option value="0">%</option>
														<option value="1">INR</option>
													</select>
												</td>
											</tr>
											
											<tr>
												<td class="total" colspan="6">Taxes</td>
												<td colspan="2"><select name="tax" id="tax" data-validation="required" class="form-control">
													<option value="0,0,3">Select Taxes</option>
													<optgroup label="Inclusive Taxes">
																													<option value="2,18,0">Gst on Products(18)</option>
																													<option value="1,18,0">Gst on Service(18)</option>
																											</optgroup>
													<optgroup label="Exclusive Taxes">
																													<option value="2,18,1">Gst on Products(18)</option>
																													<option value="1,18,1">Gst on Service(18)</option>
																											</optgroup>              
												</select></td>
											</tr>
											<!--<tr>
												<td colspan="4">Misc </td>
												<td colspan="2"><input id="misc" step="0.01" type="number" name="misc" value="0" class="form-control key1" value="0"></td>
											</tr>-->
											<tr>
												<td colspan="6">Shipping charges</td>
												<td colspan="3"><input type="number" step="0.01" id="ship" name="ship" value="0" class="form-control key1" value="0"></td>
											</tr>
											
											<tr>
												<td colspan="6">Total charges</td>
												<td colspan="3"><input type="text" id="total" class="form-control" name="total" placeholder="Total Amount" value="0" readonly=""></td>
											</tr>
											<tr>
												<td colspan="6">Amount paid</td>
												<td colspan="3"><input type="number" step="0.01" class="form-control k" id="amount_paid" value="0" name="amount_paid" value="0" ></td>
											</tr>
											<tr>
												<td colspan="6">Payment mode </td>
												<td colspan="3">
																										<select class="form-control" name="paymode">
																													<option value="1" >Cash</option>
																														<option value="3" >Credit/Debit card</option>
																														<option value="4" >Cheque</option>
																														<option value="5" >Online payment</option>
																														<option value="6" >Paytm</option>
																														<option value="10" >PhonePe</option>
																														<option value="11" >Gpay</option>
																												</select>
												</td>
											</tr>
											<tr>
												<td colspan="6">
												    Amount due/credit
												    												</td>
												<td colspan="3">
												    												        <input type="text"  class="form-control" id="credit" name="credit" value="" >
												        <input type="hidden" id="installment_price" value="0" />
												    												</td>
											</tr>
											<tr>
												<td colspan="8"><textarea name="detail" class="form-control" rows="5" placeholder="Write notes about purchase here..." id="textArea"></textarea></td>
										</tr>
									</tbody>
								</table>

							</div>
						</div>
						<div class="clearfix"></div>
						<div class="col-sm-12">
															<button type="submit" name="submit" id="btnAdd" class="btn btn-success pull-right"><i class="fa fa-plus" aria-hidden="true"></i>Add stock</button>
													</div>
					</div>
				</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>

<script>
      $("#btnAdd").bind("click", function() {
        	var empty_fields = [];
			$('.pro').each(function(){
				if($(this).val() == ''){
					empty_fields.push('empty_field');
					$(this).addClass('invalid');
				} else {
					$(this).removeClass('invalid');
				}
			});
			
	});



</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>
<script type="text/javascript">
var path = "<?php echo e(URL('autocomplete')); ?>";

$('input.typeahead').typeahead({

    source: function(query, process){

        return $.get(path, {query:query}, function(data){

            return process(data);

        });

    }

});
</script> 
    
    
    <script>
        $("#btnAdd").bind("click", function() {
      var clonetr = $("#TextBoxContainer").clone().addClass('TextBoxContainer');
      clonetr.removeAttr('id');
      clonetr.find("table.add_row").remove();
      clonetr.find('.sno').html('<span class="fa fa-trash-o" style="color:red;" onclick="$(this).parent().parent().remove();"></span>');
      clonetr.find('input').val('');
      clonetr.find('.staff option[value=""]').prop('selected',true);
      $("#addBefore").before(clonetr);
      autocomplete_serr();
      $('.TextBoxContainer').last().children().find('.qt').removeAttr('readonly');
      $('.TextBoxContainer').last().children().find('.package_service_quantity').remove();
      $('.TextBoxContainer').last().children().find('.package_service_inv').remove();
      change_event();
  });
   
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtsdigital/p4.gts.digital/Gts_salon/resources/views/admin/add_stock.blade.php ENDPATH**/ ?>