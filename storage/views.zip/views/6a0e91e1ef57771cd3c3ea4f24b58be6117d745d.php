
<?php $__env->startSection('page_title','Advanced Reports'); ?>
<?php $__env->startSection('contant'); ?>


<div class="container-fluid">
    <div class="dashboard-wrapper">
	
	<!-- Main container starts -->
	<div class="main-container">
		<!-- Row starts -->
		<div class="row gutter">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="panel">

					<div class="panel-heading">
						<h3 id="payment_mode" class="pull-left"> Sales Report</h3>
					    <div class="clearfix"></div>
					</div>
					<div class="panel-body">					
						<div class="row">
                            <br>
							<div class="col-lg-12">
								
								<div id="fetch_sales_report">  
    <style>
    
    #payment_mode{
            padding: 25px 0;
    }
    
        #tr{
            border-top:hidden !important;
        }
        .text-right{
            color: #0f9e02 !important;
        }
    </style>
    <div class="row">
        <div class="col-lg-12 col-md-12-col-xs-12 col-sm-12"><div class="row">
            <div class="col-lg-4 col-md-4 col-xs-12 col-sm-12">
                <div class="card sales-card">
                    <div class="card-header" style="background:#f8f4f4 !important;padding: 10px;"><center><h6>Daily Sales</h6></center></div>
                    <div class="card-body" style="background:#fff !important;">
                        <table class="table tbl responsive">
                                                                    <tbody><tr id="tr">
                                            <td class="text-left">Cash </td>
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                6,800.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Credit/Debit card </td>
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                560.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Cheque </td>
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                0.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Online payment </td>
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                0.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Paytm </td>
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                0.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">E-wallet </td>
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                1,500.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Reward points </td>
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                0.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">PhonePe </td>
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                0.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Gpay </td>
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                200.00</td>
                                        </tr>
                                                                <tr>
                                <td class="text-left"><h6>Total</h6></td>
                                <td class="text-right">
                                    <strong><span style="font-size:15px;margin-right:0px;">₹</span> 9,060.00</strong>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                    
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-xs-12 col-sm-12">
                <div class="card sales-card">
                    <div class="card-header" style="background:#f8f4f4 !important;padding: 10px;"><center><h6>Monthly Sales</h6></center></div>
                    <div class="card-body" style="background:#fff !important;">
                        <table class="table tbl responsive">
                                                                    <tbody><tr id="tr">
                                            <td class="text-left">Cash </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                37,005.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Credit/Debit card </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                3,939.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Cheque </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                0.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Online payment </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                500.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Paytm </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                345.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">E-wallet </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                11,400.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Reward points </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                13,161.50</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">PhonePe </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                0.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Gpay </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                914.00</td>
                                        </tr>
                                                                <tr>
                                <td class="text-left"><h6>Total</h6></td>
                                <td class="text-right">
                                    <strong><span style="font-size:15px;margin-right:0px;">₹</span> 67,264.50</strong>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                    
                </div>
            </div>           
            <div class="col-lg-4 col-md-4 col-xs-12 col-sm-12">
                <div class="card sales-card">
                    <div class="card-header" style="background:#f8f4f4 !important;padding: 10px;"><center><h6>Yearly Sales</h6></center></div>
                    <div class="card-body" style="background:#fff !important;">
                        <table class="table tbl responsive">
                                                                    <tbody><tr id="tr">
                                            <td class="text-left">Cash </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                1,324,814.98</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Credit/Debit card </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                99,122.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Cheque </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                9,980.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Online payment </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                85,338.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Paytm </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                69,548.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">E-wallet </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                127,821.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Reward points </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                19,006.90</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">PhonePe </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                29,561.00</td>
                                        </tr>
                                                                            <tr id="tr">
                                            <td class="text-left">Gpay </td>
            
                                            <td class="text-right">
                                                <span style="font-size:13px;margin-right:0px;">₹</span>
                                                214,443.00</td>
                                        </tr>
                                                                <tr>
                                <td class="text-left"><h6>Total</h6></td>
                                <td class="text-right">
                                   <strong><span style="font-size:15px;margin-right:0px;">₹</span> 1,979,634.88</strong>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                    
                </div>
            </div></div>
        </div>
    </div>
    <br><br>

    <div class="row">
        <div class="col-sm-12 col-lg-12 col-md-4 col-xs-12"><div class="row">
            <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
                <div class="card sales-card">
                    <div class="card-header" style="background:#f8f4f4 !important;padding: 10px;"><center><h6>Daily Wallet Recharge</h6></center></div>
                    <div class="card-body" style="background:#fff !important;">
                        <table class="table tbl responsive">
                            <tbody><tr id="tr"><td class="text-left">Cash</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 0.00</td></tr><tr id="tr"><td class="text-left">Credit/Debit card</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 5,000.00</td></tr><tr id="tr"><td class="text-left">Cheque</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 0.00</td></tr><tr id="tr"><td class="text-left">Online payment</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 0.00</td></tr><tr id="tr"><td class="text-left">Paytm</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 0.00</td></tr><tr id="tr"><td class="text-left">E-wallet</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 0.00</td></tr><tr id="tr"><td class="text-left">Reward points</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 0.00</td></tr><tr id="tr"><td class="text-left">PhonePe</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 0.00</td></tr><tr id="tr"><td class="text-left">Gpay</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 0.00</td></tr>                            <tr><td class="text-left"><h6>Total</h6></td><td class="text-right"><strong><span style="font-size:15px;margin-right:0px;">₹</span> 5,000.00</strong></td></tr>
                        </tbody></table>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
                <div class="card sales-card">
                    <div class="card-header" style="background:#f8f4f4 !important;padding: 10px;"><center><h6>Monthly Wallet Recharge</h6></center></div>
                    <div class="card-body" style="background:#fff !important;">
                        <table class="table tbl responsive">
                            <tbody><tr id="tr"><td class="text-left">Cash</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 7,000.00</td></tr><tr id="tr"><td class="text-left">Credit/Debit card</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 5,000.00</td></tr><tr id="tr"><td class="text-left">Cheque</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 0.00</td></tr><tr id="tr"><td class="text-left">Online payment</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 0.00</td></tr><tr id="tr"><td class="text-left">Paytm</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 0.00</td></tr><tr id="tr"><td class="text-left">E-wallet</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 0.00</td></tr><tr id="tr"><td class="text-left">Reward points</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 0.00</td></tr><tr id="tr"><td class="text-left">PhonePe</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 0.00</td></tr><tr id="tr"><td class="text-left">Gpay</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px;">₹</span> 0.00</td></tr>                            <tr><td class="text-left"><h6>Total</h6></td><td class="text-right"><strong><span style="font-size:15px;margin-right:0px;">₹</span> 12,000.00</strong></td></tr>
                        </tbody></table>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
                <div class="card sales-card">
                    <div class="card-header" style="background:#f8f4f4 !important;padding: 10px;"><center><h6>Yearly Wallet Recharge</h6></center></div>
                    <div class="card-body" style="background:#fff !important;">
                        <table class="table tbl responsive">
                            <tbody><tr id="tr"><td class="text-left">Cash</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px">₹</span>208,900.00</td></tr><tr id="tr"><td class="text-left">Credit/Debit card</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px">₹</span>30,500.00</td></tr><tr id="tr"><td class="text-left">Cheque</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px">₹</span>5,000.00</td></tr><tr id="tr"><td class="text-left">Online payment</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px">₹</span>55,000.00</td></tr><tr id="tr"><td class="text-left">Paytm</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px">₹</span>10,000.00</td></tr><tr id="tr"><td class="text-left">E-wallet</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px">₹</span>0.00</td></tr><tr id="tr"><td class="text-left">Reward points</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px">₹</span>0.00</td></tr><tr id="tr"><td class="text-left">PhonePe</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px">₹</span>500.00</td></tr><tr id="tr"><td class="text-left">Gpay</td><td class="text-right">
                                    <span style="font-size:13px;margin-right:0px">₹</span>33,010.00</td></tr>                            <tr><td class="text-left"><h6>Total</h6></td><td class="text-right"><strong><span style="font-size:15px;margin-right:0px;">₹</span> 342,910.00</strong></td></tr>
                        </tbody></table>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div><br><br>
    <div class="">
    <div class="row">
        <div class="col-lg-12">
                            
        </div>
    </div>
    <div class="row">
        <div class="col-lg-8">
            <div id="chartContainer" style="height: 300px; width: 100%;"><div class="canvasjs-chart-container" style="position: relative; text-align: left; cursor: auto; direction: ltr;"><canvas class="canvasjs-chart-canvas" width="805" height="300" style="position: absolute; user-select: none;"></canvas><canvas class="canvasjs-chart-canvas" width="805" height="300" style="position: absolute; -webkit-tap-highlight-color: transparent; user-select: none; cursor: default;"></canvas><div class="canvasjs-chart-toolbar" style="position: absolute; right: 1px; top: 1px; border: 1px solid transparent;"><button state="menu" type="button" title="More Options" style="background-color: white; color: black; border: none; user-select: none; padding: 5px 12px; cursor: pointer; float: left; width: 40px; height: 25px; outline: 0px; vertical-align: baseline; line-height: 0;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAeCAYAAABE4bxTAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADoSURBVFhH7dc9CsJAFATgRxIIBCwCqZKATX5sbawsY2MvWOtF9AB6AU8gguAJbD2AnZ2VXQT/Ko2TYGCL2OYtYQc+BuYA+1hCtnCVwMm27SGaXpDJIAiCvCkVR05hGOZNN3HkFMdx3nQRR06+76/R1IcFLJlNQEWlmWlBTwJtKLKHynehZqnjOGM0PYWRVXk61C37p7xlZ3Hk5HneCk1dmMH811xGoKLSzDiQwIBZB4ocoPJdqNkDt2yKlueWRVGUtzy3rPwo3sWRU3nLjuLI6OO67oZM00wMw3hrmpZx0XU9syxrR0T0BeMpb9dneSR2AAAAAElFTkSuQmCC" alt="More Options" style="height: 95%; pointer-events: none; filter: invert(0%);"></button><div tabindex="-1" style="position: absolute; z-index: 1; user-select: none; cursor: pointer; right: 0px; top: 25px; min-width: 120px; outline: 0px; font-size: 14px; font-family: Arial, Helvetica, sans-serif; padding: 5px 0px; text-align: left; line-height: 10px; background-color: white; box-shadow: rgb(136, 136, 136) 2px 2px 10px; display: none;"><div style="padding: 12px 8px; background-color: white; color: black;">Print</div><div style="padding: 12px 8px; background-color: white; color: black;">Save as JPEG</div><div style="padding: 12px 8px; background-color: white; color: black;">Save as PNG</div></div></div><div class="canvasjs-chart-tooltip" style="position: absolute; height: auto; box-shadow: rgba(0, 0, 0, 0.1) 1px 1px 2px 2px; z-index: 1000; pointer-events: none; display: none; border-radius: 5px;"><div style="width: auto; height: auto; min-width: 50px; line-height: normal; margin: 0px; padding: 5px; font-family: Calibri, Arial, Georgia, serif; font-weight: normal; font-style: italic; font-size: 14px; color: rgb(0, 0, 0); text-shadow: rgba(0, 0, 0, 0.1) 1px 1px 1px; text-align: left; border: 2px solid gray; background: rgba(255, 255, 255, 0.9); text-indent: 0px; white-space: nowrap; border-radius: 5px; user-select: none;">Sample Tooltip</div></div><a class="canvasjs-chart-credit" title="JavaScript Charts" tabindex="-1" target="_blank" href="https://canvasjs.com/" style="outline: none; margin: 0px; position: absolute; right: 2px; top: 286px; color: dimgrey; text-decoration: none; font-size: 11px; font-family: Calibri, &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, sans-serif;">CanvasJS.com</a></div></div>
        </div>
        <div class="col-lg-4">
                <div class="card sales-card">
                    <div class="card-header" style="background:#f8f4f4 !important;padding:10px;"><center><strong>Customers</strong></center></div>
                    <div class="card-body" style="background:#fff !important;">
                        <br><br><div align="center"><button class="button btn btn-success" onclick="window.open('clients.php', '_blank')">Total Customers :  260</button></div>
                        <br><br>
                        <div align="center"><button class="button btn btn-success" onclick="cust(0);">New Customers : 
                        1</button></div>
                        <br><br>
                        <div align="center"><button class="button btn btn-success">Repeated Customers :
                         3</button></div>
                        <!--<div align="center"><button class="button btn btn-success" onclick = "cust(1);">Repeated Customers : 3-->
                        <br><br>
                    </div>
                </div>
        </div>      
    </div>
</div>
<script type="text/javascript">
    $('document').ready(function(){
var chart = new CanvasJS.Chart("chartContainer", {
    animationEnabled: true,
    exportEnabled: true,
    theme: "light1", // "light1", "light2", "dark1", "dark2"
    title:{
        text: "Sales Record"
    },
    data: [{
        type: "column", //change type to bar, line, area, pie, etc
        //indexLabel: "{y}", //Shows y value on all Data Points
        indexLabelFontColor: "#5A5757",
        indexLabelFontSize: 16,
        indexLabelPlacement: "outside",
        dataPoints: [
            { label:"Sub Total", y: 514761.2 },
            { label:"Tax", y: 8750.7823728814 },
            { label:"Net Discount", y: 37075.15 },
            { label:"Grand Total", y: 478934 }
        ]
    }]
});
chart.render();
    });
</script>
  
</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Row ends -->
		
	</div>
	<!-- Main container ends -->
	
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->yieldPushContent('footer_script'); ?>


<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/advanced_reports/advanced_reports.blade.php ENDPATH**/ ?>