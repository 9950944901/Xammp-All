<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
			<div class="page-content">


<div class="col-sm-12">
       <div class="container-fluid">

 <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header"><i class="fa fa-table"></i> Slider</div>
            <div class="card-body">
              <div class="table-responsive">
			         <table id="example" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Sr.No.</th>
                        <th>Category</th>
                        <th>Image</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    
                    
                 <?php $__currentLoopData = $viewcategroy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   

<tr role="row" class="odd">
<td><?php echo e($i++ ); ?></td>
<td><?php echo e($setting['categroy']); ?></td>
<td>
<a href="uploads/category/<?php echo e($setting['image']); ?>" data-fancybox="images" data-caption="This image has a caption">
<img src="uploads/category/<?php echo e($setting['image']); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" style="width: 40px;">
</a></td>
<td>
<small style="color:white" class="badge float-right gradient-scooter colo-white">Active</small>	

<small style="color:white" class="badge float-right gradient-bloody colo-white">Inactive</small>
</td>

<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-animation-"><i class="fa fa-pencil"></i></button>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hypergroups/public_html/newlaravel/resources/views/admin/view-category.blade.php ENDPATH**/ ?>