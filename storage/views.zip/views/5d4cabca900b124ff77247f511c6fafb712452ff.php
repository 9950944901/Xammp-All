
<?php $__env->startSection('page_title','Balance Reports'); ?>
<?php $__env->startSection('contant'); ?>


<style>

.active{
font-size: 14px;
background-image: linear-gradient(to right, rgb(218, 34, 255) 0%, rgb(151, 51, 238) 51%, rgb(218, 34, 255) 100%);

}


.inactive{
font-size: 14px;
background-image: linear-gradient(to right, rgb(255, 81, 47) 0%, rgb(240, 152, 25) 51%, rgb(255, 81, 47) 100%);
}

.form_control222 {
    display: block;
    width: 100%;
    padding: 0.25rem 0.75rem;
    font-size: .900rem;
    font-weight: 400;
    line-height: 1.5;
    color: #212529;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    /* -webkit-appearance: none; */
    -moz-appearance: none;
    /* appearance: none; */
    border-radius: 0.25rem;
    transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
}
.bordered tbody, td, tfoot, th, thead, tr{
    border-color: inherit;
    border-style: none;
    border-width: 0;
}  



</style>

<div class="page-wrapper form_wraper_icon">
<div class="page-content">

<div class="container-fluid">
<div class="row">
    
    <div class="col-md-12">
				<div class="form-group" style="width: 15%;">
					<label>Payment method</label>
					<select name="method[]" id="modes" data-validation="required" class="form_control222 act" onchange="fetch_data(this.value);">
						<!--<option value="">--Select--</option>-->
													    <option value="1">Cash</option> 
						    							    <option value="3">Credit/Debit card</option> 
						    							    <option value="4">Cheque</option> 
						    							    <option value="5">Online payment</option> 
						    							    <option value="6">Paytm</option> 
						    							    <option value="7">E-wallet</option> 
						    							    <option value="9">Reward points</option> 
						    							    <option value="10">PhonePe</option> 
						    							    <option value="11">Gpay</option> 
						      
					</select>
				</div>
			</div>
<div class="col-lg-12">
<div class="card">
<div class="card-header billing_re_gray">Cash Balance Report<a style="float: right; font-size:13px;" href="#"><button onclick="window.print()" class="btn btn-warning pull-right"><i class="fa fa-print" aria-hidden="true"></i>Print</button></a></div>
<div class="input_form_admin">
   <div class="row">
        <div class="col-sm-3">
			<div class="form-group">
                <label for="select_date">Select date</label>
                <input type="date" class="form-control" value="06/29/2022 - 06/29/2022">
              </div>
		 </div>
		  <div class="col-sm-3">
			<div class="form-group">
			    <label for="select_date">&nbsp;</label>
               <div class="row">
                   <div class="col-md-6">
                       <a href="#" class="btn btn-success col-md-12"><i class="fa fa-filter mr-2" aria-hidden="true"></i> Filter</a>
                       </div>
               </div>
                
               
              </div>
		 </div>
   </div> 
</div>

<div class="card-body">
<div class="">


 <table class="table">
    <thead>
      <tr>
        <th>From: 11-Jul-2022</th>
        <th>To: 11-Jul-2022</th>
        <th></th>
        <th></th>
        <th></th>
           <th></th>
        <th>Opening Balance:</th>
         <th>640,712.03</th>
      </tr>
    </thead>
    
      <thead>
      <tr>
        <th>Amount Received</th>
      </tr>
    </thead>
    
    <thead>
      <tr>
        <th>Date</th>
        <th>Branch</th>
        <th>Invoice id</th>
        <th>Client name</th>
        <th>Client contact</th>
        <th>Advance received</th>
         <th>Pending payment</th>
         <th>Amount received</th>
         <th>Type</td>
      </tr>
    </thead>
    
      <tbody>
      <tr>
        <td>11-07-2022</td>
        <td>Branch 1</td>
        <td>INV 0774</td>
        <td>Poonam</td>
        <td>7888491151</td>
         <td>0.00</td>
         <td>0.00</td>
         <td>300.00</td>
          <td>Bill</td>
      </tr>
    </tbody>
  


    <thead>
      <tr>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
           <th></th>
        <th>Total Received:</th>
        <th>300.00</th>
      </tr>
    </thead>
    
      <thead>
      <tr>
        <th>Expenses</th>
      </tr>
    </thead>
    
     <thead>
      <tr>
        <th>Date</th>
        <th>Category</th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
         <th></th>
         <th>Amount paid</th>
         <th>Type</th>
      </tr>
    </thead>
    <tbody>
              <tr>
                <td>11-07-2022</td>
                <td>Stock purchase (pending payment)</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td>500</td>
                <td></td>
            </tr>
        </tbody>

   <thead>
      <tr>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
           <th></th>
        <th>Total Paid:</th>
        <th>0.00</th>
      </tr>
    </thead>
    
   <thead>
      <tr>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
           <th></th>
        <th>Closing Balance:</th>
        <th>640,712.03 /-</th>
      </tr>
    </thead>





  </table>
<div class="d-flex justify-content-flex-end Pagination_1" >

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>


<script>let elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));

elems.forEach(function(html) {
let switchery = new Switchery(html,  { size: 'small' });
});</script>




<script>

success: function (data) {
toastr.options.closeButton = true;
toastr.options.closeMethod = 'fadeOut';
toastr.options.closeDuration = 100;
toastr.success(data.message);
}
</script>




<style>

.w-5 {
display: none;
}

.h-5{
display: none;
}

.form_control222 {
    display: block;
    width: 100%;
    padding: 0.25rem 0.75rem;
    font-size: .900rem;
    font-weight: 400;
    line-height: 1.5;
    color: #212529;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    /* -webkit-appearance: none; */
    -moz-appearance: none;
    /* appearance: none; */
    border-radius: 0.25rem;
    transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
}
</style>


<?php $__env->stopSection(); ?>
<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/balance_reports/balance_reports.blade.php ENDPATH**/ ?>