<?php $__env->startSection('page_title','ADD FEEDBACK'); ?>
<?php $__env->startSection('contant'); ?>
<style>
    
   
*{
    /*padding: 3px; margin: 0;*/
    box-sizing: border-box;
    font-family: 'Acme', sans-serif;
    user-select: none;
}

.container{
    background-color: white;
    display: flex;
    flex-direction: column;
    justify-content: space-evenly;
    border-radius: 10px;
    box-shadow: 0 0 10px 10px rgba(0,0,0,0.2);
}
.mid{
    display: flex;
    flex-wrap: wrap;
    justify-content: space-evenly;
}
.head, .mid, .textarea, .end{
    padding: 15px;
}
img{
    height: 50px; width: 50px;
    cursor: pointer;
 
    border-radius: 50%;
    transition: 0.1s linear;
}
img:hover{
    background-color: gold;
    transform: scale(1.2);
}



/*.active{*/
/*  background-color: gold;*/
/*    transform: scale(1.2);*/
/*}*/




.head{
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.heading{
    width: 70%;
}
.heading h1{
    font-size: 25px;
    border-bottom: 8px solid gold;
    font-weight: bolder;
}
.close{
    display: flex;
    justify-content: space-between;
    cursor: pointer;
    transition: 0.1s linear;
    padding: 0 10px;
}
.close:hover{
    transform: scale(1.2);
}
.s{
    width: 1.5px; height: 20px;
    background-color: black;
    border-radius: 100px;
}
.s1{
    transform: translateX(1.5px) rotate(45deg);
}
.s2{
    transform: rotate(-45deg);
}
.textarea{
    display: flex;
    flex-direction: column;
    justify-content: space-evenly;
}
.textarea p{
    font-size: 18px;
}
textarea{
    outline: none;
    resize: none;
    height: 100px;
    border: 1.5px solid black;
    border-radius: 10px;
    padding: 5px;
}
.end{
    display: flex;
    justify-content: space-evenly;
    align-items: center;
}
.btn{
    width: 150px;
    height: 35px;
    border: 1px solid black;
    cursor: pointer;
    background-color: transparent;
    font-size: 15px;
}
.sub{
    background: gold;
    border: 1px solid transparent;
    transition: 0.1s linear;
}
.skp{
    transition: 0.1s linear;
    border: 1px solid black;
}
.skp:hover{
    background-color: black;
    color: white;
}
.sub:hover{
    background-color: black;
    border: 1px solid black;
    color: white;
}
    
</style>

<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Add FEEDBACK
</div>
			     <div class="card-body">
				    <form method="POSt" action="add_enquiry" class="form-horizontal" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
 <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					   <div class="content">
        <div class="container">
            <div class="head">
                <div class="heading"><h1>Share your experience</h1></div>
                <div class="close">
                    
                    
                </div>
            </div>
            <div class="mid">
                <input type="hidden" value="1" ><div class="media"><img onblur="active" src="https://cdn-icons-png.flaticon.com/128/3260/3260838.png" alt="angry"></div>
                <div class="media"><img src="https://cdn-icons-png.flaticon.com/128/42/42901.png" alt="moderate"></div>
                <div class="media"><img src="https://cdn-icons-png.flaticon.com/128/3260/3260877.png" alt="neutral"></div>
                <div class="media"><img src="https://cdn-icons-png.flaticon.com/128/569/569501.png" alt="smile" ></div>
                <div class="media"><img src="https://cdn-icons-png.flaticon.com/128/1356/1356639.png" alt="happy"></div>
            </div>
            <div class="textarea">
                <p>Share your experience</p>
                <textarea name="exp" id="exp" placeholder="Let we know..."></textarea>
            </div>
            <div class="end">
                <div class="submission">
                    <button class="sub btn">Send</button>
                </div>
              
            </div>
        </div>
    </div>
						  
						
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/add_feedback.blade.php ENDPATH**/ ?>