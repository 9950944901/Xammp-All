
<?php $__env->startSection('page_title','View Coupon'); ?>
<?php $__env->startSection('contant'); ?>


<style>

.active{
font-size: 14px;
background-image: linear-gradient(to right, rgb(218, 34, 255) 0%, rgb(151, 51, 238) 51%, rgb(218, 34, 255) 100%);

}


.inactive{
font-size: 14px;
background-image: linear-gradient(to right, rgb(255, 81, 47) 0%, rgb(240, 152, 25) 51%, rgb(255, 81, 47) 100%);
}


</style>

<div class="page-wrapper">
<div class="page-content">


<div class="col-sm-12">
<div class="container-fluid">
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header"><i class="fa fa-table"></i>View Coupon<a style="float: right;" class="btn btn-primary" href="add_coupon"><i class="fa fa-plus-circle" style="margin-right: 0;" aria-hidden="true"></i></a></div>
<div class="card-body">
<div class="table-responsive">


<table id="example2" class="table table-bordered" style="width:100%">
<thead>
<tr>
<th>Sr.No.</th>
<th>Coupon code</th>
<th>Discount </th>
<th>Minimum bill amount</th>
<th>Maximum discount amount</th>
<th>Coupons per user </th>
<th>Valid till </th>
<th>Reward points </th>
<th>Status</th>
<th>Action</th>

</tr>
</thead>
<tbody>

<?php $i=0;?>
<?php $__currentLoopData = $viewscoupon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $settingee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




<tr role="row" class="odd">
<td><?php $i++;?><?php echo e($i); ?></td>
<td><?php echo e($settingee->coupon_code); ?></td>
<td><?php echo e($settingee->discount); ?><?php if($settingee->discount_type=='1'): ?>% <?php else: ?> FIXED AMOUNT <?php endif; ?></td>
<td><?php echo e($settingee->min_bill_amount); ?></td>
<td><?php echo e($settingee->max_discount_amount); ?></td>
<td><?php echo e($settingee->coupon_per_user); ?></td>
<td><?php echo e($settingee->valid_till); ?></td>
<td><?php echo e($settingee->reward_points); ?></td>
<td>
<input type="checkbox" data-id="<?php echo e($settingee->id); ?>" name="status" class="js-switch" <?php echo e($settingee->status == 1 ? 'checked' : '0'); ?>></td>


<td>
      <?php $id= $settingee->id ;?>
    <a class="btn btn-primary" href="cou_update<?php echo e($id); ?>"><i class="fa fa-pencil"></i></a>
<a class="btn btn-danger" onclick="return confirm('Are you sure?')" href="cou_delete<?php echo e($id); ?>"><i class="fa fa-trash-o"></i></a>
</td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

</table>

<div class="d-flex justify-content-flex-end Pagination_1" >
<?php echo $viewscoupon->links("pagination::bootstrap-4"); ?>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>


<script>let elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));

elems.forEach(function(html) {
let switchery = new Switchery(html,  { size: 'small' });
});</script>


<script>


$(document).ready(function(){
$('.js-switch').change(function () {
let status = $(this).prop('checked') === true ? 1 : 0;
let userId = $(this).data('id');
$.ajax({
type: "GET",
dataType: "json",
url: 'categories.update.status',
data: {'status': status, 'id': userId},
success: function (data) {
alert(data.message);
}
});
});
});

</script>

<script>

success: function (data) {
toastr.options.closeButton = true;
toastr.options.closeMethod = 'fadeOut';
toastr.options.closeDuration = 100;
toastr.success(data.message);
}
</script>




<style>

.w-5 {
display: none;
}

.h-5{
display: none;
}

</style>

<script>let elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));

elems.forEach(function(html) {
let switchery = new Switchery(html,  { size: 'small' });
});</script>


<script>


$(document).ready(function(){
$('.js-switch').change(function () {
let status = $(this).prop('checked') === true ? 1 : 0;
let userId = $(this).data('id');
$.ajax({
type: "GET",
dataType: "json",
url: 'coupon.update.status',
data: {'status': status, 'id': userId},
success: function (data) {
alert(data.message);
}
});
});
});

</script>

<script>

success: function (data) {
toastr.options.closeButton = true;
toastr.options.closeMethod = 'fadeOut';
toastr.options.closeDuration = 100;
toastr.success(data.message);
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtsdigital/public_html/Gts_salon/resources/views/admin/view_coupon.blade.php ENDPATH**/ ?>