
<?php $__env->startSection('page_title','View tax'); ?>
<?php $__env->startSection('contant'); ?>


<style>

.active{
font-size: 14px;
background-image: linear-gradient(to right, rgb(218, 34, 255) 0%, rgb(151, 51, 238) 51%, rgb(218, 34, 255) 100%);

}


.inactive{
font-size: 14px;
background-image: linear-gradient(to right, rgb(255, 81, 47) 0%, rgb(240, 152, 25) 51%, rgb(255, 81, 47) 100%);
}


</style>

<div class="page-wrapper form_wraper_icon">
<div class="page-content">


<div class="col-sm-12">
<div class="container-fluid">
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header"><i class="fa fa-table"></i>View Tax<a style="float: right;" class="btn btn-primary" href="addtax"><i class="fa fa-plus-circle" style="margin-right: 0;" aria-hidden="true"></i></a></div>
<div class="card-body">
<div class="table-responsive">


<table id="example2" class="table table-bordered" style="width:100%">
<thead>
<tr>
<th>Sr.No.</th>
<th>Tax Method </th>

<th>Action</th>

</tr>
</thead>
<tbody>

<?php $i=0;?>
<?php $__currentLoopData = $tax; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $settingee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




<tr role="row" class="odd">
<td><?php $i++;?><?php echo e($i); ?></td>
<td><?php echo e($settingee->tax); ?></td>


<td>
      
    <a class="btn btn-primary" href="edittax/<?php echo e($settingee->id); ?>"><i class="fa fa-pencil"></i></a>
<a class="btn btn-danger" onclick="return confirm('Are you sure?')" href="deletetax<?php echo e($settingee->id); ?>"><i class="fa fa-trash-o"></i></a>
</td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

</table>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>


<style>

.w-5 {
display: none;
}

.h-5{
display: none;
}

</style>

<script>let elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));

elems.forEach(function(html) {
let switchery = new Switchery(html,  { size: 'small' });
});</script>


<script>


$(document).ready(function(){
$('.js-switch').change(function () {
let status = $(this).prop('checked') === true ? 1 : 0;
let userId = $(this).data('id');
$.ajax({
type: "GET",
dataType: "json",
url: 'method.update.status',
data: {'status': status, 'id': userId},
success: function (data) {
alert(data.message);
}
});
});
});

</script>

<script>

success: function (data) {
toastr.options.closeButton = true;
toastr.options.closeMethod = 'fadeOut';
toastr.options.closeDuration = 100;
toastr.success(data.message);
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/taxes/index.blade.php ENDPATH**/ ?>