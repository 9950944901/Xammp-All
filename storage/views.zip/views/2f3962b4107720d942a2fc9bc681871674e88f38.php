
<?php $__env->startSection('page_title','Add wallet amount'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Add wallet amount
</div>
			     <div class="card-body">
				    <form method="POSt" action="createwallet" class="form-horizontal" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                     <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Date <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control date" value="<?php echo e(old('date')); ?>" name="date" placeholder="Date" value="" required>
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Client name<span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control" value="<?php echo e(old('client_name')); ?>" name="client_name" placeholder="Client name" value="" required>
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Contact number <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e(old('contact_number')); ?>" name="number" placeholder="Contact number" value="" required>
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Amount paid <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e(old('amount_paid')); ?>" name="paid_amount" placeholder="Amount paid" value="" required>
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						   <label for="basic-input" class="col-sm-2 col-form-label">Payment mode  <span style="color:red;">*</span></label>
						  <div class="col-sm-4">
                        <div class="input-group mb-3">
                        <select name="payent_mode" class="form-control single-select">
                        <option value="">--Select payment mode--</option>
                        <option value="1">Cash</option> 
						<option value="2">Credit/Debit card</option>
						<option value="3">Cheque</option> 
						<option value="4">Online payment</option> 
						<option value="5">Paytm</option>  
						<option value="7">PhonePe</option> 
						<option value="8">Gpay</option>
                        </select> 
                        </div>
                        <p style="color:red;"><?php $__errorArgs = ['payent_mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>
						  
						  
						  </div>
						 
  
						    <div class="form-group row">
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Amount to be credit</label>
					  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="number" class="form-control" value="<?php echo e(old('credit_amount')); ?>" name="credit_amount" placeholder="Amount to be credit" value="" required>
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['credit_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  
						    <label for="basic-input" class="col-sm-2 col-form-label">Description <span style="color:red;">*</span></label>
					  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
									<!--<input class="result form-control" type="text" name="follow_date" id="" placeholder="Date">-->
									<textarea class="form-control" name="description" id="" placeholder="Description"></textarea>
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Status <span style="color:red;">*</span></label>
                            <div class="col-sm-4">
                            <div class="input-group mb-3">
                            <select name="status" class="form-control single-select">
                            <option value="">--Select Option--</option>
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                            
                            
                            </select> 
                            </div>
                            <p style="color:red;"><?php $__errorArgs = ['Status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                            </div>
                            
                            <label for="basic-input" class="col-sm-2 col-form-label">Send receipt: <span style="color:red;">*</span></label>
					  	  <div class="col-sm-4">
							<div class="input-group mt-2">
							     <div class="form-check">
                                      <label class="form-check-label">
                                        <input type="checkbox" name="reciept" class="" value="">Send the deposit receipt to customer?
                                      </label>
                                    </div>
									
							  </div>
						  </div>
						
						  
						  
						  
						  </div>
						  
						   
						  
						  
						  
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/billing/addwallet.blade.php ENDPATH**/ ?>