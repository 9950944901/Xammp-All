
<?php $__env->startSection('page_title','History'); ?>
<?php $__env->startSection('contant'); ?>

<style>
    .btn_danger {
    padding: 4px 4px;
    margin-top: 0px;
    color: #fff;
    background-color: #fd3550;
    border-color: #fd3550;
}

    .btn_group{
        margin-top: 20px;
    }
    
</style>


<div class="tab-pane fade show active" id="appointment" role="tabpanel" aria-labelledby="appointment-tab">
      
      
    <div class="page-wrapper form_wraper_icon">
<div class="page-content">
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-header billing_re_gray">Web appointment history<a style="float: right; font-size:13px;" class="btn btn-primary" href="#"><i class="fa fa-file-excel-o mr-2" aria-hidden="true"></i>Export</a></div>

<div class="card-body">
<div class="table-responsive">


<table id="example2" class="table table-bordered" style="width:100%">
<thead>
<tr>
<th>Date of appointment</th>
<th>Date of booking</th>
<th>Client name</th>
<th>Number</th>
<th>Amount</th>
<th>Paid</th>
<th>Pending</th>
<th>Notes</th>
<th>Payment mode</th>
<th>Action</th>
</tr>
</thead>
<tbody>
   
        <tr role="row" class="odd">
            <td>02-06-2022</td>
            <td>02-06-2022</td>
            <td>Senthilkumar</td>
            <td>9847269128</td>
            <td>	-9.00</td>
            <td>0.00</td>
            <td>0.00</td>
            <td></td>
            <td>Senthilkumar</td>
              <td><a href="appointment.php?id=113" class=""><button type="button" class="btn btn-xs btn-warning"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit</button></a>
            
            <a href="#" class="btn btn-xs btn_danger"><i class="fa fa-trash-o trash" aria-hidden="true"></i> Delete</a></td>
           
        </tr>
<tr role="row" class="odd">
            <td>02-06-2022</td>
            <td>02-06-2022</td>
            <td>Senthilkumar</td>
            <td>9847269128</td>
            <td>	-9.00</td>
            <td>0.00</td>
            <td>0.00</td>
            <td></td>
              <td>ABC122</td>
              <td><a href="appointment.php?id=113" class=""><button type="button" class="btn btn-xs btn-warning"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit</button></a>
        
            <a href="#" class="btn btn-xs btn_danger"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</a></td>
           
        </tr>



</tbody>

</table>

<div class="d-flex justify-content-flex-end Pagination_1" >

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
  </div>
  
  <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/web_appointment.blade.php ENDPATH**/ ?>