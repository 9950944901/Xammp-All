
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper form_wraper_icon">
			<div class="page-content">

            <div class="container-fluid">
 

 <div class="row">
	<div class="col-lg-12">
          <div class="card">

          <div class="row">
          <div class="col-md-6"> <h5 class="card-header text-uppercase"> <?php echo e($singlepro['name']); ?> Details </h5></div>
   
          </div>
		 
         
            <div class="card-body">
              
			<div class="table-responsive">
	          <table class="table table-bordered">
            <thead>
              <tr>
                <th>Name</th>
                <td><?php echo e($singlepro['name']); ?></td>
              </tr>
         </tr>
             
   <th>Username </th>
                <td><?php echo e($singlepro['username']); ?></td>
              </tr>
			  
			  <tr>
                <th>Service commission % </th>
                <td><?php echo e($singlepro['service_commission']); ?></td>
              </tr>
              <tr>
                <th>Product commission % </th>
                <td><?php echo e($singlepro['product_commission']); ?></td>
              </tr>

              <tr>
                <th>Date of birth
 </th>
                <td><?php echo e($singlepro['dob']); ?></td>
              </tr>



              <tr>
                <th>Contact number
 </th>
                <td><?php echo e($singlepro['contcat_num']); ?></td>
              </tr>


              <tr>
                <th>Email Address
 </th>
                <td><?php echo e($singlepro['email']); ?></td>
              </tr>


              <tr>
                <th>Working hours
 </th>
                <td><?php echo e($singlepro['working_hourse_start']); ?> TO <?php echo e($singlepro['working_hourse_end']); ?></td>
              </tr>

              <tr>
                <th>Monthly salary </th>
                <td><?php echo e($singlepro['month_salary']); ?></td>
              </tr>

              <tr>
                <th>Emergency contact number </th>
                <td><?php echo e($singlepro['emg_cont_num']); ?></td>
              </tr>


              <tr>
                <th>Emergency contact person </th>
                <td><?php echo e($singlepro['emg_cont_per']); ?></td>
              </tr>


              <tr>
                <th>Address </th>
                <td><?php echo e($singlepro['address']); ?></td>
              </tr>


              <tr>
                <th>Gender </th>
                <td><?php if($singlepro['gender']=='1'): ?> Male <?php else: ?> Female <?php endif; ?></td>
              </tr>
              
              
               <tr>
                <th>Date of joining </th>
                <td><?php echo e($singlepro['date_of_joing']); ?></td>
              </tr> <tr>
                  
                  
                  
                <th>Service provider type </th>
                <td><?php echo e($singlepro['service_pro_type']); ?></td>
              </tr>

                  
                <th>Service provider Photo</th>
                <td><img style="width:50px;" src="<?php echo e(url('uploads/Service Providers/Service_providers_image')); ?>/<?php echo e($singlepro->image); ?>"></td>
              </tr>
              
                                
                <th>Service provider ID Proof </th>
                <td><img style="width:50px;" src="<?php echo e(url('uploads/Service Providers/Service_providers_IDProof')); ?>/<?php echo e($singlepro->id_proof); ?>"></td>
     
             
    
			  
          </thead>
          </table>
        </div>

			</div>
            </div>
          </div>     
          </div>
          	</div>  
              </div>
             </div>
	 
	

            <?php $__env->stopSection(); ?>



<?php echo $__env->yieldPushContent('footer_script'); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/single_service_provider.blade.php ENDPATH**/ ?>