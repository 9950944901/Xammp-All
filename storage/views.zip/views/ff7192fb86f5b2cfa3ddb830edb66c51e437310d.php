<?php $__env->startSection('page_title','ADD ATTENDANCE'); ?>
<?php $__env->startSection('contant'); ?>

<div class="page-wrapper">
			<div class="page-content">
			   
			     <div class="container-fluid">
	    <div class="row">
           <div class="col-lg-12">
		     <div class="card">
			   <div class="card-header text-uppercase"> Add Attendance
</div>
			     <div class="card-body">
				    <form method="POSt" action="add_attendance" class="form-horizontal" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                         <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					    <div class="form-group row">
						  <label for="basic-input" class="col-sm-2 col-form-label">Service provider / Staff <span style="color:red;">*</span></label>
                            						  <div class="col-sm-4">
                            							<div class="input-group mb-3">
                            <select name="provider_id" class="form-control single-select">
                            <option value="">--Select Option--</option>
                            <?php $__currentLoopData = $gold; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?>(<?php echo e($list->contcat_num); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> 
                            </div>
                            <p style="color:red;"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                            </div>
						  
						  <label for="basic-input" class="col-sm-2 col-form-label">Time <span style="color:red;">*</span></label>
						  	  <div class="col-sm-4">
							<div class="input-group mb-3">
                            
								<input type="text" class="form-control timepicker" value="<?php echo e(old('time')); ?>" name="time" placeholder="Time" >
							  </div>
                              <p style="color:red;"><?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
						  </div>

						  	   <label for="basic-input" class="col-sm-2 col-form-label">Status <span style="color:red;">*</span></label>
						  						  <div class="col-sm-4">
                                							<div class="input-group mb-3">
                                <select name="status" class="form-control single-select">
                                <option value="">--Select Option--</option>
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                                
                                
                                </select> 
                                </div>
                                <p style="color:red;"><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
						  
						  </div>
						 <p class="text-center"><input type="submit" value="submit"  class="btn btn-success" name="submit"></p>
						</div>
						</form>
						  </div>
						</div>
						  </div>
						</div>
			   
			    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abgj4nxz6fww/public_html/p1/Gts_salon/resources/views/admin/add_attendance.blade.php ENDPATH**/ ?>